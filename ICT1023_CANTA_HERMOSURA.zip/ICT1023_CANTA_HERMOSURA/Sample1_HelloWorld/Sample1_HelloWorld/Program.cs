﻿/* 19-00363
 Chester E. Canta
ND2A
February 23, 2021
This Program Will display the phrase "Hello World"
*/

using System;


namespace Sample1_HelloWorld
{
    class HelloWorld

    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Hello World");
            System.Console.ReadKey();
        }
    }
}
