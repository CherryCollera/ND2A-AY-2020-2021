﻿using System;


namespace Sample3_InputMyName
{
    public class Program
    {
        static void Main(string[] args)
        {
            string memberName = "Chester Canta, Chris Hermosura";
            
            Console.WriteLine("Enter Your  firstname lastname" + memberName);
            Console.WriteLine(" ");
            Console.WriteLine("Hello" + memberName + " " + "Welcom to OOP Enviroment");
            


        }
    }
}
