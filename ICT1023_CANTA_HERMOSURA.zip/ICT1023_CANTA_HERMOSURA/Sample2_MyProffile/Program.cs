﻿using System;
/* 
Chester Canta 19-00363
Chris Hermosura  19-02769
BSCS ND2A */


namespace Sample2_MyProfile
{
    class Program
    {
        static void Main(string[] args)
        {
            String name = "Chester Canta";
            String birthday = "November 13, 2000";
            String Year = "2nd Year";
            String Section = "ND2A";
            String Course = "BSCS";

            System.Console.WriteLine("Name: " + name + "\n" + "Birthdate: " + birthday + "\n" + "Year:  " + Year + "\n" + "Course: " + Section + "\n" + "Section: " + Course);
            System.Console.ReadKey();




        }
    }
}
