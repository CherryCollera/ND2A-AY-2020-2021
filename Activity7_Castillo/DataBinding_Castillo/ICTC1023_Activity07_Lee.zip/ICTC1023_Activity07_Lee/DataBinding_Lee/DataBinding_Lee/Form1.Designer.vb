﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.BSCSToolStrip = New System.Windows.Forms.ToolStrip()
        Me.BSCSToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.BSITToolStrip = New System.Windows.Forms.ToolStrip()
        Me.BSITToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.BalangaToolStrip = New System.Windows.Forms.ToolStrip()
        Me.BalangaToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.StudIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LastNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FirstNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MiddleNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AddressDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BirthdayDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProgramDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SectionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.YearLevelDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TblStudentInfoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.StudentsDataSet = New DataBinding_Lee.studentsDataSet()
        Me.TblStudent_InfoTableAdapter = New DataBinding_Lee.studentsDataSetTableAdapters.tblStudent_InfoTableAdapter()
        Me.RefreshToolStrip = New System.Windows.Forms.ToolStrip()
        Me.RefreshToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Letter_Start_With_A_and_CToolStrip = New System.Windows.Forms.ToolStrip()
        Me.Letter_Start_With_A_and_CToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.FirstName_that_start_with_Consonant_LetterToolStrip = New System.Windows.Forms.ToolStrip()
        Me.FirstName_that_start_with_Consonant_LetterToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.Second_YearToolStrip = New System.Windows.Forms.ToolStrip()
        Me.Second_YearToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.Section_2BToolStrip = New System.Windows.Forms.ToolStrip()
        Me.Section_2BToolStripButton = New System.Windows.Forms.ToolStripButton()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BSCSToolStrip.SuspendLayout()
        Me.BSITToolStrip.SuspendLayout()
        Me.BalangaToolStrip.SuspendLayout()
        CType(Me.TblStudentInfoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StudentsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.RefreshToolStrip.SuspendLayout()
        Me.Letter_Start_With_A_and_CToolStrip.SuspendLayout()
        Me.FirstName_that_start_with_Consonant_LetterToolStrip.SuspendLayout()
        Me.Second_YearToolStrip.SuspendLayout()
        Me.Section_2BToolStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.StudIDDataGridViewTextBoxColumn, Me.LastNameDataGridViewTextBoxColumn, Me.FirstNameDataGridViewTextBoxColumn, Me.MiddleNameDataGridViewTextBoxColumn, Me.AddressDataGridViewTextBoxColumn, Me.BirthdayDataGridViewTextBoxColumn, Me.ProgramDataGridViewTextBoxColumn, Me.SectionDataGridViewTextBoxColumn, Me.YearLevelDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.TblStudentInfoBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(15, 120)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 51
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(1306, 251)
        Me.DataGridView1.TabIndex = 0
        '
        'BSCSToolStrip
        '
        Me.BSCSToolStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.BSCSToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.BSCSToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BSCSToolStripButton})
        Me.BSCSToolStrip.Location = New System.Drawing.Point(96, 456)
        Me.BSCSToolStrip.Name = "BSCSToolStrip"
        Me.BSCSToolStrip.Size = New System.Drawing.Size(84, 40)
        Me.BSCSToolStrip.TabIndex = 1
        Me.BSCSToolStrip.Text = "BSCSToolStrip"
        '
        'BSCSToolStripButton
        '
        Me.BSCSToolStripButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BSCSToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.BSCSToolStripButton.Font = New System.Drawing.Font("Bernard MT Condensed", 16.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Strikeout), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BSCSToolStripButton.ForeColor = System.Drawing.Color.DarkRed
        Me.BSCSToolStripButton.Name = "BSCSToolStripButton"
        Me.BSCSToolStripButton.Size = New System.Drawing.Size(71, 37)
        Me.BSCSToolStripButton.Text = "BSCS"
        '
        'BSITToolStrip
        '
        Me.BSITToolStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.BSITToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.BSITToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BSITToolStripButton})
        Me.BSITToolStrip.Location = New System.Drawing.Point(1167, 456)
        Me.BSITToolStrip.Name = "BSITToolStrip"
        Me.BSITToolStrip.Size = New System.Drawing.Size(83, 40)
        Me.BSITToolStrip.TabIndex = 2
        Me.BSITToolStrip.Text = "BSITToolStrip"
        '
        'BSITToolStripButton
        '
        Me.BSITToolStripButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BSITToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.BSITToolStripButton.Font = New System.Drawing.Font("Bernard MT Condensed", 16.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Strikeout), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BSITToolStripButton.ForeColor = System.Drawing.Color.DarkRed
        Me.BSITToolStripButton.Name = "BSITToolStripButton"
        Me.BSITToolStripButton.Size = New System.Drawing.Size(70, 37)
        Me.BSITToolStripButton.Text = "BSIT"
        '
        'BalangaToolStrip
        '
        Me.BalangaToolStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.BalangaToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.BalangaToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BalangaToolStripButton})
        Me.BalangaToolStrip.Location = New System.Drawing.Point(96, 506)
        Me.BalangaToolStrip.Name = "BalangaToolStrip"
        Me.BalangaToolStrip.Size = New System.Drawing.Size(128, 40)
        Me.BalangaToolStrip.TabIndex = 3
        Me.BalangaToolStrip.Text = "BalangaToolStrip"
        '
        'BalangaToolStripButton
        '
        Me.BalangaToolStripButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BalangaToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.BalangaToolStripButton.Font = New System.Drawing.Font("Bernard MT Condensed", 16.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Strikeout), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BalangaToolStripButton.ForeColor = System.Drawing.Color.DarkRed
        Me.BalangaToolStripButton.Name = "BalangaToolStripButton"
        Me.BalangaToolStripButton.Size = New System.Drawing.Size(115, 37)
        Me.BalangaToolStripButton.Text = "Balanga"
        '
        'StudIDDataGridViewTextBoxColumn
        '
        Me.StudIDDataGridViewTextBoxColumn.DataPropertyName = "StudID"
        Me.StudIDDataGridViewTextBoxColumn.HeaderText = "StudID"
        Me.StudIDDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.StudIDDataGridViewTextBoxColumn.Name = "StudIDDataGridViewTextBoxColumn"
        Me.StudIDDataGridViewTextBoxColumn.Width = 125
        '
        'LastNameDataGridViewTextBoxColumn
        '
        Me.LastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName"
        Me.LastNameDataGridViewTextBoxColumn.HeaderText = "LastName"
        Me.LastNameDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.LastNameDataGridViewTextBoxColumn.Name = "LastNameDataGridViewTextBoxColumn"
        Me.LastNameDataGridViewTextBoxColumn.Width = 125
        '
        'FirstNameDataGridViewTextBoxColumn
        '
        Me.FirstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName"
        Me.FirstNameDataGridViewTextBoxColumn.HeaderText = "FirstName"
        Me.FirstNameDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.FirstNameDataGridViewTextBoxColumn.Name = "FirstNameDataGridViewTextBoxColumn"
        Me.FirstNameDataGridViewTextBoxColumn.Width = 125
        '
        'MiddleNameDataGridViewTextBoxColumn
        '
        Me.MiddleNameDataGridViewTextBoxColumn.DataPropertyName = "MiddleName"
        Me.MiddleNameDataGridViewTextBoxColumn.HeaderText = "MiddleName"
        Me.MiddleNameDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.MiddleNameDataGridViewTextBoxColumn.Name = "MiddleNameDataGridViewTextBoxColumn"
        Me.MiddleNameDataGridViewTextBoxColumn.Width = 125
        '
        'AddressDataGridViewTextBoxColumn
        '
        Me.AddressDataGridViewTextBoxColumn.DataPropertyName = "Address"
        Me.AddressDataGridViewTextBoxColumn.HeaderText = "Address"
        Me.AddressDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.AddressDataGridViewTextBoxColumn.Name = "AddressDataGridViewTextBoxColumn"
        Me.AddressDataGridViewTextBoxColumn.Width = 125
        '
        'BirthdayDataGridViewTextBoxColumn
        '
        Me.BirthdayDataGridViewTextBoxColumn.DataPropertyName = "Birthday"
        Me.BirthdayDataGridViewTextBoxColumn.HeaderText = "Birthday"
        Me.BirthdayDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.BirthdayDataGridViewTextBoxColumn.Name = "BirthdayDataGridViewTextBoxColumn"
        Me.BirthdayDataGridViewTextBoxColumn.Width = 125
        '
        'ProgramDataGridViewTextBoxColumn
        '
        Me.ProgramDataGridViewTextBoxColumn.DataPropertyName = "Program"
        Me.ProgramDataGridViewTextBoxColumn.HeaderText = "Program"
        Me.ProgramDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.ProgramDataGridViewTextBoxColumn.Name = "ProgramDataGridViewTextBoxColumn"
        Me.ProgramDataGridViewTextBoxColumn.Width = 125
        '
        'SectionDataGridViewTextBoxColumn
        '
        Me.SectionDataGridViewTextBoxColumn.DataPropertyName = "Section"
        Me.SectionDataGridViewTextBoxColumn.HeaderText = "Section"
        Me.SectionDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.SectionDataGridViewTextBoxColumn.Name = "SectionDataGridViewTextBoxColumn"
        Me.SectionDataGridViewTextBoxColumn.Width = 125
        '
        'YearLevelDataGridViewTextBoxColumn
        '
        Me.YearLevelDataGridViewTextBoxColumn.DataPropertyName = "YearLevel"
        Me.YearLevelDataGridViewTextBoxColumn.HeaderText = "YearLevel"
        Me.YearLevelDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.YearLevelDataGridViewTextBoxColumn.Name = "YearLevelDataGridViewTextBoxColumn"
        Me.YearLevelDataGridViewTextBoxColumn.Width = 125
        '
        'TblStudentInfoBindingSource
        '
        Me.TblStudentInfoBindingSource.DataMember = "tblStudent_Info"
        Me.TblStudentInfoBindingSource.DataSource = Me.StudentsDataSet
        '
        'StudentsDataSet
        '
        Me.StudentsDataSet.DataSetName = "studentsDataSet"
        Me.StudentsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblStudent_InfoTableAdapter
        '
        Me.TblStudent_InfoTableAdapter.ClearBeforeFill = True
        '
        'RefreshToolStrip
        '
        Me.RefreshToolStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.RefreshToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.RefreshToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RefreshToolStripButton})
        Me.RefreshToolStrip.Location = New System.Drawing.Point(1129, 506)
        Me.RefreshToolStrip.Name = "RefreshToolStrip"
        Me.RefreshToolStrip.Size = New System.Drawing.Size(121, 40)
        Me.RefreshToolStrip.TabIndex = 4
        Me.RefreshToolStrip.Text = "RefreshToolStrip"
        '
        'RefreshToolStripButton
        '
        Me.RefreshToolStripButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.RefreshToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.RefreshToolStripButton.Font = New System.Drawing.Font("Bernard MT Condensed", 16.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Strikeout), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RefreshToolStripButton.ForeColor = System.Drawing.Color.DarkRed
        Me.RefreshToolStripButton.Name = "RefreshToolStripButton"
        Me.RefreshToolStripButton.Size = New System.Drawing.Size(108, 37)
        Me.RefreshToolStripButton.Text = "Refresh"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DarkRed
        Me.Label1.Location = New System.Drawing.Point(316, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(767, 68)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "STUDENT INFORMATION"
        '
        'Letter_Start_With_A_and_CToolStrip
        '
        Me.Letter_Start_With_A_and_CToolStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.Letter_Start_With_A_and_CToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.Letter_Start_With_A_and_CToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Letter_Start_With_A_and_CToolStripButton})
        Me.Letter_Start_With_A_and_CToolStrip.Location = New System.Drawing.Point(96, 612)
        Me.Letter_Start_With_A_and_CToolStrip.Name = "Letter_Start_With_A_and_CToolStrip"
        Me.Letter_Start_With_A_and_CToolStrip.Size = New System.Drawing.Size(355, 40)
        Me.Letter_Start_With_A_and_CToolStrip.TabIndex = 7
        Me.Letter_Start_With_A_and_CToolStrip.Text = "Letter_Start_With_A_and_CToolStrip"
        '
        'Letter_Start_With_A_and_CToolStripButton
        '
        Me.Letter_Start_With_A_and_CToolStripButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Letter_Start_With_A_and_CToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.Letter_Start_With_A_and_CToolStripButton.Font = New System.Drawing.Font("Bernard MT Condensed", 16.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Strikeout), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Letter_Start_With_A_and_CToolStripButton.ForeColor = System.Drawing.Color.DarkRed
        Me.Letter_Start_With_A_and_CToolStripButton.Name = "Letter_Start_With_A_and_CToolStripButton"
        Me.Letter_Start_With_A_and_CToolStripButton.Size = New System.Drawing.Size(342, 37)
        Me.Letter_Start_With_A_and_CToolStripButton.Text = "Letter_Start_With_A_and_C"
        '
        'FirstName_that_start_with_Consonant_LetterToolStrip
        '
        Me.FirstName_that_start_with_Consonant_LetterToolStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.FirstName_that_start_with_Consonant_LetterToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.FirstName_that_start_with_Consonant_LetterToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FirstName_that_start_with_Consonant_LetterToolStripButton})
        Me.FirstName_that_start_with_Consonant_LetterToolStrip.Location = New System.Drawing.Point(690, 612)
        Me.FirstName_that_start_with_Consonant_LetterToolStrip.Name = "FirstName_that_start_with_Consonant_LetterToolStrip"
        Me.FirstName_that_start_with_Consonant_LetterToolStrip.Size = New System.Drawing.Size(560, 40)
        Me.FirstName_that_start_with_Consonant_LetterToolStrip.TabIndex = 8
        Me.FirstName_that_start_with_Consonant_LetterToolStrip.Text = "FirstName_that_start_with_Consonant_LetterToolStrip"
        '
        'FirstName_that_start_with_Consonant_LetterToolStripButton
        '
        Me.FirstName_that_start_with_Consonant_LetterToolStripButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FirstName_that_start_with_Consonant_LetterToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FirstName_that_start_with_Consonant_LetterToolStripButton.Font = New System.Drawing.Font("Bernard MT Condensed", 16.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Strikeout), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FirstName_that_start_with_Consonant_LetterToolStripButton.ForeColor = System.Drawing.Color.DarkRed
        Me.FirstName_that_start_with_Consonant_LetterToolStripButton.Name = "FirstName_that_start_with_Consonant_LetterToolStripButton"
        Me.FirstName_that_start_with_Consonant_LetterToolStripButton.Size = New System.Drawing.Size(547, 37)
        Me.FirstName_that_start_with_Consonant_LetterToolStripButton.Text = "FirstName_that_start_with_Consonant_Letter"
        '
        'Second_YearToolStrip
        '
        Me.Second_YearToolStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.Second_YearToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.Second_YearToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Second_YearToolStripButton})
        Me.Second_YearToolStrip.Location = New System.Drawing.Point(96, 559)
        Me.Second_YearToolStrip.Name = "Second_YearToolStrip"
        Me.Second_YearToolStrip.Size = New System.Drawing.Size(182, 40)
        Me.Second_YearToolStrip.TabIndex = 9
        Me.Second_YearToolStrip.Text = "Second_YearToolStrip"
        '
        'Second_YearToolStripButton
        '
        Me.Second_YearToolStripButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Second_YearToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.Second_YearToolStripButton.Font = New System.Drawing.Font("Bernard MT Condensed", 16.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Strikeout), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Second_YearToolStripButton.ForeColor = System.Drawing.Color.DarkRed
        Me.Second_YearToolStripButton.Name = "Second_YearToolStripButton"
        Me.Second_YearToolStripButton.Size = New System.Drawing.Size(169, 37)
        Me.Second_YearToolStripButton.Text = "Second_Year"
        '
        'Section_2BToolStrip
        '
        Me.Section_2BToolStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.Section_2BToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.Section_2BToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Section_2BToolStripButton})
        Me.Section_2BToolStrip.Location = New System.Drawing.Point(1087, 559)
        Me.Section_2BToolStrip.Name = "Section_2BToolStrip"
        Me.Section_2BToolStrip.Size = New System.Drawing.Size(163, 40)
        Me.Section_2BToolStrip.TabIndex = 10
        Me.Section_2BToolStrip.Text = "Section_2BToolStrip"
        '
        'Section_2BToolStripButton
        '
        Me.Section_2BToolStripButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Section_2BToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.Section_2BToolStripButton.Font = New System.Drawing.Font("Bernard MT Condensed", 16.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Strikeout), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Section_2BToolStripButton.ForeColor = System.Drawing.Color.DarkRed
        Me.Section_2BToolStripButton.Name = "Section_2BToolStripButton"
        Me.Section_2BToolStripButton.Size = New System.Drawing.Size(150, 37)
        Me.Section_2BToolStripButton.Text = "Section_2B"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.DataBinding_Lee.My.Resources.Resources.sas
        Me.ClientSize = New System.Drawing.Size(1342, 728)
        Me.Controls.Add(Me.Section_2BToolStrip)
        Me.Controls.Add(Me.Second_YearToolStrip)
        Me.Controls.Add(Me.FirstName_that_start_with_Consonant_LetterToolStrip)
        Me.Controls.Add(Me.Letter_Start_With_A_and_CToolStrip)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.RefreshToolStrip)
        Me.Controls.Add(Me.BalangaToolStrip)
        Me.Controls.Add(Me.BSITToolStrip)
        Me.Controls.Add(Me.BSCSToolStrip)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BSCSToolStrip.ResumeLayout(False)
        Me.BSCSToolStrip.PerformLayout()
        Me.BSITToolStrip.ResumeLayout(False)
        Me.BSITToolStrip.PerformLayout()
        Me.BalangaToolStrip.ResumeLayout(False)
        Me.BalangaToolStrip.PerformLayout()
        CType(Me.TblStudentInfoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StudentsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.RefreshToolStrip.ResumeLayout(False)
        Me.RefreshToolStrip.PerformLayout()
        Me.Letter_Start_With_A_and_CToolStrip.ResumeLayout(False)
        Me.Letter_Start_With_A_and_CToolStrip.PerformLayout()
        Me.FirstName_that_start_with_Consonant_LetterToolStrip.ResumeLayout(False)
        Me.FirstName_that_start_with_Consonant_LetterToolStrip.PerformLayout()
        Me.Second_YearToolStrip.ResumeLayout(False)
        Me.Second_YearToolStrip.PerformLayout()
        Me.Section_2BToolStrip.ResumeLayout(False)
        Me.Section_2BToolStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents StudentsDataSet As studentsDataSet
    Friend WithEvents TblStudentInfoBindingSource As BindingSource
    Friend WithEvents TblStudent_InfoTableAdapter As studentsDataSetTableAdapters.tblStudent_InfoTableAdapter
    Friend WithEvents StudIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents LastNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents FirstNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents MiddleNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents AddressDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BirthdayDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ProgramDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents SectionDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents YearLevelDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BSCSToolStrip As ToolStrip
    Friend WithEvents BSCSToolStripButton As ToolStripButton
    Friend WithEvents BSITToolStrip As ToolStrip
    Friend WithEvents BSITToolStripButton As ToolStripButton
    Friend WithEvents BalangaToolStrip As ToolStrip
    Friend WithEvents BalangaToolStripButton As ToolStripButton
    Friend WithEvents RefreshToolStrip As ToolStrip
    Friend WithEvents RefreshToolStripButton As ToolStripButton
    Friend WithEvents Label1 As Label
    Friend WithEvents Letter_Start_With_A_and_CToolStrip As ToolStrip
    Friend WithEvents Letter_Start_With_A_and_CToolStripButton As ToolStripButton
    Friend WithEvents FirstName_that_start_with_Consonant_LetterToolStrip As ToolStrip
    Friend WithEvents FirstName_that_start_with_Consonant_LetterToolStripButton As ToolStripButton
    Friend WithEvents Second_YearToolStrip As ToolStrip
    Friend WithEvents Second_YearToolStripButton As ToolStripButton
    Friend WithEvents Section_2BToolStrip As ToolStrip
    Friend WithEvents Section_2BToolStripButton As ToolStripButton
End Class
