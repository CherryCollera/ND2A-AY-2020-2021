﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'StudentsDataSet.tblStudent_Info' table. You can move, or remove it, as needed.
        Me.TblStudent_InfoTableAdapter.Fill(Me.StudentsDataSet.tblStudent_Info)

    End Sub

    Private Sub BSCSToolStripButton_Click(sender As Object, e As EventArgs) Handles BSCSToolStripButton.Click
        Try
            Me.TblStudent_InfoTableAdapter.BSCS(Me.StudentsDataSet.tblStudent_Info)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub BSITToolStripButton_Click(sender As Object, e As EventArgs) Handles BSITToolStripButton.Click
        Try
            Me.TblStudent_InfoTableAdapter.BSIT(Me.StudentsDataSet.tblStudent_Info)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub BalangaToolStripButton_Click(sender As Object, e As EventArgs) Handles BalangaToolStripButton.Click
        Try
            Me.TblStudent_InfoTableAdapter.Balanga(Me.StudentsDataSet.tblStudent_Info)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub Lastname_start_with_letter_A_and_CToolStripButton_Click(sender As Object, e As EventArgs)
        Try
            Me.TblStudent_InfoTableAdapter.lastname_start_with_letter_A_and_C(Me.StudentsDataSet.tblStudent_Info)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub RefreshToolStripButton_Click(sender As Object, e As EventArgs) Handles RefreshToolStripButton.Click
        Try
            Me.TblStudent_InfoTableAdapter.Refresh(Me.StudentsDataSet.tblStudent_Info)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub Lastname_start_with_Letter_A_and_C1ToolStripButton_Click(sender As Object, e As EventArgs)
        Try
            Me.TblStudent_InfoTableAdapter.Lastname_start_with_Letter_A_and_C1(Me.StudentsDataSet.tblStudent_Info)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub Letter_Start_With_A_and_CToolStripButton_Click(sender As Object, e As EventArgs) Handles Letter_Start_With_A_and_CToolStripButton.Click
        Try
            Me.TblStudent_InfoTableAdapter.Letter_Start_With_A_and_C(Me.StudentsDataSet.tblStudent_Info)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub FirstName_that_start_with_Consonant_LetterToolStripButton_Click(sender As Object, e As EventArgs) Handles FirstName_that_start_with_Consonant_LetterToolStripButton.Click
        Try
            Me.TblStudent_InfoTableAdapter.FirstName_that_start_with_Consonant_Letter(Me.StudentsDataSet.tblStudent_Info)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub Second_YearToolStripButton_Click(sender As Object, e As EventArgs) Handles Second_YearToolStripButton.Click
        Try
            Me.TblStudent_InfoTableAdapter.Second_Year(Me.StudentsDataSet.tblStudent_Info)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub Section_2BToolStripButton_Click(sender As Object, e As EventArgs) Handles Section_2BToolStripButton.Click
        Try
            Me.TblStudent_InfoTableAdapter.Section_2B(Me.StudentsDataSet.tblStudent_Info)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub
End Class
