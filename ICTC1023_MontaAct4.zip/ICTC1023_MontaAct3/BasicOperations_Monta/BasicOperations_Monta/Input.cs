﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BasicOperations_Monta
{
    class Input
    {
        public int num1, num2;
        public void InputV()
        {

            Console.Write("Enter first number: ");
            DeclareVar.num1 = Convert.ToInt32(Console.ReadLine());
            System.Console.Write("Enter second number: ");
            DeclareVar.num2 = Convert.ToInt32(Console.ReadLine());
          
           

        }
    }
}

