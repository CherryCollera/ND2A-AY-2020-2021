﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BasicOperations_Monta
{
    class Remainder
    {
        
        public void ComputeRem()
        {

            DeclareVar.rem = DeclareVar.num1 % DeclareVar.num2;

        }
    }
}
