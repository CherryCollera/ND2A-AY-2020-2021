﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BasicOperations_Monta
{
    class Difference
    {
        

        public void ComputeDiff()
        {

            DeclareVar.diff = DeclareVar.num1 - DeclareVar.num2;
        }
    }
}
