﻿using BasicOperations_Monta;
    class DeclareVar
        {
    
           public static int num1, num2, sum, diff, quo, prod, rem;
      
        }

