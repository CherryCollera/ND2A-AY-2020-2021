﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BasicOperations_Monta
{
    class Quotient
    {
        
        public void ComputeQuotient()
        {

            DeclareVar.quo = DeclareVar.num1 / DeclareVar.num2;

        }
    }
}
