﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BasicOperations_Monta
{
    class Sum
    {
        public void ComputeSum()
        {
            DeclareVar.sum = DeclareVar.num1 + DeclareVar.num2;
            
        }
    }
}
