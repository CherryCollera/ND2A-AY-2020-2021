﻿/* 19-04378
  Lorefe-Mae T. Monta
  ND2A
 March 16, 2021
 */


using System;

namespace BasicOperations_Monta
{
    class Program
    {
        static void Main(string[] args)
        {
            Input i = new Input();
            i.InputV();

            Sum s = new Sum();
            s.ComputeSum();
            Console.WriteLine("The Sum is: " + DeclareVar.sum);

            Difference d = new Difference();
            d.ComputeDiff();
            Console.WriteLine("The Difference is: " + DeclareVar.diff);

            Quotient q = new Quotient();
            q.ComputeQuotient();
            Console.WriteLine("The Quotient is: " + DeclareVar.quo);

            Product p = new Product();
            p.ComputeProd();
            Console.WriteLine("The Product is: " + DeclareVar.prod);

            Remainder r = new Remainder();
            r.ComputeRem();
            Console.WriteLine("The Remainder is: " + DeclareVar.rem);



        }
    }
}
