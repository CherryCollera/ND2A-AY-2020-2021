﻿/* 19-04378
  Lorefe-Mae T. Monta
  ND2A
 March 16, 2021
 */


using System;

namespace ClassExample1_Monta
{
    class Program
    {
        static void Main(string[] args)
        {
            Print p = new Print();
            p.PrintDetails();
            Console.ReadLine();
        }
    }
}
