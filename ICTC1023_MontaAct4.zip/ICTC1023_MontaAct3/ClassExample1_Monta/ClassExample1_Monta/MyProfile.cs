﻿   class MyProfile
    {
        public void DisplayProfile()
         {
            System.Console.WriteLine("\n\n\n\t\t\t\tP R O F I L E");
            System.Console.WriteLine("Name:\t\t\tLorefe-Mae Monta");
        System.Console.WriteLine("Birthday:\t\tJuly 3, 2001");
        System.Console.WriteLine("Course:\t\t\tBS Computer Science major in Network and Data Communication");
        System.Console.WriteLine("Year:\t\t\t2nd Year");
        System.Console.WriteLine("Section:\t\t\tA");

    }
}

