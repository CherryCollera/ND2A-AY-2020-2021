﻿/*
CANTA_HERMOSURA
BSCS ND2A
23/02/21
The  Program are intended to get your name and sex and display if your are Male or Female
 */
using System;
class HelloWorld
{
    static void Main()
    {
        string name;
        char sex;
        Console.Write("Enter your Name: ");
        name = Console.ReadLine();
        Console.Write("Enter your Sex [M/F]: ");
        sex = Convert.ToChar(Console.ReadLine());

        switch (sex)
        {
            case 'm':
            case 'M':
                Console.WriteLine("\nHi " + name + "!\nYour Gender is Male.");
                break;
            case 'f':
            case 'F':
                Console.WriteLine("\nHi " + name + "!\nYour Gender is Female.");
                break;
            default:
                Console.WriteLine("Invalid Input!");
                break;
        }
        Console.ReadKey();

    }
}
