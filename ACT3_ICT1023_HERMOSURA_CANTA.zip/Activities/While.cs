﻿/*
CANTA_HERMOSURA
BSCS ND2A
23/02/21
The  Program are intended to loop number and print number until 0-9 using while
 */
using System;
class HelloWorld
{
    static void Main()
    {
        int i = 0;
        while (i < 10)
        {
            Console.Write("While Statement  ");
            Console.WriteLine(i);
            i++;
        }
        Console.ReadLine();
    }
}
