﻿/*

BSCS ND2A
23/02/21
The  Program are intended to loop number and print number until 0-9
 */
using System;
class HelloWorld
{
    static void Main()
    {
        for (int i = 10 - 1; i >= 0; i--)
        {
            Console.WriteLine(i);
        }
        Console.ReadKey();
    }
}
