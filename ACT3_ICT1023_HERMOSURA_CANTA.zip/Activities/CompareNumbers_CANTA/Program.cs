﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompareNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, num3;

            Console.Write("Enter First Number: ");
            num1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Second Number: ");
            num2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Third Number: ");
            num3 = Convert.ToInt32(Console.ReadLine());
            Console.ReadKey();

            if (num1 == num2)
            {
                if (num1 == num3)
                {
                    Console.WriteLine("{0} {1} and {2} are equal", num1, num2, num3);
                    Console.ReadKey();
                }
                else if (num1 < num3)
                {
                    Console.WriteLine("{0} and {1} are equal but less than {3}", num1, num2, num3);
                    Console.ReadKey();
                }
                else if (num1 > num3)
                {
                    Console.WriteLine("{0} and {1} are equal but greater than {3}", num1, num2, num3);
                    Console.ReadKey();
                }


            }
            else if (num1 > num2)
            {
                if (num1 > num3)
                {
                    Console.WriteLine("{0} is greater than {1} and {2}", num1, num2, num3);

                    Console.WriteLine("{0} is greater than {1}", num1, num2);
                    Console.WriteLine("{0} is greater than {1}", num1, num3);
                    Console.ReadKey();
                }

                else if (num1 < num3)
                {
                    Console.WriteLine("{0} is greater than {1} but less than {2}", num1, num2, num3);
                    Console.WriteLine("{0} is greater than {1}", num1, num2);
                    Console.WriteLine("{0} is less than {1}", num1, num3);
                    Console.ReadKey();
                }
                else if (num1 == num3)
                {
                    Console.WriteLine("{0} is greater than {1} but equal to {2}", num1, num2, num3);
                    Console.WriteLine("{0} is greater than {1}", num1, num2);
                    Console.WriteLine("{0} is equal to {1}", num1, num3);
                    Console.ReadKey();

                }

                }
                else if (num2 > num3)
                {
                    if (num2 > num1)
                    {
                        Console.WriteLine("{0} is greater than {1} and {2}", num2, num1, num3);
                        Console.WriteLine("{0} is greater than {1}", num2, num3);
                        Console.WriteLine("{0} is greater than {1}", num2, num1);
                        Console.ReadKey();

                    }

                
               
                }
                else if (num3 > num1)
                {
                    if (num3 > num2)
                    {
                        Console.WriteLine("{0} greater than {1} and {2}", num3, num2, num1);
                       
                    Console.WriteLine("{0} greater than {1}", num3, num1);
                    Console.WriteLine("{0} is greater than {1}", num3, num2);
                    Console.ReadKey();
                }
                else if (num3 < num2)
                    {
                        Console.WriteLine("{0} greater than {1} but less than {2}", num3, num1, num2);
                    Console.WriteLine("{0} greater than {1}", num3, num1);
                    Console.WriteLine("{0} is less than {1}", num3, num2);
                    Console.ReadKey();
                    }
                    else if (num3 == num2)
                    {
                        Console.WriteLine("{0} greater than {1} equal to {2}", num3, num1, num2);
                    Console.WriteLine("{0} greater than {1}", num3, num1);
                    Console.WriteLine("{0} is equal {1}", num3, num2);
                    Console.ReadKey();
                    }
                }

            }

        }
    }

