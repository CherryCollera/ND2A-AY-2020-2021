﻿
namespace act7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.bSCSToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSCSToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.refreshToolStrip = new System.Windows.Forms.ToolStrip();
            this.refreshToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.studIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.middleNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.birthdayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.programDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sectionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yearLevelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblStudentInfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.studentsDataSet = new act7.studentsDataSet();
            this.tblStudent_InfoTableAdapter = new act7.studentsDataSetTableAdapters.tblStudent_InfoTableAdapter();
            this.samalToolStrip = new System.Windows.Forms.ToolStrip();
            this.samalToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.bSITToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSITToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.balangaToolStrip = new System.Windows.Forms.ToolStrip();
            this.balangaToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.section_2BToolStrip = new System.Windows.Forms.ToolStrip();
            this.section_2BToolStripButton = new System.Windows.Forms.ToolStripButton();
            this._2nd_YearToolStrip = new System.Windows.Forms.ToolStrip();
            this._2nd_YearToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.lastaname_A_ToolStrip = new System.Windows.Forms.ToolStrip();
            this.lastaname_A_ToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.lastname_CToolStrip = new System.Windows.Forms.ToolStrip();
            this.lastname_CToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.fN_ConsonantToolStrip = new System.Windows.Forms.ToolStrip();
            this.fN_ConsonantToolStripButton = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.bSCSToolStrip.SuspendLayout();
            this.refreshToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentInfoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsDataSet)).BeginInit();
            this.samalToolStrip.SuspendLayout();
            this.bSITToolStrip.SuspendLayout();
            this.balangaToolStrip.SuspendLayout();
            this.section_2BToolStrip.SuspendLayout();
            this._2nd_YearToolStrip.SuspendLayout();
            this.lastaname_A_ToolStrip.SuspendLayout();
            this.lastname_CToolStrip.SuspendLayout();
            this.fN_ConsonantToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Myriad Hebrew", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(309, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(326, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Students Record MonitoringSystem";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.studIDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.middleNameDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.birthdayDataGridViewTextBoxColumn,
            this.programDataGridViewTextBoxColumn,
            this.sectionDataGridViewTextBoxColumn,
            this.yearLevelDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentInfoBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(35, 73);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(945, 266);
            this.dataGridView1.TabIndex = 1;
            // 
            // bSCSToolStrip
            // 
            this.bSCSToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSCSToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSCSToolStripButton});
            this.bSCSToolStrip.Location = new System.Drawing.Point(88, 379);
            this.bSCSToolStrip.Name = "bSCSToolStrip";
            this.bSCSToolStrip.Size = new System.Drawing.Size(50, 25);
            this.bSCSToolStrip.TabIndex = 2;
            this.bSCSToolStrip.Text = "bSCSToolStrip";
            // 
            // bSCSToolStripButton
            // 
            this.bSCSToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSCSToolStripButton.Name = "bSCSToolStripButton";
            this.bSCSToolStripButton.Size = new System.Drawing.Size(38, 22);
            this.bSCSToolStripButton.Text = "BSCS";
            this.bSCSToolStripButton.Click += new System.EventHandler(this.bSCSToolStripButton_Click);
            // 
            // refreshToolStrip
            // 
            this.refreshToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.refreshToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshToolStripButton});
            this.refreshToolStrip.Location = new System.Drawing.Point(887, 406);
            this.refreshToolStrip.Name = "refreshToolStrip";
            this.refreshToolStrip.Size = new System.Drawing.Size(62, 25);
            this.refreshToolStrip.TabIndex = 3;
            this.refreshToolStrip.Text = "refreshToolStrip";
            // 
            // refreshToolStripButton
            // 
            this.refreshToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.refreshToolStripButton.Name = "refreshToolStripButton";
            this.refreshToolStripButton.Size = new System.Drawing.Size(50, 22);
            this.refreshToolStripButton.Text = "Refresh";
            this.refreshToolStripButton.Click += new System.EventHandler(this.refreshToolStripButton_Click);
            // 
            // studIDDataGridViewTextBoxColumn
            // 
            this.studIDDataGridViewTextBoxColumn.DataPropertyName = "StudID";
            this.studIDDataGridViewTextBoxColumn.HeaderText = "StudID";
            this.studIDDataGridViewTextBoxColumn.Name = "studIDDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // middleNameDataGridViewTextBoxColumn
            // 
            this.middleNameDataGridViewTextBoxColumn.DataPropertyName = "MiddleName";
            this.middleNameDataGridViewTextBoxColumn.HeaderText = "MiddleName";
            this.middleNameDataGridViewTextBoxColumn.Name = "middleNameDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            // 
            // birthdayDataGridViewTextBoxColumn
            // 
            this.birthdayDataGridViewTextBoxColumn.DataPropertyName = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.HeaderText = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.Name = "birthdayDataGridViewTextBoxColumn";
            // 
            // programDataGridViewTextBoxColumn
            // 
            this.programDataGridViewTextBoxColumn.DataPropertyName = "Program";
            this.programDataGridViewTextBoxColumn.HeaderText = "Program";
            this.programDataGridViewTextBoxColumn.Name = "programDataGridViewTextBoxColumn";
            // 
            // sectionDataGridViewTextBoxColumn
            // 
            this.sectionDataGridViewTextBoxColumn.DataPropertyName = "Section";
            this.sectionDataGridViewTextBoxColumn.HeaderText = "Section";
            this.sectionDataGridViewTextBoxColumn.Name = "sectionDataGridViewTextBoxColumn";
            // 
            // yearLevelDataGridViewTextBoxColumn
            // 
            this.yearLevelDataGridViewTextBoxColumn.DataPropertyName = "YearLevel";
            this.yearLevelDataGridViewTextBoxColumn.HeaderText = "YearLevel";
            this.yearLevelDataGridViewTextBoxColumn.Name = "yearLevelDataGridViewTextBoxColumn";
            // 
            // tblStudentInfoBindingSource
            // 
            this.tblStudentInfoBindingSource.DataMember = "tblStudent_Info";
            this.tblStudentInfoBindingSource.DataSource = this.studentsDataSet;
            // 
            // studentsDataSet
            // 
            this.studentsDataSet.DataSetName = "studentsDataSet";
            this.studentsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudent_InfoTableAdapter
            // 
            this.tblStudent_InfoTableAdapter.ClearBeforeFill = true;
            // 
            // samalToolStrip
            // 
            this.samalToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.samalToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.samalToolStripButton});
            this.samalToolStrip.Location = new System.Drawing.Point(475, 379);
            this.samalToolStrip.Name = "samalToolStrip";
            this.samalToolStrip.Size = new System.Drawing.Size(55, 25);
            this.samalToolStrip.TabIndex = 4;
            this.samalToolStrip.Text = "samalToolStrip";
            // 
            // samalToolStripButton
            // 
            this.samalToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.samalToolStripButton.Name = "samalToolStripButton";
            this.samalToolStripButton.Size = new System.Drawing.Size(43, 22);
            this.samalToolStripButton.Text = "Samal";
            this.samalToolStripButton.Click += new System.EventHandler(this.samalToolStripButton_Click);
            // 
            // bSITToolStrip
            // 
            this.bSITToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSITToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSITToolStripButton});
            this.bSITToolStrip.Location = new System.Drawing.Point(88, 424);
            this.bSITToolStrip.Name = "bSITToolStrip";
            this.bSITToolStrip.Size = new System.Drawing.Size(45, 25);
            this.bSITToolStrip.TabIndex = 5;
            this.bSITToolStrip.Text = "bSITToolStrip";
            // 
            // bSITToolStripButton
            // 
            this.bSITToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSITToolStripButton.Name = "bSITToolStripButton";
            this.bSITToolStripButton.Size = new System.Drawing.Size(33, 22);
            this.bSITToolStripButton.Text = "BSIT";
            this.bSITToolStripButton.Click += new System.EventHandler(this.bSITToolStripButton_Click);
            // 
            // balangaToolStrip
            // 
            this.balangaToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.balangaToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.balangaToolStripButton});
            this.balangaToolStrip.Location = new System.Drawing.Point(475, 424);
            this.balangaToolStrip.Name = "balangaToolStrip";
            this.balangaToolStrip.Size = new System.Drawing.Size(65, 25);
            this.balangaToolStrip.TabIndex = 6;
            this.balangaToolStrip.Text = "balangaToolStrip";
            // 
            // balangaToolStripButton
            // 
            this.balangaToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.balangaToolStripButton.Name = "balangaToolStripButton";
            this.balangaToolStripButton.Size = new System.Drawing.Size(53, 22);
            this.balangaToolStripButton.Text = "Balanga";
            this.balangaToolStripButton.Click += new System.EventHandler(this.balangaToolStripButton_Click);
            // 
            // section_2BToolStrip
            // 
            this.section_2BToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.section_2BToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.section_2BToolStripButton});
            this.section_2BToolStrip.Location = new System.Drawing.Point(251, 379);
            this.section_2BToolStrip.Name = "section_2BToolStrip";
            this.section_2BToolStrip.Size = new System.Drawing.Size(80, 25);
            this.section_2BToolStrip.TabIndex = 7;
            this.section_2BToolStrip.Text = "section_2BToolStrip";
            // 
            // section_2BToolStripButton
            // 
            this.section_2BToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.section_2BToolStripButton.Name = "section_2BToolStripButton";
            this.section_2BToolStripButton.Size = new System.Drawing.Size(68, 22);
            this.section_2BToolStripButton.Text = "Section_2B";
            this.section_2BToolStripButton.Click += new System.EventHandler(this.section_2BToolStripButton_Click);
            // 
            // _2nd_YearToolStrip
            // 
            this._2nd_YearToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this._2nd_YearToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._2nd_YearToolStripButton});
            this._2nd_YearToolStrip.Location = new System.Drawing.Point(251, 424);
            this._2nd_YearToolStrip.Name = "_2nd_YearToolStrip";
            this._2nd_YearToolStrip.Size = new System.Drawing.Size(75, 25);
            this._2nd_YearToolStrip.TabIndex = 8;
            this._2nd_YearToolStrip.Text = "_2nd_YearToolStrip";
            // 
            // _2nd_YearToolStripButton
            // 
            this._2nd_YearToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this._2nd_YearToolStripButton.Name = "_2nd_YearToolStripButton";
            this._2nd_YearToolStripButton.Size = new System.Drawing.Size(63, 22);
            this._2nd_YearToolStripButton.Text = "_2nd_Year";
            this._2nd_YearToolStripButton.Click += new System.EventHandler(this._2nd_YearToolStripButton_Click);
            // 
            // lastaname_A_ToolStrip
            // 
            this.lastaname_A_ToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.lastaname_A_ToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lastaname_A_ToolStripButton});
            this.lastaname_A_ToolStrip.Location = new System.Drawing.Point(679, 358);
            this.lastaname_A_ToolStrip.Name = "lastaname_A_ToolStrip";
            this.lastaname_A_ToolStrip.Size = new System.Drawing.Size(98, 25);
            this.lastaname_A_ToolStrip.TabIndex = 9;
            this.lastaname_A_ToolStrip.Text = "lastaname_A_ToolStrip";
            // 
            // lastaname_A_ToolStripButton
            // 
            this.lastaname_A_ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.lastaname_A_ToolStripButton.Name = "lastaname_A_ToolStripButton";
            this.lastaname_A_ToolStripButton.Size = new System.Drawing.Size(86, 22);
            this.lastaname_A_ToolStripButton.Text = "Lastaname_A_";
            this.lastaname_A_ToolStripButton.Click += new System.EventHandler(this.lastaname_A_ToolStripButton_Click);
            // 
            // lastname_CToolStrip
            // 
            this.lastname_CToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.lastname_CToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lastname_CToolStripButton});
            this.lastname_CToolStrip.Location = new System.Drawing.Point(679, 406);
            this.lastname_CToolStrip.Name = "lastname_CToolStrip";
            this.lastname_CToolStrip.Size = new System.Drawing.Size(87, 25);
            this.lastname_CToolStrip.TabIndex = 10;
            this.lastname_CToolStrip.Text = "lastname_CToolStrip";
            // 
            // lastname_CToolStripButton
            // 
            this.lastname_CToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.lastname_CToolStripButton.Name = "lastname_CToolStripButton";
            this.lastname_CToolStripButton.Size = new System.Drawing.Size(75, 22);
            this.lastname_CToolStripButton.Text = "Lastname_C";
            this.lastname_CToolStripButton.Click += new System.EventHandler(this.lastname_CToolStripButton_Click);
            // 
            // fN_ConsonantToolStrip
            // 
            this.fN_ConsonantToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.fN_ConsonantToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fN_ConsonantToolStripButton});
            this.fN_ConsonantToolStrip.Location = new System.Drawing.Point(679, 449);
            this.fN_ConsonantToolStrip.Name = "fN_ConsonantToolStrip";
            this.fN_ConsonantToolStrip.Size = new System.Drawing.Size(101, 25);
            this.fN_ConsonantToolStrip.TabIndex = 11;
            this.fN_ConsonantToolStrip.Text = "fN_ConsonantToolStrip";
            // 
            // fN_ConsonantToolStripButton
            // 
            this.fN_ConsonantToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fN_ConsonantToolStripButton.Name = "fN_ConsonantToolStripButton";
            this.fN_ConsonantToolStripButton.Size = new System.Drawing.Size(89, 22);
            this.fN_ConsonantToolStripButton.Text = "FN_Consonant";
            this.fN_ConsonantToolStripButton.Click += new System.EventHandler(this.fN_ConsonantToolStripButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(1022, 495);
            this.Controls.Add(this.fN_ConsonantToolStrip);
            this.Controls.Add(this.lastname_CToolStrip);
            this.Controls.Add(this.lastaname_A_ToolStrip);
            this.Controls.Add(this._2nd_YearToolStrip);
            this.Controls.Add(this.section_2BToolStrip);
            this.Controls.Add(this.balangaToolStrip);
            this.Controls.Add(this.bSITToolStrip);
            this.Controls.Add(this.samalToolStrip);
            this.Controls.Add(this.refreshToolStrip);
            this.Controls.Add(this.bSCSToolStrip);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "DataGrid_Romero";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.bSCSToolStrip.ResumeLayout(false);
            this.bSCSToolStrip.PerformLayout();
            this.refreshToolStrip.ResumeLayout(false);
            this.refreshToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentInfoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsDataSet)).EndInit();
            this.samalToolStrip.ResumeLayout(false);
            this.samalToolStrip.PerformLayout();
            this.bSITToolStrip.ResumeLayout(false);
            this.bSITToolStrip.PerformLayout();
            this.balangaToolStrip.ResumeLayout(false);
            this.balangaToolStrip.PerformLayout();
            this.section_2BToolStrip.ResumeLayout(false);
            this.section_2BToolStrip.PerformLayout();
            this._2nd_YearToolStrip.ResumeLayout(false);
            this._2nd_YearToolStrip.PerformLayout();
            this.lastaname_A_ToolStrip.ResumeLayout(false);
            this.lastaname_A_ToolStrip.PerformLayout();
            this.lastname_CToolStrip.ResumeLayout(false);
            this.lastname_CToolStrip.PerformLayout();
            this.fN_ConsonantToolStrip.ResumeLayout(false);
            this.fN_ConsonantToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private studentsDataSet studentsDataSet;
        private System.Windows.Forms.BindingSource tblStudentInfoBindingSource;
        private studentsDataSetTableAdapters.tblStudent_InfoTableAdapter tblStudent_InfoTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn studIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn middleNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn birthdayDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn programDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yearLevelDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStrip bSCSToolStrip;
        private System.Windows.Forms.ToolStripButton bSCSToolStripButton;
        private System.Windows.Forms.ToolStrip refreshToolStrip;
        private System.Windows.Forms.ToolStripButton refreshToolStripButton;
        private System.Windows.Forms.ToolStrip samalToolStrip;
        private System.Windows.Forms.ToolStripButton samalToolStripButton;
        private System.Windows.Forms.ToolStrip bSITToolStrip;
        private System.Windows.Forms.ToolStripButton bSITToolStripButton;
        private System.Windows.Forms.ToolStrip balangaToolStrip;
        private System.Windows.Forms.ToolStripButton balangaToolStripButton;
        private System.Windows.Forms.ToolStrip section_2BToolStrip;
        private System.Windows.Forms.ToolStripButton section_2BToolStripButton;
        private System.Windows.Forms.ToolStrip _2nd_YearToolStrip;
        private System.Windows.Forms.ToolStripButton _2nd_YearToolStripButton;
        private System.Windows.Forms.ToolStrip lastaname_A_ToolStrip;
        private System.Windows.Forms.ToolStripButton lastaname_A_ToolStripButton;
        private System.Windows.Forms.ToolStrip lastname_CToolStrip;
        private System.Windows.Forms.ToolStripButton lastname_CToolStripButton;
        private System.Windows.Forms.ToolStrip fN_ConsonantToolStrip;
        private System.Windows.Forms.ToolStripButton fN_ConsonantToolStripButton;
    }
}

