﻿
    class Accept
    {
        public string firstname, lastname;
        public void AcceptDetails()

        {

            System.Console.Write("Enter your firstname and lastname: ");
            firstname = System.Console.ReadLine();
            lastname = System.Console.ReadLine();

        }
    }

