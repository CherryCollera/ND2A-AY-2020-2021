﻿using ClassExample1_Sacdalan;

    class Print
    {
        public void PrintDetails()
        {

            Accept i = new Accept();
            i.AcceptDetails();

            System.Console.Write("Hello " + i.firstname + " " + i.lastname + "\nYou Have Created Classes in OOP");
            MyProfile mp = new MyProfile();
            mp.DisplayProfile();

        }
}

