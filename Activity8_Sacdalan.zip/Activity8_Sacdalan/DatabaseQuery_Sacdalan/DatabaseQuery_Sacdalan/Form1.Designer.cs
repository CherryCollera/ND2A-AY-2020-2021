﻿namespace DatabaseQuery_Sacdalan
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gradePointAverageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblStudentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cartmanCollegeDataSet = new DatabaseQuery_Sacdalan.CartmanCollegeDataSet();
            this.btnHighGPA = new System.Windows.Forms.Button();
            this.listBox_HighGPA = new System.Windows.Forms.ListBox();
            this.labelMinGPA = new System.Windows.Forms.Label();
            this.tblStudentsTableAdapter = new DatabaseQuery_Sacdalan.CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter();
            this.btnShowRecords = new System.Windows.Forms.Button();
            this.textBox_MinGPA = new System.Windows.Forms.TextBox();
            this.listBoxMinGPA = new System.Windows.Forms.ListBox();
            this.btn_ViewGradeStatistics = new System.Windows.Forms.Button();
            this.labelCount = new System.Windows.Forms.Label();
            this.labelMin = new System.Windows.Forms.Label();
            this.labelMax = new System.Windows.Forms.Label();
            this.labelAverage = new System.Windows.Forms.Label();
            this.btn_GroupByGPA = new System.Windows.Forms.Button();
            this.listBoxGroupByGPA = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.gradePointAverageDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(38, 29);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(444, 186);
            this.dataGridView1.TabIndex = 0;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // gradePointAverageDataGridViewTextBoxColumn
            // 
            this.gradePointAverageDataGridViewTextBoxColumn.DataPropertyName = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.HeaderText = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.Name = "gradePointAverageDataGridViewTextBoxColumn";
            // 
            // tblStudentsBindingSource
            // 
            this.tblStudentsBindingSource.DataMember = "tblStudents";
            this.tblStudentsBindingSource.DataSource = this.cartmanCollegeDataSet;
            // 
            // cartmanCollegeDataSet
            // 
            this.cartmanCollegeDataSet.DataSetName = "CartmanCollegeDataSet";
            this.cartmanCollegeDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btnHighGPA
            // 
            this.btnHighGPA.Location = new System.Drawing.Point(38, 242);
            this.btnHighGPA.Name = "btnHighGPA";
            this.btnHighGPA.Size = new System.Drawing.Size(204, 31);
            this.btnHighGPA.TabIndex = 1;
            this.btnHighGPA.Text = " Show Students with High GPA";
            this.btnHighGPA.UseVisualStyleBackColor = true;
            this.btnHighGPA.Click += new System.EventHandler(this.btnHighGPA_Click);
            // 
            // listBox_HighGPA
            // 
            this.listBox_HighGPA.FormattingEnabled = true;
            this.listBox_HighGPA.Location = new System.Drawing.Point(38, 301);
            this.listBox_HighGPA.Name = "listBox_HighGPA";
            this.listBox_HighGPA.Size = new System.Drawing.Size(204, 95);
            this.listBox_HighGPA.TabIndex = 2;
            // 
            // labelMinGPA
            // 
            this.labelMinGPA.AutoSize = true;
            this.labelMinGPA.Location = new System.Drawing.Point(274, 242);
            this.labelMinGPA.Name = "labelMinGPA";
            this.labelMinGPA.Size = new System.Drawing.Size(103, 13);
            this.labelMinGPA.TabIndex = 3;
            this.labelMinGPA.Text = "Enter minimum GPA:";
            // 
            // tblStudentsTableAdapter
            // 
            this.tblStudentsTableAdapter.ClearBeforeFill = true;
            // 
            // btnShowRecords
            // 
            this.btnShowRecords.Location = new System.Drawing.Point(277, 268);
            this.btnShowRecords.Name = "btnShowRecords";
            this.btnShowRecords.Size = new System.Drawing.Size(100, 27);
            this.btnShowRecords.TabIndex = 8;
            this.btnShowRecords.Text = " Show Records";
            this.btnShowRecords.UseVisualStyleBackColor = true;
            this.btnShowRecords.Click += new System.EventHandler(this.btnShowRecords_Click);
            // 
            // textBox_MinGPA
            // 
            this.textBox_MinGPA.Location = new System.Drawing.Point(383, 235);
            this.textBox_MinGPA.Name = "textBox_MinGPA";
            this.textBox_MinGPA.Size = new System.Drawing.Size(99, 20);
            this.textBox_MinGPA.TabIndex = 9;
            // 
            // listBoxMinGPA
            // 
            this.listBoxMinGPA.FormattingEnabled = true;
            this.listBoxMinGPA.Location = new System.Drawing.Point(277, 301);
            this.listBoxMinGPA.Name = "listBoxMinGPA";
            this.listBoxMinGPA.Size = new System.Drawing.Size(205, 95);
            this.listBoxMinGPA.TabIndex = 10;
            // 
            // btn_ViewGradeStatistics
            // 
            this.btn_ViewGradeStatistics.Location = new System.Drawing.Point(501, 29);
            this.btn_ViewGradeStatistics.Name = "btn_ViewGradeStatistics";
            this.btn_ViewGradeStatistics.Size = new System.Drawing.Size(204, 31);
            this.btn_ViewGradeStatistics.TabIndex = 11;
            this.btn_ViewGradeStatistics.Text = "View Grade Statistics";
            this.btn_ViewGradeStatistics.UseVisualStyleBackColor = true;
            this.btn_ViewGradeStatistics.Click += new System.EventHandler(this.btn_ViewGradeStatistics_Click);
            // 
            // labelCount
            // 
            this.labelCount.AutoSize = true;
            this.labelCount.Location = new System.Drawing.Point(517, 81);
            this.labelCount.Name = "labelCount";
            this.labelCount.Size = new System.Drawing.Size(35, 13);
            this.labelCount.TabIndex = 12;
            this.labelCount.Text = "label1";
            // 
            // labelMin
            // 
            this.labelMin.AutoSize = true;
            this.labelMin.Location = new System.Drawing.Point(517, 119);
            this.labelMin.Name = "labelMin";
            this.labelMin.Size = new System.Drawing.Size(35, 13);
            this.labelMin.TabIndex = 13;
            this.labelMin.Text = "label2";
            // 
            // labelMax
            // 
            this.labelMax.AutoSize = true;
            this.labelMax.Location = new System.Drawing.Point(517, 161);
            this.labelMax.Name = "labelMax";
            this.labelMax.Size = new System.Drawing.Size(35, 13);
            this.labelMax.TabIndex = 14;
            this.labelMax.Text = "label3";
            // 
            // labelAverage
            // 
            this.labelAverage.AutoSize = true;
            this.labelAverage.Location = new System.Drawing.Point(517, 202);
            this.labelAverage.Name = "labelAverage";
            this.labelAverage.Size = new System.Drawing.Size(35, 13);
            this.labelAverage.TabIndex = 15;
            this.labelAverage.Text = "label4";
            // 
            // btn_GroupByGPA
            // 
            this.btn_GroupByGPA.Location = new System.Drawing.Point(729, 29);
            this.btn_GroupByGPA.Name = "btn_GroupByGPA";
            this.btn_GroupByGPA.Size = new System.Drawing.Size(204, 31);
            this.btn_GroupByGPA.TabIndex = 16;
            this.btn_GroupByGPA.Text = "Group Records by GPA";
            this.btn_GroupByGPA.UseVisualStyleBackColor = true;
            this.btn_GroupByGPA.Click += new System.EventHandler(this.btn_GroupByGPA_Click);
            // 
            // listBoxGroupByGPA
            // 
            this.listBoxGroupByGPA.FormattingEnabled = true;
            this.listBoxGroupByGPA.Location = new System.Drawing.Point(731, 81);
            this.listBoxGroupByGPA.Name = "listBoxGroupByGPA";
            this.listBoxGroupByGPA.Size = new System.Drawing.Size(202, 225);
            this.listBoxGroupByGPA.TabIndex = 17;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(966, 423);
            this.Controls.Add(this.listBoxGroupByGPA);
            this.Controls.Add(this.btn_GroupByGPA);
            this.Controls.Add(this.labelAverage);
            this.Controls.Add(this.labelMax);
            this.Controls.Add(this.labelMin);
            this.Controls.Add(this.labelCount);
            this.Controls.Add(this.btn_ViewGradeStatistics);
            this.Controls.Add(this.listBoxMinGPA);
            this.Controls.Add(this.textBox_MinGPA);
            this.Controls.Add(this.btnShowRecords);
            this.Controls.Add(this.labelMinGPA);
            this.Controls.Add(this.listBox_HighGPA);
            this.Controls.Add(this.btnHighGPA);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Database Query Sacdalan";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnHighGPA;
        private System.Windows.Forms.ListBox listBox_HighGPA;
        private System.Windows.Forms.Label labelMinGPA;
        private CartmanCollegeDataSet cartmanCollegeDataSet;
        private System.Windows.Forms.BindingSource tblStudentsBindingSource;
        private CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter tblStudentsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gradePointAverageDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btnShowRecords;
        private System.Windows.Forms.TextBox textBox_MinGPA;
        private System.Windows.Forms.ListBox listBoxMinGPA;
        private System.Windows.Forms.Button btn_ViewGradeStatistics;
        private System.Windows.Forms.Label labelCount;
        private System.Windows.Forms.Label labelMin;
        private System.Windows.Forms.Label labelMax;
        private System.Windows.Forms.Label labelAverage;
        private System.Windows.Forms.Button btn_GroupByGPA;
        private System.Windows.Forms.ListBox listBoxGroupByGPA;
    }
}

