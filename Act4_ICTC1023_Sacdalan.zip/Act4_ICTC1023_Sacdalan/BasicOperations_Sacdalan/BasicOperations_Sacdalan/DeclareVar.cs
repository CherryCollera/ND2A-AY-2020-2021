﻿using BasicOperations_Sacdalan;

    class DeclareVar
    {
        public static double num1, num2, sum, difference, product, quotient, remainder;
    }

