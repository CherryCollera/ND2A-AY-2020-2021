﻿
    class Quotient
    {
        public void ComputeQuotient()
        {
            DeclareVar.quotient = DeclareVar.num1 / DeclareVar.num2;
        }
}

