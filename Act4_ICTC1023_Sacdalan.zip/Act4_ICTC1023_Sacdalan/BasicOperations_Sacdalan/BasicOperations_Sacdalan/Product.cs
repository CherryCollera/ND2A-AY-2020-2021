﻿

    class Product
    {
        public void ComputeProduct()
        {
            DeclareVar.product = DeclareVar.num1 * DeclareVar.num2;
        }
}

