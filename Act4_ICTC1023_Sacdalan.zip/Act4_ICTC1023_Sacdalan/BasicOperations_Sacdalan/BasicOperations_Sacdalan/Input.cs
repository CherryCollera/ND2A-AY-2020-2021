﻿using System;

namespace BasicOperations_Sacdalan
{
    class Input
    {
        public void InputData()
        {

            Console.Write("Enter First Number: ");
            DeclareVar.num1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            DeclareVar.num2 = Convert.ToDouble(Console.ReadLine());


        }
    }
}
