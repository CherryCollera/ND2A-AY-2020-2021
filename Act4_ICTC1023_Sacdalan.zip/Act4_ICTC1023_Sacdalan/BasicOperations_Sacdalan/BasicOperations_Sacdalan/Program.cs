﻿using System;

namespace BasicOperations_Sacdalan
{
    class Program
    {
        static void Main(string[] args)
        {
            Sum s = new Sum();
            s.ComputeSum();
            Difference d = new Difference();
            d.ComputeDifference();
            Product p = new Product();
            p.ComputeProduct();
            Quotient q = new Quotient();
            q.ComputeQuotient();
            Remainder r = new Remainder();
            r.ComputeRemainder();


            Console.WriteLine("Sum = " + DeclareVar.sum);
            Console.WriteLine("Difference = " + DeclareVar.difference);
            Console.WriteLine("Product = " + DeclareVar.product);
            Console.WriteLine("Quotient = " + DeclareVar.quotient);
            Console.WriteLine("Remainder = " + DeclareVar.remainder);
            Console.ReadKey();

        }
    }
}
