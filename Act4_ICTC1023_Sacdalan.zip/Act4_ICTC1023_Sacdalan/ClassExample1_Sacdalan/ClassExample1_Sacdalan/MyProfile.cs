﻿
    class MyProfile
    {
        public void DisplayProfile()
        {

            System.Console.WriteLine("\n\n\n\t\t\tP R O F I L E");
            System.Console.WriteLine("\nName:\t\t\tSta. Nina Marie P. Sacdalan");
            System.Console.WriteLine("\nBirthday:\t\tJanuary 21, 2001");
            System.Console.WriteLine("\nCourse:\t\t\tBS Computer Science Major in Network and Data Communication");
            System.Console.WriteLine("\nYear:\t\t\t2nd Year");
            System.Console.WriteLine("\nSection:\t\tA");
            System.Console.ReadLine();

        }

}

