﻿
namespace DatabaseQuery_Monta
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.cartmanCollegeDataSet = new DatabaseQuery_Monta.CartmanCollegeDataSet();
            this.tblStudentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblStudentsTableAdapter = new DatabaseQuery_Monta.CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gradePointAverageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_HighGPA = new System.Windows.Forms.Button();
            this.listBox_HighGPA = new System.Windows.Forms.ListBox();
            this.labelMinGPA = new System.Windows.Forms.Label();
            this.btn_ShowRecord = new System.Windows.Forms.Button();
            this.Box_MinGPA = new System.Windows.Forms.TextBox();
            this.listBox_MinGPA = new System.Windows.Forms.ListBox();
            this.btn_ViewGradeStat = new System.Windows.Forms.Button();
            this.label_Count = new System.Windows.Forms.Label();
            this.label_Min = new System.Windows.Forms.Label();
            this.label_Max = new System.Windows.Forms.Label();
            this.label_Average = new System.Windows.Forms.Label();
            this.btn_GroupByGPA = new System.Windows.Forms.Button();
            this.listBox_GroupByGPA = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.PaleTurquoise;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.gradePointAverageDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(23, 30);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(767, 220);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // cartmanCollegeDataSet
            // 
            this.cartmanCollegeDataSet.DataSetName = "CartmanCollegeDataSet";
            this.cartmanCollegeDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudentsBindingSource
            // 
            this.tblStudentsBindingSource.DataMember = "tblStudents";
            this.tblStudentsBindingSource.DataSource = this.cartmanCollegeDataSet;
            // 
            // tblStudentsTableAdapter
            // 
            this.tblStudentsTableAdapter.ClearBeforeFill = true;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.Width = 125;
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            this.lastNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            this.firstNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // gradePointAverageDataGridViewTextBoxColumn
            // 
            this.gradePointAverageDataGridViewTextBoxColumn.DataPropertyName = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.HeaderText = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.gradePointAverageDataGridViewTextBoxColumn.Name = "gradePointAverageDataGridViewTextBoxColumn";
            this.gradePointAverageDataGridViewTextBoxColumn.Width = 125;
            // 
            // btn_HighGPA
            // 
            this.btn_HighGPA.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_HighGPA.BackColor = System.Drawing.Color.Aquamarine;
            this.btn_HighGPA.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HighGPA.Location = new System.Drawing.Point(61, 286);
            this.btn_HighGPA.Name = "btn_HighGPA";
            this.btn_HighGPA.Size = new System.Drawing.Size(301, 44);
            this.btn_HighGPA.TabIndex = 1;
            this.btn_HighGPA.Text = "Show Student with High GPA";
            this.btn_HighGPA.UseVisualStyleBackColor = false;
            this.btn_HighGPA.Click += new System.EventHandler(this.btn_HighGPA_Click);
            // 
            // listBox_HighGPA
            // 
            this.listBox_HighGPA.BackColor = System.Drawing.Color.White;
            this.listBox_HighGPA.FormattingEnabled = true;
            this.listBox_HighGPA.ItemHeight = 16;
            this.listBox_HighGPA.Location = new System.Drawing.Point(61, 336);
            this.listBox_HighGPA.Name = "listBox_HighGPA";
            this.listBox_HighGPA.Size = new System.Drawing.Size(301, 116);
            this.listBox_HighGPA.TabIndex = 2;
            this.listBox_HighGPA.SelectedIndexChanged += new System.EventHandler(this.listBox_HighGPA_SelectedIndexChanged);
            // 
            // labelMinGPA
            // 
            this.labelMinGPA.AutoSize = true;
            this.labelMinGPA.BackColor = System.Drawing.Color.Transparent;
            this.labelMinGPA.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMinGPA.Location = new System.Drawing.Point(411, 258);
            this.labelMinGPA.Name = "labelMinGPA";
            this.labelMinGPA.Size = new System.Drawing.Size(191, 20);
            this.labelMinGPA.TabIndex = 3;
            this.labelMinGPA.Text = "Enter minimum GPA: ";
            // 
            // btn_ShowRecord
            // 
            this.btn_ShowRecord.BackColor = System.Drawing.Color.Aquamarine;
            this.btn_ShowRecord.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ShowRecord.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_ShowRecord.Location = new System.Drawing.Point(415, 288);
            this.btn_ShowRecord.Name = "btn_ShowRecord";
            this.btn_ShowRecord.Size = new System.Drawing.Size(159, 40);
            this.btn_ShowRecord.TabIndex = 4;
            this.btn_ShowRecord.Text = "Show Record";
            this.btn_ShowRecord.UseVisualStyleBackColor = false;
            this.btn_ShowRecord.Click += new System.EventHandler(this.btn_ShowRecord_Click);
            // 
            // Box_MinGPA
            // 
            this.Box_MinGPA.Location = new System.Drawing.Point(623, 258);
            this.Box_MinGPA.Name = "Box_MinGPA";
            this.Box_MinGPA.Size = new System.Drawing.Size(132, 22);
            this.Box_MinGPA.TabIndex = 5;
            this.Box_MinGPA.TextChanged += new System.EventHandler(this.Box_MinGPA_TextChanged);
            // 
            // listBox_MinGPA
            // 
            this.listBox_MinGPA.BackColor = System.Drawing.Color.White;
            this.listBox_MinGPA.FormattingEnabled = true;
            this.listBox_MinGPA.ItemHeight = 16;
            this.listBox_MinGPA.Location = new System.Drawing.Point(415, 336);
            this.listBox_MinGPA.Name = "listBox_MinGPA";
            this.listBox_MinGPA.Size = new System.Drawing.Size(340, 116);
            this.listBox_MinGPA.TabIndex = 6;
            // 
            // btn_ViewGradeStat
            // 
            this.btn_ViewGradeStat.BackColor = System.Drawing.Color.Aquamarine;
            this.btn_ViewGradeStat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ViewGradeStat.Location = new System.Drawing.Point(796, 30);
            this.btn_ViewGradeStat.Name = "btn_ViewGradeStat";
            this.btn_ViewGradeStat.Size = new System.Drawing.Size(240, 42);
            this.btn_ViewGradeStat.TabIndex = 7;
            this.btn_ViewGradeStat.Text = "View Grade Statistics";
            this.btn_ViewGradeStat.UseVisualStyleBackColor = false;
            this.btn_ViewGradeStat.Click += new System.EventHandler(this.btn_ViewGradeStat_Click);
            // 
            // label_Count
            // 
            this.label_Count.AutoSize = true;
            this.label_Count.BackColor = System.Drawing.Color.Transparent;
            this.label_Count.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Count.Location = new System.Drawing.Point(822, 88);
            this.label_Count.Name = "label_Count";
            this.label_Count.Size = new System.Drawing.Size(50, 20);
            this.label_Count.TabIndex = 8;
            this.label_Count.Text = "label1";
            // 
            // label_Min
            // 
            this.label_Min.AutoSize = true;
            this.label_Min.BackColor = System.Drawing.Color.Transparent;
            this.label_Min.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Min.Location = new System.Drawing.Point(822, 138);
            this.label_Min.Name = "label_Min";
            this.label_Min.Size = new System.Drawing.Size(50, 20);
            this.label_Min.TabIndex = 9;
            this.label_Min.Text = "label2";
            // 
            // label_Max
            // 
            this.label_Max.AutoSize = true;
            this.label_Max.BackColor = System.Drawing.Color.Transparent;
            this.label_Max.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Max.Location = new System.Drawing.Point(822, 186);
            this.label_Max.Name = "label_Max";
            this.label_Max.Size = new System.Drawing.Size(50, 20);
            this.label_Max.TabIndex = 10;
            this.label_Max.Text = "label3";
            // 
            // label_Average
            // 
            this.label_Average.AutoSize = true;
            this.label_Average.BackColor = System.Drawing.Color.Transparent;
            this.label_Average.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Average.Location = new System.Drawing.Point(822, 236);
            this.label_Average.Name = "label_Average";
            this.label_Average.Size = new System.Drawing.Size(50, 20);
            this.label_Average.TabIndex = 11;
            this.label_Average.Text = "label4";
            // 
            // btn_GroupByGPA
            // 
            this.btn_GroupByGPA.BackColor = System.Drawing.Color.Aquamarine;
            this.btn_GroupByGPA.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_GroupByGPA.Location = new System.Drawing.Point(1057, 30);
            this.btn_GroupByGPA.Name = "btn_GroupByGPA";
            this.btn_GroupByGPA.Size = new System.Drawing.Size(217, 42);
            this.btn_GroupByGPA.TabIndex = 12;
            this.btn_GroupByGPA.Text = "View Records by GPA";
            this.btn_GroupByGPA.UseVisualStyleBackColor = false;
            this.btn_GroupByGPA.Click += new System.EventHandler(this.btn_GroupByGPA_Click);
            // 
            // listBox_GroupByGPA
            // 
            this.listBox_GroupByGPA.BackColor = System.Drawing.Color.White;
            this.listBox_GroupByGPA.FormattingEnabled = true;
            this.listBox_GroupByGPA.ItemHeight = 16;
            this.listBox_GroupByGPA.Location = new System.Drawing.Point(1057, 91);
            this.listBox_GroupByGPA.Name = "listBox_GroupByGPA";
            this.listBox_GroupByGPA.Size = new System.Drawing.Size(220, 228);
            this.listBox_GroupByGPA.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleVioletRed;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1302, 481);
            this.Controls.Add(this.listBox_GroupByGPA);
            this.Controls.Add(this.btn_GroupByGPA);
            this.Controls.Add(this.label_Average);
            this.Controls.Add(this.label_Max);
            this.Controls.Add(this.label_Min);
            this.Controls.Add(this.label_Count);
            this.Controls.Add(this.btn_ViewGradeStat);
            this.Controls.Add(this.listBox_MinGPA);
            this.Controls.Add(this.Box_MinGPA);
            this.Controls.Add(this.btn_ShowRecord);
            this.Controls.Add(this.labelMinGPA);
            this.Controls.Add(this.listBox_HighGPA);
            this.Controls.Add(this.btn_HighGPA);
            this.Controls.Add(this.dataGridView1);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Database Query Monta";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CartmanCollegeDataSet cartmanCollegeDataSet;
        private System.Windows.Forms.BindingSource tblStudentsBindingSource;
        private CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter tblStudentsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gradePointAverageDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btn_HighGPA;
        private System.Windows.Forms.ListBox listBox_HighGPA;
        private System.Windows.Forms.Label labelMinGPA;
        private System.Windows.Forms.Button btn_ShowRecord;
        private System.Windows.Forms.TextBox Box_MinGPA;
        private System.Windows.Forms.ListBox listBox_MinGPA;
        private System.Windows.Forms.Button btn_ViewGradeStat;
        private System.Windows.Forms.Label label_Count;
        private System.Windows.Forms.Label label_Min;
        private System.Windows.Forms.Label label_Max;
        private System.Windows.Forms.Label label_Average;
        private System.Windows.Forms.Button btn_GroupByGPA;
        private System.Windows.Forms.ListBox listBox_GroupByGPA;
    }
}

