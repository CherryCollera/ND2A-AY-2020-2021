﻿
namespace DatabaseQuery_Monta
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.listBox_GroupByGPA = new System.Windows.Forms.ListBox();
            this.btn_GroupByGPA = new System.Windows.Forms.Button();
            this.label_Average = new System.Windows.Forms.Label();
            this.label_Max = new System.Windows.Forms.Label();
            this.label_Min = new System.Windows.Forms.Label();
            this.label_Count = new System.Windows.Forms.Label();
            this.btn_ViewGradeStat = new System.Windows.Forms.Button();
            this.listBox_MinGPA = new System.Windows.Forms.ListBox();
            this.Box_MinGPA = new System.Windows.Forms.TextBox();
            this.btn_ShowRecord = new System.Windows.Forms.Button();
            this.labelMinGPA = new System.Windows.Forms.Label();
            this.listBox_HighGPA = new System.Windows.Forms.ListBox();
            this.btn_HighGPA = new System.Windows.Forms.Button();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.cartmanCollegeDataSet1 = new DatabaseQuery_Monta.CartmanCollegeDataSet1();
            this.tblStudentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblStudentsTableAdapter = new DatabaseQuery_Monta.CartmanCollegeDataSet1TableAdapters.tblStudentsTableAdapter();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gradePointAverageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // listBox_GroupByGPA
            // 
            this.listBox_GroupByGPA.BackColor = System.Drawing.SystemColors.Info;
            this.listBox_GroupByGPA.FormattingEnabled = true;
            this.listBox_GroupByGPA.ItemHeight = 16;
            this.listBox_GroupByGPA.Location = new System.Drawing.Point(1055, 75);
            this.listBox_GroupByGPA.Name = "listBox_GroupByGPA";
            this.listBox_GroupByGPA.Size = new System.Drawing.Size(220, 228);
            this.listBox_GroupByGPA.TabIndex = 27;
            // 
            // btn_GroupByGPA
            // 
            this.btn_GroupByGPA.BackColor = System.Drawing.Color.Aquamarine;
            this.btn_GroupByGPA.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_GroupByGPA.Location = new System.Drawing.Point(1055, 14);
            this.btn_GroupByGPA.Name = "btn_GroupByGPA";
            this.btn_GroupByGPA.Size = new System.Drawing.Size(217, 42);
            this.btn_GroupByGPA.TabIndex = 26;
            this.btn_GroupByGPA.Text = "View Records by GPA";
            this.btn_GroupByGPA.UseVisualStyleBackColor = false;
            this.btn_GroupByGPA.Click += new System.EventHandler(this.btn_GroupByGPA_Click);
            // 
            // label_Average
            // 
            this.label_Average.AutoSize = true;
            this.label_Average.BackColor = System.Drawing.Color.Transparent;
            this.label_Average.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Average.Location = new System.Drawing.Point(820, 220);
            this.label_Average.Name = "label_Average";
            this.label_Average.Size = new System.Drawing.Size(50, 20);
            this.label_Average.TabIndex = 25;
            this.label_Average.Text = "label4";
            // 
            // label_Max
            // 
            this.label_Max.AutoSize = true;
            this.label_Max.BackColor = System.Drawing.Color.Transparent;
            this.label_Max.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Max.Location = new System.Drawing.Point(820, 170);
            this.label_Max.Name = "label_Max";
            this.label_Max.Size = new System.Drawing.Size(50, 20);
            this.label_Max.TabIndex = 24;
            this.label_Max.Text = "label3";
            // 
            // label_Min
            // 
            this.label_Min.AutoSize = true;
            this.label_Min.BackColor = System.Drawing.Color.Transparent;
            this.label_Min.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Min.Location = new System.Drawing.Point(820, 122);
            this.label_Min.Name = "label_Min";
            this.label_Min.Size = new System.Drawing.Size(50, 20);
            this.label_Min.TabIndex = 23;
            this.label_Min.Text = "label2";
            // 
            // label_Count
            // 
            this.label_Count.AutoSize = true;
            this.label_Count.BackColor = System.Drawing.Color.Transparent;
            this.label_Count.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Count.Location = new System.Drawing.Point(820, 72);
            this.label_Count.Name = "label_Count";
            this.label_Count.Size = new System.Drawing.Size(50, 20);
            this.label_Count.TabIndex = 22;
            this.label_Count.Text = "label1";
            // 
            // btn_ViewGradeStat
            // 
            this.btn_ViewGradeStat.BackColor = System.Drawing.Color.Aquamarine;
            this.btn_ViewGradeStat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ViewGradeStat.Location = new System.Drawing.Point(794, 14);
            this.btn_ViewGradeStat.Name = "btn_ViewGradeStat";
            this.btn_ViewGradeStat.Size = new System.Drawing.Size(240, 42);
            this.btn_ViewGradeStat.TabIndex = 21;
            this.btn_ViewGradeStat.Text = "View Grade Statistics";
            this.btn_ViewGradeStat.UseVisualStyleBackColor = false;
            this.btn_ViewGradeStat.Click += new System.EventHandler(this.btn_ViewGradeStat_Click);
            // 
            // listBox_MinGPA
            // 
            this.listBox_MinGPA.BackColor = System.Drawing.SystemColors.Info;
            this.listBox_MinGPA.FormattingEnabled = true;
            this.listBox_MinGPA.ItemHeight = 16;
            this.listBox_MinGPA.Location = new System.Drawing.Point(413, 320);
            this.listBox_MinGPA.Name = "listBox_MinGPA";
            this.listBox_MinGPA.Size = new System.Drawing.Size(340, 116);
            this.listBox_MinGPA.TabIndex = 20;
            // 
            // Box_MinGPA
            // 
            this.Box_MinGPA.Location = new System.Drawing.Point(621, 242);
            this.Box_MinGPA.Name = "Box_MinGPA";
            this.Box_MinGPA.Size = new System.Drawing.Size(132, 22);
            this.Box_MinGPA.TabIndex = 19;
            // 
            // btn_ShowRecord
            // 
            this.btn_ShowRecord.BackColor = System.Drawing.Color.Aquamarine;
            this.btn_ShowRecord.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ShowRecord.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_ShowRecord.Location = new System.Drawing.Point(413, 272);
            this.btn_ShowRecord.Name = "btn_ShowRecord";
            this.btn_ShowRecord.Size = new System.Drawing.Size(159, 40);
            this.btn_ShowRecord.TabIndex = 18;
            this.btn_ShowRecord.Text = "Show Record";
            this.btn_ShowRecord.UseVisualStyleBackColor = false;
            this.btn_ShowRecord.Click += new System.EventHandler(this.btn_ShowRecord_Click);
            // 
            // labelMinGPA
            // 
            this.labelMinGPA.AutoSize = true;
            this.labelMinGPA.BackColor = System.Drawing.Color.Transparent;
            this.labelMinGPA.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMinGPA.Location = new System.Drawing.Point(409, 242);
            this.labelMinGPA.Name = "labelMinGPA";
            this.labelMinGPA.Size = new System.Drawing.Size(191, 20);
            this.labelMinGPA.TabIndex = 17;
            this.labelMinGPA.Text = "Enter minimum GPA: ";
            // 
            // listBox_HighGPA
            // 
            this.listBox_HighGPA.BackColor = System.Drawing.SystemColors.Info;
            this.listBox_HighGPA.FormattingEnabled = true;
            this.listBox_HighGPA.ItemHeight = 16;
            this.listBox_HighGPA.Location = new System.Drawing.Point(59, 320);
            this.listBox_HighGPA.Name = "listBox_HighGPA";
            this.listBox_HighGPA.Size = new System.Drawing.Size(301, 116);
            this.listBox_HighGPA.TabIndex = 16;
            // 
            // btn_HighGPA
            // 
            this.btn_HighGPA.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_HighGPA.BackColor = System.Drawing.Color.Aquamarine;
            this.btn_HighGPA.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_HighGPA.Location = new System.Drawing.Point(59, 270);
            this.btn_HighGPA.Name = "btn_HighGPA";
            this.btn_HighGPA.Size = new System.Drawing.Size(301, 44);
            this.btn_HighGPA.TabIndex = 15;
            this.btn_HighGPA.Text = "Show Student with High GPA";
            this.btn_HighGPA.UseVisualStyleBackColor = false;
            this.btn_HighGPA.Click += new System.EventHandler(this.btn_HighGPA_Click);
            // 
            // dataGridView
            // 
            this.dataGridView.AutoGenerateColumns = false;
            this.dataGridView.BackgroundColor = System.Drawing.Color.PaleTurquoise;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.gradePointAverageDataGridViewTextBoxColumn});
            this.dataGridView.DataSource = this.tblStudentsBindingSource;
            this.dataGridView.Location = new System.Drawing.Point(21, 14);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.RowHeadersWidth = 51;
            this.dataGridView.RowTemplate.Height = 24;
            this.dataGridView.Size = new System.Drawing.Size(767, 220);
            this.dataGridView.TabIndex = 14;
            // 
            // cartmanCollegeDataSet1
            // 
            this.cartmanCollegeDataSet1.DataSetName = "CartmanCollegeDataSet1";
            this.cartmanCollegeDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudentsBindingSource
            // 
            this.tblStudentsBindingSource.DataMember = "tblStudents";
            this.tblStudentsBindingSource.DataSource = this.cartmanCollegeDataSet1;
            // 
            // tblStudentsTableAdapter
            // 
            this.tblStudentsTableAdapter.ClearBeforeFill = true;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.Width = 125;
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            this.lastNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            this.firstNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // gradePointAverageDataGridViewTextBoxColumn
            // 
            this.gradePointAverageDataGridViewTextBoxColumn.DataPropertyName = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.HeaderText = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.gradePointAverageDataGridViewTextBoxColumn.Name = "gradePointAverageDataGridViewTextBoxColumn";
            this.gradePointAverageDataGridViewTextBoxColumn.Width = 125;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1293, 450);
            this.Controls.Add(this.listBox_GroupByGPA);
            this.Controls.Add(this.btn_GroupByGPA);
            this.Controls.Add(this.label_Average);
            this.Controls.Add(this.label_Max);
            this.Controls.Add(this.label_Min);
            this.Controls.Add(this.label_Count);
            this.Controls.Add(this.btn_ViewGradeStat);
            this.Controls.Add(this.listBox_MinGPA);
            this.Controls.Add(this.Box_MinGPA);
            this.Controls.Add(this.btn_ShowRecord);
            this.Controls.Add(this.labelMinGPA);
            this.Controls.Add(this.listBox_HighGPA);
            this.Controls.Add(this.btn_HighGPA);
            this.Controls.Add(this.dataGridView);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox_GroupByGPA;
        private System.Windows.Forms.Button btn_GroupByGPA;
        private System.Windows.Forms.Label label_Average;
        private System.Windows.Forms.Label label_Max;
        private System.Windows.Forms.Label label_Min;
        private System.Windows.Forms.Label label_Count;
        private System.Windows.Forms.Button btn_ViewGradeStat;
        private System.Windows.Forms.ListBox listBox_MinGPA;
        private System.Windows.Forms.TextBox Box_MinGPA;
        private System.Windows.Forms.Button btn_ShowRecord;
        private System.Windows.Forms.Label labelMinGPA;
        private System.Windows.Forms.ListBox listBox_HighGPA;
        private System.Windows.Forms.Button btn_HighGPA;
        private System.Windows.Forms.DataGridView dataGridView;
        private CartmanCollegeDataSet1 cartmanCollegeDataSet1;
        private System.Windows.Forms.BindingSource tblStudentsBindingSource;
        private CartmanCollegeDataSet1TableAdapters.tblStudentsTableAdapter tblStudentsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gradePointAverageDataGridViewTextBoxColumn;
    }
}