﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DatabaseQuery_Monta
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cartmanCollegeDataSet1.tblStudents' table. You can move, or remove it, as needed.
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet1.tblStudents);

        }

        //1
        private void btn_HighGPA_Click(object sender, EventArgs e)
        {
            listBox_HighGPA.Items.Clear();
            const double CUTOFF = 3.00;
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet1.tblStudents);
            var goodStudents =
                from s in this.cartmanCollegeDataSet1.tblStudents
                where s.GradePointAverage > CUTOFF
                orderby s.GradePointAverage descending
                select s;
            foreach (var s in goodStudents)
                listBox_HighGPA.Items.Add(s.LastName + " " + s.FirstName);
        }

        //2
        private void btn_ShowRecord_Click(object sender, EventArgs e)
        {
            listBox_MinGPA.Items.Clear();
            double minGPA = Convert.ToDouble(Box_MinGPA.Text);
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet1.tblStudents);
            var goodStudents =
                from s in this.cartmanCollegeDataSet1.tblStudents
                where s.GradePointAverage > minGPA
                orderby s.GradePointAverage descending
                select s;
            foreach (var s in goodStudents)
                listBox_MinGPA.Items.Add(s.LastName + " " + s.FirstName);
        }

        //3
        private void btn_ViewGradeStat_Click(object sender, EventArgs e)
        {
            var gpas =
                from s in this.cartmanCollegeDataSet1.tblStudents
                select s.GradePointAverage;
            label_Count.Text = "Count is " + "\t" + gpas.Count();
            label_Min.Text = "Lowest is " + "\t" + gpas.Min();
            label_Max.Text = "Highest is " + "\t" + gpas.Max();
            label_Average.Text = "Average of all GPAs is " + "\t" + gpas.Average();
        }

        //4
        private void btn_GroupByGPA_Click(object sender, EventArgs e)
        {
            listBox_GroupByGPA.Items.Clear();
            var studgpa =
                from s in this.cartmanCollegeDataSet1.tblStudents
                group s by (int)s.GradePointAverage;
            foreach (var GroupGPA in studgpa)
            {
                listBox_GroupByGPA.Items.Add("GPA: " + GroupGPA.Key);
                foreach (var s in GroupGPA)
                    listBox_GroupByGPA.Items.Add(" " + s.GradePointAverage + " " + s.LastName);
            }
        }
    }
}
