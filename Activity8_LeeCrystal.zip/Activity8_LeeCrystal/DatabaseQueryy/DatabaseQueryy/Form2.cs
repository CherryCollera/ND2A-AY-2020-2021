﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DatabaseQueryy
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cartmanCollegeDataSet1.tblStudents' table. You can move, or remove it, as needed.
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet1.tblStudents);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            const double CUTOFF = 3.00;
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet1.tblStudents);
            var goodStudents =
                from s in this.cartmanCollegeDataSet1.tblStudents
                where s.GradePointAverage > CUTOFF
                orderby s.GradePointAverage descending
                select s;
            foreach (var s in goodStudents)
                listBox2.Items.Add(s.LastName + " " + s.FirstName);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            listBox3.Items.Clear();
            double minGPA = Convert.ToDouble(textBox1.Text);
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet1.tblStudents);
            var goodStudents =
                from s in this.cartmanCollegeDataSet1.tblStudents
                where s.GradePointAverage > minGPA
                orderby s.GradePointAverage descending
                select s;
            foreach (var s in goodStudents)
                listBox3.Items.Add(s.LastName + ", " + s.FirstName);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var gpas =
               from s in this.cartmanCollegeDataSet1.tblStudents
               select s.GradePointAverage;
            label1.Text = " Count is " + "\t" + gpas.Count();
            label2.Text = " Lowest is " + "\t" + gpas.Min();
            label3.Text = " Highest is " + "\t" + gpas.Max();
            label4.Text = " Average of all GPAs is " + "\t" + gpas.Average();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            var studgpa =
                from s in this.cartmanCollegeDataSet1.tblStudents
                group s by (int)s.GradePointAverage;

            foreach (var GroupGPA in studgpa)
            {
                listBox1.Items.Add("GPA: " + GroupGPA.Key);
                foreach (var s in GroupGPA)
                    listBox1.Items.Add(" " + s.GradePointAverage + " " + s.LastName);
            }
        }
    }
}
