﻿/*
 19-04378
 Monta, Lorefe-Mae T.
 19-04013
 Sta. Niña Marie P. Sacdalan
 ND2A
 March 9. 2021
 This program will use Switch
*/

using System;

namespace Switch
{
    class Monta_Sacdalan
    {
        static void Main(string[] args)
        {
            string name;
            char gender;

            Console.Write("Enter Your Name: ");
            name = Console.ReadLine();
            Console.Write("Enter Your Gender M/F: ");
            gender = Convert.ToChar(Console.ReadLine());

            switch (gender)
            {

                case 'M': case 'm':
                    Console.WriteLine("\n Hi " + name + "!" + " Your Gender is Male!.");
                    break;
                case 'F': case 'f':
                    Console.WriteLine("\n Hi " + name + "!" + " Your Gender is Female!.");
                    break;
                default:
                    Console.WriteLine("\n Invalid Input... Try again...");
                    break;

            }

            Console.ReadKey();
        }
    }
}
