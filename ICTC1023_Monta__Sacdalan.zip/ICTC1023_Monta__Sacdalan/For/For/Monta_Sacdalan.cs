﻿/*
 19-04378
 Monta, Lorefe-Mae T.
 19-04013
 Sta. Niña Marie P. Sacdalan
 ND2A
 March 9. 2021
 This program will use For Loop
*/

using System;

namespace For
{
    class Monta_Sacdalan
    {
        static void Main(string[] args)
        {
            for (int i = 10 - 1; i >= 0; i--)
            {
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }
    }
}
