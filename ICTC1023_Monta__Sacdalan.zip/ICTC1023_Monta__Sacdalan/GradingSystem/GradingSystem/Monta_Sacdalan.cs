﻿/*
 19-04378
 Monta, Lorefe-Mae T.
 19-04013
 Sta. Niña Marie P. Sacdalan
 ND2A
 March 9. 2021
 This program will get the equivalent grade
*/

using System;

namespace GradingSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your final Grade : ");
            double gr = Convert.ToDouble(Console.ReadLine());
            double[] gra = {1.00, 1.25, 1.50, 1.75, 2.00, 2.25, 2.50, 2.75, 3.00, 4.00, 5.00};
            String[] rem = {"Excellent" , "Very Good" , "Good", "Fair" , "Passed" , "Conditional", "Failed", "Incomplete" };

            if (gr == 98 || gr == 99 || gr == 100)
            {
                Console.WriteLine("Grade equivalent : " + gra[0]);
                Console.WriteLine("Remarks :  " + rem[0]);
            }

            else if (gr == 95 || gr == 96 || gr == 97)
            {
                Console.WriteLine("Grade equivalent : " + gra[1]);
                Console.WriteLine("Remarks :  " + rem[1]);
            }

            else if (gr == 92 || gr == 93 || gr == 94)
            {
                Console.WriteLine("Grade equivalent : " + gra[2]);
                Console.WriteLine("Remarks :  " + rem[1]);
            }

            else if (gr == 89 || gr == 90 || gr == 91)
            {
                Console.WriteLine("Grade equivalent : " + gra[3]);
                Console.WriteLine("Remarks :  " + rem[1]);
            }

            else if (gr == 86 || gr == 87 || gr == 88)
            {
                Console.WriteLine("Grade equivalent : " + gra[4]);
                Console.WriteLine("Remarks :  " + rem[2]);
            }

            else if (gr == 83 || gr == 84 || gr == 85)
            {
                Console.WriteLine("Grade equivalent : " + gra[5]);
                Console.WriteLine("Remarks :  " + rem[2]);
            }

            else if (gr == 80 || gr == 81 || gr == 82)
            {
                Console.WriteLine("Grade equivalent : " + gra[6]);
                Console.WriteLine("Remarks :  " + rem[3]);
            }

            else if (gr == 77 || gr == 78 || gr == 79)
            {
                Console.WriteLine("Grade equivalent : " + gra[7]);
                Console.WriteLine("Remarks :  " + rem[4]);
            }

            else if ( gr == 75 || gr == 76)
            {
                Console.WriteLine("Grade equivalent : " + gra[8]);
                Console.WriteLine("Remarks :  " + rem[4]);
            }

            else if (gr == 72 || gr == 73 || gr == 74)
            {
                Console.WriteLine("Grade equivalent : " + gra[9]);
                Console.WriteLine("Remarks :  " + rem[5]);
            }

            else if (gr == 63 || gr == 64 || gr == 65 || gr == 66 || gr == 67 || gr == 68 || gr == 69 || gr == 70 || gr == 71)
            {
                Console.WriteLine("Grade equivalent : " + gra[10]);
                Console.WriteLine("Remarks :  " + rem[6]);
            }

            else if (gr == 60 || gr == 61 || gr == 62)
            {
                Console.WriteLine("Grade equivalent : " + gra[10]);
                Console.WriteLine("Remarks :  " + rem[6]);
            }

            else
            {
                Console.WriteLine("You are " + rem[7] + "!");
            }
        }
    }
}
