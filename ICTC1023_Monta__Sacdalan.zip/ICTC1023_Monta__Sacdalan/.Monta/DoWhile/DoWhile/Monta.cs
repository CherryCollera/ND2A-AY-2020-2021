﻿/*
 19-04378
 Monta, Lorefe-Mae T.
 ND2A
 March 9. 2021
 This program will use Do While Loop
*/

using System;

namespace DoWhile
{
    class Monta
    {
        static void Main(string[] args)
        {
            int[] LMTM03_nms = new int[] {6 , 7 , 8, 10};
            int LMTM03_sum = 0;
            int i = 0;

            do {
                LMTM03_sum += LMTM03_nms[i];
                i++;
            } while (i < 4);

            Console.WriteLine(LMTM03_sum);
            Console.ReadKey();
            
        }
    }
}
