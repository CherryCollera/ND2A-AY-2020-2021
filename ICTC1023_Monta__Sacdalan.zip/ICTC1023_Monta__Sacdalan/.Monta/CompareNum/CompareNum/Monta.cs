﻿/*
 19-04378
 Monta, Lorefe-Mae T.
 ND2A
 March 9. 2021
 This program will Compare 3 numbers
*/

using System;

namespace CompareNum
{
    class Monta
    {
        static void Main(string[] args)
        {
            int LMTM03_Num1, LMTM03_Num2, LMTM03_Num3;

            Console.Write("Enter first number: ");
            LMTM03_Num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter second number: ");
            LMTM03_Num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter third number: ");
            LMTM03_Num3 = Convert.ToInt32(Console.ReadLine());
            Console.Write("\n");

            if (LMTM03_Num1 == LMTM03_Num2 && LMTM03_Num3 > LMTM03_Num1 && LMTM03_Num3 > LMTM03_Num2)
            {
                Console.WriteLine("{0} is equal to {1}. ", LMTM03_Num2, LMTM03_Num1);
                Console.WriteLine("{0} is less than {1}. ", LMTM03_Num1, LMTM03_Num3);
                Console.WriteLine("{0} is less than {1}. ", LMTM03_Num2, LMTM03_Num3);
            }

            else if (LMTM03_Num1 == LMTM03_Num3 && LMTM03_Num2 > LMTM03_Num1 && LMTM03_Num2 > LMTM03_Num3)
            {
                Console.WriteLine("{0} is equal to {1}. ", LMTM03_Num3, LMTM03_Num1);
                Console.WriteLine("{0} is less than {1}. ", LMTM03_Num1, LMTM03_Num2);
                Console.WriteLine("{0} is less than {1}. ", LMTM03_Num3, LMTM03_Num2);
            }

            else if (LMTM03_Num2 == LMTM03_Num3 && LMTM03_Num1 > LMTM03_Num2 && LMTM03_Num1 > LMTM03_Num3)
            {
                Console.WriteLine("{0} is equal to {1}. ", LMTM03_Num3, LMTM03_Num2);
                Console.WriteLine("{0} is less than {1}. ", LMTM03_Num2, LMTM03_Num1);
                Console.WriteLine("{0} is less than {1}. ", LMTM03_Num3, LMTM03_Num1);
            }

            else if (LMTM03_Num1 > LMTM03_Num2 && LMTM03_Num1 > LMTM03_Num3)
            {
                Console.WriteLine("{0} is greater than {1} and {2}. ", LMTM03_Num1, LMTM03_Num2, LMTM03_Num3);
                Console.WriteLine("{0} is less than {1}. ", LMTM03_Num2, LMTM03_Num1);
                Console.WriteLine("{0} is less than {1}. ", LMTM03_Num3, LMTM03_Num1);
            }

            //equal 1st
            else if (LMTM03_Num1 == LMTM03_Num2 && LMTM03_Num1 > LMTM03_Num3 && LMTM03_Num2 > LMTM03_Num3)
            {
                Console.WriteLine("{0} is equal to {1}. ", LMTM03_Num1, LMTM03_Num2);
                Console.WriteLine("{0} is less than {1}. ", LMTM03_Num3, LMTM03_Num1);
                Console.WriteLine("{0} is less than {1}. ", LMTM03_Num3, LMTM03_Num2);
            }

            // end 1st 

            else if (LMTM03_Num2 > LMTM03_Num1 && LMTM03_Num2 > LMTM03_Num3)
            {
                Console.WriteLine("{0} is greater than {1} and {2}. ", LMTM03_Num2, LMTM03_Num1, LMTM03_Num3);
                Console.WriteLine("{0} is less than {1}. ", LMTM03_Num1, LMTM03_Num2);
                Console.WriteLine("{0} is less than {1}. ", LMTM03_Num3, LMTM03_Num2);
            }

            //equal 2nd
            else if (LMTM03_Num1 == LMTM03_Num3 && LMTM03_Num1 > LMTM03_Num2 && LMTM03_Num3 > LMTM03_Num2)
            {
                Console.WriteLine("{0} is equal to {1}. ", LMTM03_Num1, LMTM03_Num3);
                Console.WriteLine("{0} is less than {1}. ", LMTM03_Num2, LMTM03_Num1);
                Console.WriteLine("{0} is less than {1}. ", LMTM03_Num2, LMTM03_Num3);
            }

            //end equal 2nd

            else if (LMTM03_Num3 > LMTM03_Num1 && LMTM03_Num3 > LMTM03_Num2)
            {
                Console.WriteLine("{0} is greater than {1} and {2}. ", LMTM03_Num3, LMTM03_Num1, LMTM03_Num2);
                Console.WriteLine("{0} is less than {1}. ", LMTM03_Num1, LMTM03_Num3);
                Console.WriteLine("{0} is less than {1}. ", LMTM03_Num2, LMTM03_Num3);
            }

            //equal 3rd
            else if (LMTM03_Num2 == LMTM03_Num3 && LMTM03_Num2 > LMTM03_Num1 && LMTM03_Num3 > LMTM03_Num1)
                {
                    Console.WriteLine("{0} is equal to {1}. ", LMTM03_Num2, LMTM03_Num3);
                    Console.WriteLine("{0} is less than {1}. ", LMTM03_Num1, LMTM03_Num2);
                    Console.WriteLine("{0} is less than {1}. ", LMTM03_Num1, LMTM03_Num3);
                }

            //end equal 3rd
            else
                {
                    Console.WriteLine("{0}, {1} and {2} are equal. ", LMTM03_Num1, LMTM03_Num2, LMTM03_Num3);
                }
            
        }
    }
}
