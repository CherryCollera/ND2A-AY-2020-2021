﻿/*
 19-04378
 Monta, Lorefe-Mae T.
 19-04013
 Sta. Niña Marie P. Sacdalan
 ND2A
 March 9. 2021
 This program will use While Loop
*/

using System;

namespace While
{
    class Monta_Sacdalan
    {
        static void Main(string[] args)
        {
            int i = 0;
            while (i < 10)
            {
                Console.Write("While Statement ");
                Console.WriteLine(i);
                i++;
            }
        }
    }
}
