﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Calculator : Form
    {
        double num1, num2, ans;
        char op;
        private void button19_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + "0";
        }

        private void button14_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + "3";
        }

        private void button15_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + "2";
        }

        private void button16_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + "1";
        }

        private void button10_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + "6";
        }

        private void button11_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + "5";
        }

        private void button12_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + "4";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + "9";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + "8";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + "7";
        }

        private void BtnClearChar_Click(object sender, EventArgs e)
        {
            if (label1.TextLength > 0)
            {
                label1.Text = label1.Text.Substring(0, (label1.TextLength - 1));
            }
            else
            {
                MessageBox.Show("No Number.");
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            label1.Text = "";
            num1 = 0;
            num2 = 0;
            ans = 0;
            op = 'N';
        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            if (label1.Text == "")
            {
                MessageBox.Show("Error, Please Enter a number");
            }
            else
            {
                num1 = Convert.ToDouble(label1.Text);
                label1.Text = "";
                op = '+';
            }

        }

        private void btnMinus_Click(object sender, EventArgs e)
        {
            if (label1.Text == "")
            {
                MessageBox.Show("Error, Please Enter a number");
            }
            else
            {
                num1 = Convert.ToDouble(label1.Text);
                label1.Text = "";
                op = '-';
            }
        }

        private void btnTimes_Click(object sender, EventArgs e)
        {
            if (label1.Text == "")
            {
                MessageBox.Show("Error, Please Enter a number");
            }
            else
            {
                num1 = Convert.ToDouble(label1.Text);
                label1.Text = "";
                op = 'x';
            }
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            if (label1.Text == "")
            {
                MessageBox.Show("Error, Please Enter a number");
            }
            else
            {
                num1 = Convert.ToDouble(label1.Text);
                label1.Text = "";
                op = '/';
            }
             
        }

        private void btnModulo_Click(object sender, EventArgs e)
        {
            if (label1.Text == "")
            {
                MessageBox.Show("Error, Please Enter a number");
            }
            else
            {
                num1 = Convert.ToDouble(label1.Text);
                label1.Text = "";
                op = '%';
            }
            
        }

        private void btnEqual_Click(object sender, EventArgs e)
        {
            switch(op)
            {
                case '+':
                    num2 = Convert.ToDouble(label1.Text);
                    ans = num1 + num2;
                    label1.Text = ans.ToString();
                    break;
                case '-':
                    num2 = Convert.ToDouble(label1.Text);
                    ans = num1 - num2;
                    label1.Text = ans.ToString();
                    break;
                case 'x':
                    num2 = Convert.ToDouble(label1.Text);
                    ans = num1 * num2;
                    label1.Text = ans.ToString();
                    break;
                case '/':
                    num2 = Convert.ToDouble(label1.Text);
                    ans = num2 / num1;
                    label1.Text = ans.ToString();
                    break;
                case '%':
                    num2 = Convert.ToDouble(label1.Text);
                    ans = num2 % num1;
                    label1.Text = ans.ToString();
                    break;
                default:
                    MessageBox.Show("Error");
                    break;

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.Show();
            this.Hide();
        }

        public Calculator()
        {
            InitializeComponent();
        }

        private void button18_Click(object sender, EventArgs e)
        {
            label1.Text = label1.Text + ".";
        }
    }
}
