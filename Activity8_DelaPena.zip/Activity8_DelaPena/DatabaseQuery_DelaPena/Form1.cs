﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DatabaseQuery_DelaPena
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cartmanCollegeDataSet.tblStudents' table. You can move, or remove it, as needed.
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet.tblStudents);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBoxGroupBy.Items.Clear();
            var studGPA =
                from s in this.cartmanCollegeDataSet.tblStudents
                group s by (int)s.GradePointAverage;

            foreach (var groupGPA in studGPA)
            {
                listBoxGroupBy.Items.Add("GPA:  " + groupGPA.Key);
                foreach (var s in groupGPA)
                {
                    listBoxGroupBy.Items.Add("  " + s.GradePointAverage + "  " + s.LastName);
                }
            }
        }

        private void btnHighGPA_Click(object sender, EventArgs e)
        {
            listBox_HighGPA.Items.Clear();
            const double cutOff = 3.00;
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet.tblStudents);
            var passStudents =
                from s in this.cartmanCollegeDataSet.tblStudents
                where s.GradePointAverage > cutOff
                orderby s.GradePointAverage descending
                select s;
            foreach (var s in passStudents)
                listBox_HighGPA.Items.Add(s.LastName + " " + s.FirstName);
        }

        private void textBox_MinGPA_TextChanged(object sender, EventArgs e)
        {
            listBox_MinGPA.Items.Clear();
            double minGPA = Convert.ToDouble(textBox_MinGPA.Text);
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet.tblStudents);
            var aboveStudents =
                from s in this.cartmanCollegeDataSet.tblStudents
                where s.GradePointAverage > minGPA
                orderby s.GradePointAverage descending
                select s;
            foreach (var s in aboveStudents)
                listBox_MinGPA.Items.Add(s.LastName + " " + s.FirstName);
        }

        private void listBox_MinGPA_Enter(object sender, EventArgs e)
        {
            listBox_MinGPA.Items.Clear();
            double minGPA = Convert.ToDouble(textBox_MinGPA.Text);
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet.tblStudents);
            var aboveStudents =
                from s in this.cartmanCollegeDataSet.tblStudents
                where s.GradePointAverage > minGPA
                orderby s.GradePointAverage descending
                select s;
            foreach (var s in aboveStudents)
                listBox_MinGPA.Items.Add(s.LastName + " " + s.FirstName);
        }

        private void btnGradeStat_Click(object sender, EventArgs e)
        {
            labelCount.Text = "";
            labelMin.Text = "";
            labelMax.Text = "";
            labelAve.Text = "";
            var gStat =
                from s in this.cartmanCollegeDataSet.tblStudents
                select s.GradePointAverage;
            labelCount.Text = "Count is " + "\t" + gStat.Count();
            labelMin.Text = "Lowest is " + "\t" + gStat.Min();
            labelMax.Text = "Highest is " + "\t" + gStat.Max();
            labelAve.Text = "Average is " + "\t" + gStat.Average();

        }
    }
}
