﻿
namespace DatabaseQuery_DelaPena
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gradePointAverageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblStudentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cartmanCollegeDataSet = new DatabaseQuery_DelaPena.CartmanCollegeDataSet();
            this.tblStudentsTableAdapter = new DatabaseQuery_DelaPena.CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter();
            this.btnHighGPA = new System.Windows.Forms.Button();
            this.listBox_HighGPA = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_MinGPA = new System.Windows.Forms.TextBox();
            this.listBox_MinGPA = new System.Windows.Forms.ListBox();
            this.btnGradeStat = new System.Windows.Forms.Button();
            this.labelCount = new System.Windows.Forms.Label();
            this.labelMin = new System.Windows.Forms.Label();
            this.labelMax = new System.Windows.Forms.Label();
            this.labelAve = new System.Windows.Forms.Label();
            this.btnGroupByGPA = new System.Windows.Forms.Button();
            this.listBoxGroupBy = new System.Windows.Forms.ListBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.gradePointAverageDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentsBindingSource;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(448, 266);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // gradePointAverageDataGridViewTextBoxColumn
            // 
            this.gradePointAverageDataGridViewTextBoxColumn.DataPropertyName = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.HeaderText = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.Name = "gradePointAverageDataGridViewTextBoxColumn";
            // 
            // tblStudentsBindingSource
            // 
            this.tblStudentsBindingSource.DataMember = "tblStudents";
            this.tblStudentsBindingSource.DataSource = this.cartmanCollegeDataSet;
            // 
            // cartmanCollegeDataSet
            // 
            this.cartmanCollegeDataSet.DataSetName = "CartmanCollegeDataSet";
            this.cartmanCollegeDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudentsTableAdapter
            // 
            this.tblStudentsTableAdapter.ClearBeforeFill = true;
            // 
            // btnHighGPA
            // 
            this.btnHighGPA.Location = new System.Drawing.Point(12, 293);
            this.btnHighGPA.Name = "btnHighGPA";
            this.btnHighGPA.Size = new System.Drawing.Size(189, 26);
            this.btnHighGPA.TabIndex = 1;
            this.btnHighGPA.Text = "Students with High GPA";
            this.btnHighGPA.UseVisualStyleBackColor = true;
            this.btnHighGPA.Click += new System.EventHandler(this.btnHighGPA_Click);
            // 
            // listBox_HighGPA
            // 
            this.listBox_HighGPA.FormattingEnabled = true;
            this.listBox_HighGPA.Location = new System.Drawing.Point(11, 335);
            this.listBox_HighGPA.Name = "listBox_HighGPA";
            this.listBox_HighGPA.Size = new System.Drawing.Size(189, 95);
            this.listBox_HighGPA.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(257, 300);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Enter minimum GPA:";
            // 
            // textBox_MinGPA
            // 
            this.textBox_MinGPA.Location = new System.Drawing.Point(366, 298);
            this.textBox_MinGPA.Name = "textBox_MinGPA";
            this.textBox_MinGPA.Size = new System.Drawing.Size(94, 20);
            this.textBox_MinGPA.TabIndex = 4;
            this.textBox_MinGPA.TextChanged += new System.EventHandler(this.textBox_MinGPA_TextChanged);
            // 
            // listBox_MinGPA
            // 
            this.listBox_MinGPA.FormattingEnabled = true;
            this.listBox_MinGPA.Location = new System.Drawing.Point(271, 335);
            this.listBox_MinGPA.Name = "listBox_MinGPA";
            this.listBox_MinGPA.Size = new System.Drawing.Size(189, 95);
            this.listBox_MinGPA.TabIndex = 5;
            this.listBox_MinGPA.Enter += new System.EventHandler(this.listBox_MinGPA_Enter);
            // 
            // btnGradeStat
            // 
            this.btnGradeStat.Location = new System.Drawing.Point(490, 12);
            this.btnGradeStat.Name = "btnGradeStat";
            this.btnGradeStat.Size = new System.Drawing.Size(153, 26);
            this.btnGradeStat.TabIndex = 6;
            this.btnGradeStat.Text = "Grade Statistics";
            this.btnGradeStat.UseVisualStyleBackColor = true;
            this.btnGradeStat.Click += new System.EventHandler(this.btnGradeStat_Click);
            // 
            // labelCount
            // 
            this.labelCount.AutoSize = true;
            this.labelCount.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.labelCount.Location = new System.Drawing.Point(499, 55);
            this.labelCount.Name = "labelCount";
            this.labelCount.Size = new System.Drawing.Size(0, 13);
            this.labelCount.TabIndex = 7;
            // 
            // labelMin
            // 
            this.labelMin.AutoSize = true;
            this.labelMin.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.labelMin.Location = new System.Drawing.Point(499, 83);
            this.labelMin.Name = "labelMin";
            this.labelMin.Size = new System.Drawing.Size(0, 13);
            this.labelMin.TabIndex = 8;
            // 
            // labelMax
            // 
            this.labelMax.AutoSize = true;
            this.labelMax.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.labelMax.Location = new System.Drawing.Point(499, 113);
            this.labelMax.Name = "labelMax";
            this.labelMax.Size = new System.Drawing.Size(0, 13);
            this.labelMax.TabIndex = 9;
            this.labelMax.Click += new System.EventHandler(this.label4_Click);
            // 
            // labelAve
            // 
            this.labelAve.AutoSize = true;
            this.labelAve.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.labelAve.Location = new System.Drawing.Point(499, 147);
            this.labelAve.Name = "labelAve";
            this.labelAve.Size = new System.Drawing.Size(0, 13);
            this.labelAve.TabIndex = 10;
            // 
            // btnGroupByGPA
            // 
            this.btnGroupByGPA.Location = new System.Drawing.Point(489, 220);
            this.btnGroupByGPA.Name = "btnGroupByGPA";
            this.btnGroupByGPA.Size = new System.Drawing.Size(153, 26);
            this.btnGroupByGPA.TabIndex = 11;
            this.btnGroupByGPA.Text = "Group Records by GPA";
            this.btnGroupByGPA.UseVisualStyleBackColor = true;
            this.btnGroupByGPA.Click += new System.EventHandler(this.button3_Click);
            // 
            // listBoxGroupBy
            // 
            this.listBoxGroupBy.FormattingEnabled = true;
            this.listBoxGroupBy.Location = new System.Drawing.Point(489, 252);
            this.listBoxGroupBy.Name = "listBoxGroupBy";
            this.listBoxGroupBy.Size = new System.Drawing.Size(189, 186);
            this.listBoxGroupBy.TabIndex = 12;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(490, 44);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(188, 136);
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(746, 450);
            this.Controls.Add(this.listBoxGroupBy);
            this.Controls.Add(this.btnGroupByGPA);
            this.Controls.Add(this.labelAve);
            this.Controls.Add(this.labelMax);
            this.Controls.Add(this.labelMin);
            this.Controls.Add(this.labelCount);
            this.Controls.Add(this.btnGradeStat);
            this.Controls.Add(this.listBox_MinGPA);
            this.Controls.Add(this.textBox_MinGPA);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox_HighGPA);
            this.Controls.Add(this.btnHighGPA);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Database Query Dela Pena";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CartmanCollegeDataSet cartmanCollegeDataSet;
        private System.Windows.Forms.BindingSource tblStudentsBindingSource;
        private CartmanCollegeDataSetTableAdapters.tblStudentsTableAdapter tblStudentsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gradePointAverageDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btnHighGPA;
        private System.Windows.Forms.ListBox listBox_HighGPA;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_MinGPA;
        private System.Windows.Forms.ListBox listBox_MinGPA;
        private System.Windows.Forms.Button btnGradeStat;
        private System.Windows.Forms.Label labelCount;
        private System.Windows.Forms.Label labelMin;
        private System.Windows.Forms.Label labelMax;
        private System.Windows.Forms.Label labelAve;
        private System.Windows.Forms.Button btnGroupByGPA;
        private System.Windows.Forms.ListBox listBoxGroupBy;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

