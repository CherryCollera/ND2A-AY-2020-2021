﻿
namespace DatabaseQuery_Ocasiones
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gradePointAverageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblStudentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cartmanCollegeDataSet1 = new DatabaseQuery_Ocasiones.CartmanCollegeDataSet1();
            this.tblStudentsTableAdapter = new DatabaseQuery_Ocasiones.CartmanCollegeDataSet1TableAdapters.tblStudentsTableAdapter();
            this.Btn_High = new System.Windows.Forms.Button();
            this.Btn_Stat = new System.Windows.Forms.Button();
            this.textBox_min = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.listBox_high = new System.Windows.Forms.ListBox();
            this.listBox_min = new System.Windows.Forms.ListBox();
            this.listBox_group = new System.Windows.Forms.ListBox();
            this.label_low = new System.Windows.Forms.Label();
            this.label_high = new System.Windows.Forms.Label();
            this.label_avg = new System.Windows.Forms.Label();
            this.label_count = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.gradePointAverageDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 100);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(453, 284);
            this.dataGridView1.TabIndex = 0;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // gradePointAverageDataGridViewTextBoxColumn
            // 
            this.gradePointAverageDataGridViewTextBoxColumn.DataPropertyName = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.HeaderText = "GradePointAverage";
            this.gradePointAverageDataGridViewTextBoxColumn.Name = "gradePointAverageDataGridViewTextBoxColumn";
            this.gradePointAverageDataGridViewTextBoxColumn.Width = 115;
            // 
            // tblStudentsBindingSource
            // 
            this.tblStudentsBindingSource.DataMember = "tblStudents";
            this.tblStudentsBindingSource.DataSource = this.cartmanCollegeDataSet1;
            // 
            // cartmanCollegeDataSet1
            // 
            this.cartmanCollegeDataSet1.DataSetName = "CartmanCollegeDataSet1";
            this.cartmanCollegeDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudentsTableAdapter
            // 
            this.tblStudentsTableAdapter.ClearBeforeFill = true;
            // 
            // Btn_High
            // 
            this.Btn_High.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(57)))), ((int)(((byte)(57)))));
            this.Btn_High.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_High.ForeColor = System.Drawing.SystemColors.Window;
            this.Btn_High.Location = new System.Drawing.Point(12, 411);
            this.Btn_High.Name = "Btn_High";
            this.Btn_High.Size = new System.Drawing.Size(219, 39);
            this.Btn_High.TabIndex = 2;
            this.Btn_High.Text = "Show Students with Highest GPA";
            this.Btn_High.UseVisualStyleBackColor = false;
            this.Btn_High.Click += new System.EventHandler(this.Btn_High_Click);
            // 
            // Btn_Stat
            // 
            this.Btn_Stat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(57)))), ((int)(((byte)(57)))));
            this.Btn_Stat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Stat.ForeColor = System.Drawing.SystemColors.Window;
            this.Btn_Stat.Location = new System.Drawing.Point(246, 411);
            this.Btn_Stat.Name = "Btn_Stat";
            this.Btn_Stat.Size = new System.Drawing.Size(219, 39);
            this.Btn_Stat.TabIndex = 5;
            this.Btn_Stat.Text = "View Grade Statistics";
            this.Btn_Stat.UseVisualStyleBackColor = false;
            this.Btn_Stat.Click += new System.EventHandler(this.Btn_Stat_Click);
            // 
            // textBox_min
            // 
            this.textBox_min.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_min.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_min.Location = new System.Drawing.Point(478, 117);
            this.textBox_min.Margin = new System.Windows.Forms.Padding(10, 3, 3, 3);
            this.textBox_min.Name = "textBox_min";
            this.textBox_min.Size = new System.Drawing.Size(229, 22);
            this.textBox_min.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cambria", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(42, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(402, 57);
            this.label1.TabIndex = 15;
            this.label1.Text = "DATABASE QUERY";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(57)))), ((int)(((byte)(57)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.SystemColors.Window;
            this.button2.Location = new System.Drawing.Point(713, 117);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(135, 22);
            this.button2.TabIndex = 16;
            this.button2.Text = "Show Records";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.Btn_Show_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.Window;
            this.label2.Location = new System.Drawing.Point(475, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "Enter Minimum GPA:";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(57)))), ((int)(((byte)(57)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.SystemColors.Window;
            this.button3.Location = new System.Drawing.Point(556, 411);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(229, 39);
            this.button3.TabIndex = 18;
            this.button3.Text = "Group Records by GPA";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.Btn_Grp_Click);
            // 
            // listBox_high
            // 
            this.listBox_high.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.listBox_high.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listBox_high.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox_high.ForeColor = System.Drawing.SystemColors.Window;
            this.listBox_high.FormattingEnabled = true;
            this.listBox_high.ItemHeight = 15;
            this.listBox_high.Location = new System.Drawing.Point(12, 460);
            this.listBox_high.Name = "listBox_high";
            this.listBox_high.Size = new System.Drawing.Size(218, 182);
            this.listBox_high.TabIndex = 19;
            // 
            // listBox_min
            // 
            this.listBox_min.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.listBox_min.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listBox_min.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox_min.ForeColor = System.Drawing.SystemColors.Window;
            this.listBox_min.FormattingEnabled = true;
            this.listBox_min.ItemHeight = 15;
            this.listBox_min.Location = new System.Drawing.Point(478, 157);
            this.listBox_min.Name = "listBox_min";
            this.listBox_min.Size = new System.Drawing.Size(370, 227);
            this.listBox_min.TabIndex = 20;
            // 
            // listBox_group
            // 
            this.listBox_group.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.listBox_group.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listBox_group.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox_group.ForeColor = System.Drawing.SystemColors.Window;
            this.listBox_group.FormattingEnabled = true;
            this.listBox_group.ItemHeight = 15;
            this.listBox_group.Location = new System.Drawing.Point(478, 460);
            this.listBox_group.Name = "listBox_group";
            this.listBox_group.Size = new System.Drawing.Size(370, 182);
            this.listBox_group.TabIndex = 21;
            // 
            // label_low
            // 
            this.label_low.AutoSize = true;
            this.label_low.ForeColor = System.Drawing.SystemColors.Window;
            this.label_low.Location = new System.Drawing.Point(289, 529);
            this.label_low.Name = "label_low";
            this.label_low.Size = new System.Drawing.Size(127, 13);
            this.label_low.TabIndex = 22;
            this.label_low.Text = "xxxxxxxxxxxxxxxxxxxxxxxx";
            // 
            // label_high
            // 
            this.label_high.AutoSize = true;
            this.label_high.ForeColor = System.Drawing.SystemColors.Window;
            this.label_high.Location = new System.Drawing.Point(289, 571);
            this.label_high.Name = "label_high";
            this.label_high.Size = new System.Drawing.Size(127, 13);
            this.label_high.TabIndex = 23;
            this.label_high.Text = "xxxxxxxxxxxxxxxxxxxxxxxx";
            // 
            // label_avg
            // 
            this.label_avg.AutoSize = true;
            this.label_avg.ForeColor = System.Drawing.SystemColors.Window;
            this.label_avg.Location = new System.Drawing.Point(289, 612);
            this.label_avg.Name = "label_avg";
            this.label_avg.Size = new System.Drawing.Size(127, 13);
            this.label_avg.TabIndex = 24;
            this.label_avg.Text = "xxxxxxxxxxxxxxxxxxxxxxxx";
            // 
            // label_count
            // 
            this.label_count.AutoSize = true;
            this.label_count.ForeColor = System.Drawing.SystemColors.Window;
            this.label_count.Location = new System.Drawing.Point(289, 487);
            this.label_count.Name = "label_count";
            this.label_count.Size = new System.Drawing.Size(127, 13);
            this.label_count.TabIndex = 25;
            this.label_count.Text = "xxxxxxxxxxxxxxxxxxxxxxxx";
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(57)))), ((int)(((byte)(57)))));
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.ForeColor = System.Drawing.SystemColors.Window;
            this.button7.Location = new System.Drawing.Point(824, 361);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(24, 23);
            this.button7.TabIndex = 28;
            this.button7.Text = "C";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.Btn_C_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(57)))), ((int)(((byte)(57)))));
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.ForeColor = System.Drawing.SystemColors.Window;
            this.button6.Location = new System.Drawing.Point(637, 648);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(97, 30);
            this.button6.TabIndex = 27;
            this.button6.Text = "Clear All";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.Btn_Clearall_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(57)))), ((int)(((byte)(57)))));
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.ForeColor = System.Drawing.SystemColors.Window;
            this.button5.Location = new System.Drawing.Point(751, 648);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(97, 30);
            this.button5.TabIndex = 26;
            this.button5.Text = "Close";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.Btn_Close_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(19)))));
            this.ClientSize = new System.Drawing.Size(863, 687);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.label_count);
            this.Controls.Add(this.label_avg);
            this.Controls.Add(this.label_high);
            this.Controls.Add(this.label_low);
            this.Controls.Add(this.listBox_group);
            this.Controls.Add(this.listBox_min);
            this.Controls.Add(this.listBox_high);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox_min);
            this.Controls.Add(this.Btn_Stat);
            this.Controls.Add(this.Btn_High);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form2";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cartmanCollegeDataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CartmanCollegeDataSet1 cartmanCollegeDataSet1;
        private System.Windows.Forms.BindingSource tblStudentsBindingSource;
        private CartmanCollegeDataSet1TableAdapters.tblStudentsTableAdapter tblStudentsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gradePointAverageDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button Btn_High;
        private System.Windows.Forms.Button Btn_Stat;
        private System.Windows.Forms.TextBox textBox_min;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ListBox listBox_high;
        private System.Windows.Forms.ListBox listBox_min;
        private System.Windows.Forms.ListBox listBox_group;
        private System.Windows.Forms.Label label_low;
        private System.Windows.Forms.Label label_high;
        private System.Windows.Forms.Label label_avg;
        private System.Windows.Forms.Label label_count;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
    }
}