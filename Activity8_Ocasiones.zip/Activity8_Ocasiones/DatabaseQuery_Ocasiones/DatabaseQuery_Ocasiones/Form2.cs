﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DatabaseQuery_Ocasiones
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cartmanCollegeDataSet1.tblStudents' table. You can move, or remove it, as needed.
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet1.tblStudents);

        }
        //Show Students with Highest GPA button
        private void Btn_High_Click(object sender, EventArgs e)
        {
            listBox_high.Items.Clear();
            const double stand = 3.00;
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet1.tblStudents);

            var highestStudents =
                from h in this.cartmanCollegeDataSet1.tblStudents
                where h.GradePointAverage > stand
                orderby h.GradePointAverage descending
                select h;

            foreach (var h in highestStudents)
                listBox_high.Items.Add(h.LastName + ", " + h.FirstName);
        }
        //Show Records button
        private void Btn_Show_Click(object sender, EventArgs e)
        {
            listBox_min.Items.Clear();
            double MinGPA = Convert.ToDouble(textBox_min.Text);
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet1.tblStudents);

            var minStudents =
                from m in this.cartmanCollegeDataSet1.tblStudents
                where m.GradePointAverage > MinGPA
                orderby m.GradePointAverage descending
                select m;

            foreach (var h in minStudents)
                listBox_min.Items.Add(h.LastName + ", " + h.FirstName);
        }
        // View Grade Statistics button
        private void Btn_Stat_Click(object sender, EventArgs e)
        {
            var stat =
                from s in this.cartmanCollegeDataSet1.tblStudents
                select s.GradePointAverage;

            label_count.Text = "Count is " + stat.Count();
            label_high.Text = "The highest GPA is " + stat.Max();
            label_low.Text = "The lowest GPA is " + stat.Min();
            label_avg.Text = "The average GPA is " + stat.Average();
        }
        //Show Group Records button
        private void Btn_Grp_Click(object sender, EventArgs e)
        {
            listBox_group.Items.Clear();
            var listGPA =
                from g in this.cartmanCollegeDataSet1.tblStudents
                group g by (int)g.GradePointAverage;

            foreach (var grpGPA in listGPA)
            {
                listBox_group.Items.Add("GPA: " + grpGPA.Key);

                foreach (var g in grpGPA)
                    listBox_group.Items.Add("   " + g.GradePointAverage + " " + g.LastName);
            }
        }
        //Close Button
        private void Btn_Close_Click(object sender, EventArgs e)
        {
            DialogResult choice = MessageBox.Show("Are you sure you want to close the Program?", "Exit", MessageBoxButtons.YesNo);
            if (choice == DialogResult.Yes)
            {
                Application.ExitThread();
            }
            else if (choice == DialogResult.No)
            {
            }
        }
        //ClearAll button
        private void Btn_Clearall_Click(object sender, EventArgs e)
        {
            listBox_high.Items.Clear();
            listBox_min.Items.Clear();
            listBox_group.Items.Clear();
            textBox_min.Text = string.Empty;
            label_avg.Text = "xxxxxxxxxxxxxxxxxxxxxxxx";
            label_count.Text = "xxxxxxxxxxxxxxxxxxxxxxxx";
            label_high.Text = "xxxxxxxxxxxxxxxxxxxxxxxx";
            label_low.Text = "xxxxxxxxxxxxxxxxxxxxxxxx";
        }
        //Clear Button for Show Records
        private void Btn_C_Click(object sender, EventArgs e)
        {
            listBox_min.Items.Clear();
            textBox_min.Text = string.Empty;
        }
    }
}
