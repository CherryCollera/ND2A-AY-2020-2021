﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DatabaseQuery_Ocasiones
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cartmanCollegeDataSet.tblStudents' table. You can move, or remove it, as needed.
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet.tblStudents);

        }
        //Show Students with Highest GPA button
        private void Btn_Highest(object sender, EventArgs e)
        {
            lb_highest.Items.Clear();
            const double stand = 3.00;
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet.tblStudents);

            var highestStudents =
                from h in this.cartmanCollegeDataSet.tblStudents
                where h.GradePointAverage > stand
                orderby h.GradePointAverage descending
                select h;

            foreach (var h in highestStudents)
                lb_highest.Items.Add(h.LastName + ", " + h.FirstName);
        }
        //View Grade Statistics button
        private void Btn_Statistics(object sender, EventArgs e)
        {
            var stat =
                from s in this.cartmanCollegeDataSet.tblStudents
                select s.GradePointAverage;

            label_count.Text = "Count is " + stat.Count();
            label_highest.Text = "The highest GPA is " + stat.Max();
            label_lowest.Text = "The lowest GPA is " + stat.Min();
            label_avg.Text = "The average GPA is " + stat.Average();
        }
        //Show Records button
        private void Btn_ShowRecords(object sender, EventArgs e)
        {
            lb_min.Items.Clear();
            double MinGPA = Convert.ToDouble(textBox_min.Text);
            this.tblStudentsTableAdapter.Fill(this.cartmanCollegeDataSet.tblStudents);

            var minStudents =
                from m in this.cartmanCollegeDataSet.tblStudents
                where m.GradePointAverage > MinGPA
                orderby m.GradePointAverage descending
                select m;

            foreach (var h in minStudents)
                lb_min.Items.Add(h.LastName + ", " + h.FirstName);
        }
        //Show Group Records button
        private void Btn_GrpRecords(object sender, EventArgs e)
        {
            lb_grpGPA.Items.Clear();
            var listGPA =
                from g in this.cartmanCollegeDataSet.tblStudents
                group g by (int)g.GradePointAverage;

            foreach (var grpGPA in listGPA)
            {
                lb_grpGPA.Items.Add("GPA: " + grpGPA.Key);

                foreach (var g in grpGPA)
                    lb_grpGPA.Items.Add("   "+g.GradePointAverage + " " + g.LastName);
            }
        }

        private void Btn_Close(object sender, EventArgs e)
        {
            DialogResult choice = MessageBox.Show("Are you sure you want to close the Program?", "Exit", MessageBoxButtons.YesNo);
            if (choice == DialogResult.Yes)
            {
                Application.ExitThread();
            }
            else if (choice == DialogResult.No)
            {
            }
        }

        private void Btn_ClearAll(object sender, EventArgs e)
        {
            lb_grpGPA.Items.Clear();
            lb_min.Items.Clear();
            lb_highest.Items.Clear();
            textBox_min.Text = string.Empty;
            label_avg.Text = "---------------------------------------------";
            label_count.Text = "---------------------------------------------";
            label_highest.Text = "---------------------------------------------";
            label_lowest.Text = "---------------------------------------------";
        }

        private void Btn_ClearMin(object sender, EventArgs e)
        {
            lb_min.Items.Clear();
            textBox_min.Text = string.Empty;
        }
    }
}
