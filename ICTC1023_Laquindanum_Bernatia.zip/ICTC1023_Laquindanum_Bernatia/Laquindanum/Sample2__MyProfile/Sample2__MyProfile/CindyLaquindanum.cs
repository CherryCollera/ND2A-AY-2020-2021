﻿/* 19-04418
Laquindanum, Cindy M.
ND2A
This program will display "Name, Date of Birth, Course, Year and section */

using System;

namespace Sample2__MyProfile
{
    class CindyLaquindanum
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Name: " + " Cindy M. Laquindanum");
            Console.WriteLine("Birthdate: " + " August 01, 2000");
            Console.WriteLine("Course: " + " BS Computer Science");
            Console.WriteLine("Year and Section: " + " 2nd year Network and Data Communication");
            Console.ReadLine();
        }
    }
}
