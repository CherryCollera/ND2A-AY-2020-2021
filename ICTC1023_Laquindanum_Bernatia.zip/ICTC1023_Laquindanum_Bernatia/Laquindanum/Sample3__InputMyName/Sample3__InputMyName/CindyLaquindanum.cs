﻿/* 19-04418 
Laquindanum, Cindy M.  
ND2A
This program will Input the Name of the User*/

using System;

namespace Sample3__InputMyName
{
    class CindyLaquindanum
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your FirstName and LastName: ");
            string Name = Console.ReadLine();
            Console.WriteLine("Hello " + Name + "!!!");
            Console.WriteLine("Welcome to OOP Environment");

        }
    }
}
