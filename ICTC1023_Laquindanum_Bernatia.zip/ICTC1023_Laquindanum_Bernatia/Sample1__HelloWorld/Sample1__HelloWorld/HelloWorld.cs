﻿/*19-04418 19-00740
Laquindanum, Cindy M.  Bernatia, Alliah V.
ND2A
This program will display "Hello World */


using System;

namespace Sample1__HelloWorld
{
    class HelloWorld
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.ReadKey();
        }
    }
}
