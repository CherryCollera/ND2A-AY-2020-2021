﻿/*19-00740
Bernatia, Alliah V.
ND2A
This program will display the Input of the Name of the User*/

using System;

namespace Sample03__InputMyName
{
    class AlliahBernatia
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your FirstName and LastName: ");
            string Name = Console.ReadLine();
            Console.WriteLine("Hello " + Name + "!!!");
            Console.WriteLine("Welcome to OOP Environment");
        }
    }
}
