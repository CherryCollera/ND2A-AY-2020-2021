﻿/*19-00740
Bernatia, Alliah V.
ND2A
This program will display "Name, Date of Birth, Course, Year and section */

using System;

namespace Sample02__MyProfile
{
    class AlliahBernatia
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Name: " + " Alliah V. Bernatia");
            Console.WriteLine("Birthdate: " + " October 07, 2000");
            Console.WriteLine("Course: " + " BS Computer Science");
            Console.WriteLine("Year and Section: " + " 2nd year Network and Data Communication");
            Console.ReadLine();
        }
    }
}
