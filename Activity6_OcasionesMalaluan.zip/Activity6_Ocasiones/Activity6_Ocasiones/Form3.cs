﻿using System;
using System.Windows.Forms;

namespace Activity6_Ocasiones
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btn_Integer_Click(object sender, EventArgs e)
        {
            int num = 19;
            MessageBox.Show(num.ToString());
        }

        private void btn_Float_Click(object sender, EventArgs e)
        {
            float num = 19.22F;
            MessageBox.Show(num.ToString());
        }

        private void btn_Double_Click(object sender, EventArgs e)
        {
            double num = 19.2202;
            MessageBox.Show(num.ToString());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int num1, num2, result;

            num1 = Convert.ToInt32(fnum.Text);
            num2 = Convert.ToInt32(snum.Text);
            result = num1 + num2;

            MessageBox.Show("The sum of the given values is " + Convert.ToString(result)+".");
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            fnum.Clear();
            snum.Clear();
        }
    }
}
