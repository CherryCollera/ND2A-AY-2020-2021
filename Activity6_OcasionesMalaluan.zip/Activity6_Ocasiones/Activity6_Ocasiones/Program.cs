﻿/* 19-03008
 * Ocasiones, Rovic Troy B.
 * Malaluan, Francis Vien
 * ND2A
 */

using System;
using System.Windows.Forms;

namespace Activity6_Ocasiones
{
    class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());

        }
    }
}
