﻿using System;
using System.Windows.Forms;

namespace Activity6_Ocasiones
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Message_Click(object sender, EventArgs e)
        {
            DialogResult btn = MessageBox.Show("HELLO!","This is My Message", MessageBoxButtons.YesNo,
                MessageBoxIcon.Information);
            if (btn == DialogResult.Yes)
            {
                Calculator calc = new Calculator();
                calc.Show();
                this.Hide();
            }
            else if (btn  == DialogResult.No)
            {
                
            }
        }
    }
}
