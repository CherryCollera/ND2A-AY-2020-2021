﻿
using System;
using System.Windows.Forms;

namespace Activity6_Ocasiones
{
    public partial class Calculator : Form
    {

        double result = 0;
        double total = 0;

        bool btn_Add_clicked = false;
        bool btn_Sub_clicked = false;
        bool btn_Mul_clicked = false;
        bool btn_Dvd_clicked = false;

        public Calculator()
        {
            InitializeComponent(); 
        }

        private void btn_zero_click(object sender, EventArgs e)
        {
            InputDisplay.Text += "0";
        }

        private void btn_one_click(object sender, EventArgs e)
        {
            if (InputDisplay.Text == "0" && InputDisplay.Text != null)
            {
                InputDisplay.Text = "1";
            }
            else
            {
                InputDisplay.Text += "1";
            }
        }

        private void btn_two_click(object sender, EventArgs e)
        {
            if (InputDisplay.Text == "0" && InputDisplay.Text != null)
            {
                InputDisplay.Text = "2";
            }
            else
            {
                InputDisplay.Text += "2";
            }
        }

        private void btn_three_click(object sender, EventArgs e)
        {
            if (InputDisplay.Text == "0" && InputDisplay.Text != null)
            {
                InputDisplay.Text = "3";
            }
            else
            {
                InputDisplay.Text += "3";
            }
        }
        private void btn_four_click(object sender, EventArgs e)
        {
            if (InputDisplay.Text == "0" && InputDisplay.Text != null)
            {
                InputDisplay.Text = "4";
            }
            else
            {
                InputDisplay.Text += "4";
            }
        }

        private void btn_five_click(object sender, EventArgs e)
        {
            if (InputDisplay.Text == "0" && InputDisplay.Text != null)
            {
                InputDisplay.Text = "5";
            }
            else
            {
                InputDisplay.Text += "5";
            }
        }

        private void btn_six_click(object sender, EventArgs e)
        {
            if (InputDisplay.Text == "0" && InputDisplay.Text != null)
            {
                InputDisplay.Text = "6";
            }
            else
            {
                InputDisplay.Text += "6";
            }
        }

        private void btn_seven_click(object sender, EventArgs e)
        {
            if(InputDisplay.Text == "0" && InputDisplay.Text != null)
            {
                InputDisplay.Text = "7";
            }
            else
            {
                InputDisplay.Text += "7";
            }
        }

        private void btn_eight_click(object sender, EventArgs e)
        {
            if (InputDisplay.Text == "0" && InputDisplay.Text != null)
            {
                InputDisplay.Text = "8";
            }
            else
            {
                InputDisplay.Text += "8";
            }
        }

        private void btn_nine_click(object sender, EventArgs e)
        {
            if (InputDisplay.Text == "0" && InputDisplay.Text != null)
            {
                InputDisplay.Text = "9";
            }
            else
            {
                InputDisplay.Text += "9";
            }
        }

        private void btn_Dot_click(object sender, EventArgs e)
        {
            InputDisplay.Text += ".";
        }

        private void btn_Add_click(object sender, EventArgs e)
        {
            total = double.Parse(InputDisplay.Text);
            InputDisplay.Clear();

            btn_Add_clicked = true;
            btn_Sub_clicked = false;
            btn_Mul_clicked = false;
            btn_Dvd_clicked = false;
        }

        private void btn_Sub_click(object sender, EventArgs e)
        {
            total =  double.Parse(InputDisplay.Text);
            InputDisplay.Clear();

            btn_Add_clicked = false;
            btn_Sub_clicked = true;
            btn_Mul_clicked = false;
            btn_Dvd_clicked = false;
        }

        private void btn_Mul_click(object sender, EventArgs e)
        {
            total =  double.Parse(InputDisplay.Text);
            InputDisplay.Clear();

            btn_Add_clicked = false;
            btn_Sub_clicked = false;
            btn_Mul_clicked = true;
            btn_Dvd_clicked = false;
        }

        private void btn_Dvd_click(object sender, EventArgs e)
        {
            total = double.Parse(InputDisplay.Text);
            InputDisplay.Clear();

            btn_Add_clicked = false;
            btn_Sub_clicked = false;
            btn_Mul_clicked = false;
            btn_Dvd_clicked = true;
        }

        private void btn_Equals_click(object sender, EventArgs e)
        {

            if (btn_Add_clicked == true)
            {
                result = total + double.Parse(InputDisplay.Text); 
            }
            else if (btn_Sub_clicked == true) 
            {
                result = total - double.Parse(InputDisplay.Text); 
            }
            else if (btn_Mul_clicked == true)
            {
                result = total * double.Parse(InputDisplay.Text);
            }
            else if (btn_Dvd_clicked == true)
            {
                result = total / double.Parse(InputDisplay.Text);
            }
            InputDisplay.Text = result.ToString();
            total = 0;
        }

        private void btn_Clear_click(object sender, EventArgs e)
        {
            InputDisplay.Clear();
        }

        private void btn_BackToForm1_click(object sender, EventArgs e)
        {
            Form1 btn = new Form1();
            btn.Show();
            this.Hide();
        }

        private void btn_GoToForm3_click(object sender, EventArgs e)
        {
            Form3 btn = new Form3();
            btn.Show();     
            this.Hide();    
        }
    }
}
