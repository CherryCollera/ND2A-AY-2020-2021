﻿using System;

namespace Act2_ComputingSumUsingDouble
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the First Number: ");
            double first = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter the Second Number: ");
            double second = Convert.ToDouble(Console.ReadLine());
          

            Console.WriteLine();
            Console.WriteLine("Total: " + (first + second));
        }
    }
}
