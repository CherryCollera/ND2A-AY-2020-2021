﻿using System;

namespace Act6_IfElse
{
    class Program
    {
        static void Main(string[] args)
        {
            int exit = 0;
            while (exit != 1)
            {
                Console.WriteLine();
                Console.WriteLine("Start \n Exit");
                Console.WriteLine();
                Console.Write("command: ");

                string choose = Console.ReadLine();

                Console.WriteLine();
                if (choose == "start" | choose == " start ")
                {
                    Console.Write("Enter First Number: ");
                    int first =
                    Convert.ToInt32(Console.ReadLine());
                    Console.Write("Enter Second Number: ");
                    int second =
                    Convert.ToInt32(Console.ReadLine());
                    Console.Write("Enter Third Number: ");
                    int third =
                    Convert.ToInt32(Console.ReadLine());
                    if (first > second && first > third)
                    {

                        Console.WriteLine(first + " is greater than " + second + " & " + third);

                    }
                    else if (second > first && second > third)
                    {
                        Console.WriteLine(second + " is greater than " + first + " & " + third);
                    }
                    else if (third > first && third > second)
                    {

                        Console.WriteLine(third + " is greater than" + first + " &" + second); ;
                    }
                }
                else if (choose == "Exit" | choose == " exit")
                {
                    exit++;
                }
            }
        }
    }
}
