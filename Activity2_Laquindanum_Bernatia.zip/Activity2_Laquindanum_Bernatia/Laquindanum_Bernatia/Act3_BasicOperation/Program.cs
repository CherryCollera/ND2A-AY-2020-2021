﻿using System;

namespace Act3_BasicOperation
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the First Number: ");
            int first = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the Second Number: ");
            int second = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine();

            Console.WriteLine("Addition: {0}", first + second);
            Console.WriteLine("Subtraction: {0}", first - second);
            Console.WriteLine("Multiplication: {0}", first * second);
            Console.WriteLine("Division: {0}", first / second);
            Console.WriteLine("Modulo: {0}", first % second);
        }
    }
}
