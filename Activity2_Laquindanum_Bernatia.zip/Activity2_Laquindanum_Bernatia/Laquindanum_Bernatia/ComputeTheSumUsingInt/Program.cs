﻿using System;

namespace ComputeTheSumUsingInt
{
    class Laquindanum_Cindy
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the First Number: ");
            int first = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the Second Number: ");
            int second = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine();
            Console.WriteLine("Total: {0} ", first + second);
        }
    }
}
