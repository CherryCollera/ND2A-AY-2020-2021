﻿/*
19-01923
Jefte R. Perdio
19-00359
John Henrich Dela Pena
BSCS ND2A
07/03/21
The  Program are intended to have a five grade input from the user and get the average of all grades with the specific format of "00.000"
 */

using System;
namespace ComputingGrades
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter First Grades : ");
            double num1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter second Grades : ");
            double num2 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Third Grades : ");
            double num3 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter fourth Grades : ");
            double num4 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Fifth Grades : ");
            double num5 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Total Average = {0:0.000}", (num1 + num2 + num3 + num4 + num5) / 5);
            Console.ReadLine();


        }
    }
}