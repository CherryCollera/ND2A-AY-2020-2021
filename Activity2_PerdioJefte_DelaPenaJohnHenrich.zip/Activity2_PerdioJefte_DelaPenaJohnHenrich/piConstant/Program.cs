﻿/*
19-01923
Jefte R. Perdio
19-00359
John Henrich Dela Pena
BSCS ND2A
07/03/21
The  Program are intended to have a five grade input from the user and get the average of all grades with the specific format of "00.000"
 */
using System;
namespace piConstant
{
    class Program
    {
        static void Main(string[] args)
        {
            const double pi = 3.14159;
            double radius;
            Console.Write("Enter Radius: ");
            radius = Convert.ToDouble(Console.ReadLine());
            Console.Write("The Area of the Circle is: {0:0.0000}", pi * (radius * radius));
            Console.ReadLine();
        }
    }
}
