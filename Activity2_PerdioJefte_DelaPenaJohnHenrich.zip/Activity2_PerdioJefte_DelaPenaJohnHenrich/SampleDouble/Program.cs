﻿/*
19-01923
Jefte R. Perdio
19-00359
John Henrich Dela Pena
BSCS ND2A
07/03/21
The  Program are intended to have a two input from the user having decimals and display the sum of it.
 */

using System;
namespace SampleDouble
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write(" Enter First Number : ");
            double num1 = Convert.ToDouble(Console.ReadLine());
            Console.Write(" Enter Second Number : ");
            double num2 = Convert.ToDouble(Console.ReadLine());
            //Format Specifier
            Console.Write(" Total {0} = ", num1 + num2);
            Console.ReadLine();
        }
    }
}
