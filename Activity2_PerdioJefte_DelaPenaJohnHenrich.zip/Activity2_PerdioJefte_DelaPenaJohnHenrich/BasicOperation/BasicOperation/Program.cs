﻿/*
19-01923
Jefte R. Perdio
19-00359
John Henrich Dela Pena
BSCS ND2A
07/03/21
The  Program are intended to do five basic math operation and display the result 
 */

using System;
class BasicOperation
{
    static void Main(string[] args)
    {
        double num1, num2;
        Console.Write("First number: ");
        num1 = Convert.ToDouble(Console.ReadLine());
        Console.Write("Second number: ");
        num2 = Convert.ToDouble(Console.ReadLine());
        Console.Write("The sum is {0} \n", num1 + num2);
        Console.Write("The difference is {0} \n", num1 - num2);
        Console.Write("The product is {0} \n", num1 * num2);
        Console.Write("The quotient is {0:0} \n", num2 / num1);
        Console.Write("The Remainder is {0} \n", num1 % num2);
        Console.ReadLine();

    }
}
