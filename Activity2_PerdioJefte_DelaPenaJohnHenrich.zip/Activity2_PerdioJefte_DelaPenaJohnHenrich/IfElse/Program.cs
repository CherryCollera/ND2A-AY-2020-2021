﻿/*
19-01923
Jefte R. Perdio
19-00359
John Henrich Dela Pena
BSCS ND2A
07/03/21
The  Program are intended to compare three input (integer) from the user and arrange them by descending order 
the first should be greater than with the next two input. 
 */

using System;
class HelloWorld
{
    static void Main(string[] args)
    {

        int num1, num2, num3;
        int holder = 0;

        Console.Write(" Enter First Number : ");
        num1 = Convert.ToInt32(Console.ReadLine());
        Console.Write(" Enter Second Number : ");
        num2 = Convert.ToInt32(Console.ReadLine());
        Console.Write(" Enter Third Number : ");
        num3 = Convert.ToInt32(Console.ReadLine());


        if (num2 > num1)
        {
            holder = num2;
            num2 = num1;
            num1 = holder;
        }
        if (num3 > num2)
        {
            holder = num3;
            num3 = num2;
            num2 = holder;

            if (num2 > num1)
            {
                holder = num2;
                num2 = num1;
                num1 = holder;
            }
        }

        Console.Write("{0} is greater than {1} and {2}", num1, num2, num3);
        Console.ReadLine();

    }
}

