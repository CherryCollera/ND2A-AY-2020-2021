﻿class DeclareVar
{
    public static double num1, num2, sumans, diff, prdct, quo, rem;
}