﻿using System;
class program
{
    static void Main(string[] args)
    {
        Input io = new Input();
        io.InputData();
        Sum s = new Sum();
        Difference d = new Difference();
        Product p = new Product();
        Quotient q = new Quotient();
        Remainder r = new Remainder();
        s.ComputeSum(DeclareVar.num1, DeclareVar.num2);
        d.ComputeDiff(DeclareVar.num1, DeclareVar.num2);
        p.ComputePrdct(DeclareVar.num1, DeclareVar.num2);
        q.ComputeQuo(DeclareVar.num1, DeclareVar.num2);
        r.ComputeRem(DeclareVar.num1, DeclareVar.num2);
        Console.WriteLine("Sum is " + DeclareVar.sumans);
        Console.WriteLine("Difference is " + DeclareVar.diff);
        Console.WriteLine("Product is " + DeclareVar.prdct);
        Console.WriteLine("Quotient is {0:0.000}", DeclareVar.quo);
        Console.WriteLine("Remainder is " + DeclareVar.rem);
        Console.ReadLine();
    }
}
