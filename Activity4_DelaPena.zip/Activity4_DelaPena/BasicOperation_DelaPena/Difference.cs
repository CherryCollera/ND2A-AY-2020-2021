﻿class Difference
{
    public void ComputeDiff(double num1, double num2)
    {
        DeclareVar.diff = num1 - num2;
    }
}