﻿class Quotient
{
    public void ComputeQuo(double num1, double num2)
    {
        DeclareVar.quo = num2 / num1;
    }
}