﻿class Product
{
    public void ComputePrdct(double num1, double num2)
    {
        DeclareVar.prdct = num1 * num2;
    }
}