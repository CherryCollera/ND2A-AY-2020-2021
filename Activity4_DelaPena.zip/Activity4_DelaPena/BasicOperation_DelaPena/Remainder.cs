﻿class Remainder
{
    public void ComputeRem(double num1, double num2)
    {
        DeclareVar.rem = num2 % num1;
    }
}