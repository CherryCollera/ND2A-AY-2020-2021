﻿using System;
class Input
{
    public void InputData()
    {

        System.Console.Write("First Number:  ");
        DeclareVar.num1 = Convert.ToDouble(Console.ReadLine());
        System.Console.Write("Second Number:  ");
        DeclareVar.num2 = Convert.ToDouble(Console.ReadLine());
    }
}