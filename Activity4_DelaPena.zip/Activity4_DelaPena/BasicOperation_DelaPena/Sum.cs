﻿class Sum
{
    public void ComputeSum(double num1, double num2)
    {
        DeclareVar.sumans = num1 + num2;
    }
}