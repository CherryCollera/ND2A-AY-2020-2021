﻿class MyProfile
{
    public void DisplayProfile()
    {
        System.Console.WriteLine("\n\t\tP R O F I L E");
        System.Console.WriteLine("\t\t--------------");
        System.Console.WriteLine("Name:\t\tDela Pena, John Henrich");
        System.Console.WriteLine("Birthday:\tNovember 28,2000");
        System.Console.WriteLine("Course:\t\tBSCS major in Network and Data");
        System.Console.WriteLine("Year:\t\t2nd Year");
        System.Console.WriteLine("Section:\tND2A");
        System.Console.ReadLine();
    }
}