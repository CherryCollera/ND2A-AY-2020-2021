﻿/*
Creating Class in OOP
Dela Pena, John Henrich
March 16, 2021
19-00359 ND2A
*/
using System;
namespace ClassExample_DelaPena
{
    class Program
    {
        static void Main(string[] args)
        {
            Print prt = new Print();
            prt.PrintDetails();
        }
    }
}
