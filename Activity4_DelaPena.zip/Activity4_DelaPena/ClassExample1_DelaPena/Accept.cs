﻿class Accept
{
    public string firstname, lastname;
    public void AcceptDetails()
    {
        System.Console.WriteLine("Enter your First Name and Last Name: ");
        firstname = System.Console.ReadLine();
        lastname = System.Console.ReadLine();
    }
}