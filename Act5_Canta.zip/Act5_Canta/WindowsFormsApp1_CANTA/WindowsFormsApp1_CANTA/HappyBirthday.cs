﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WindowsFormsApp1_CANTA
{
    class HappyBirthday
    {
        public string GetMessage(string firstname)
        {
            return "Happy Birthday" + firstname;
        }
    }
}
