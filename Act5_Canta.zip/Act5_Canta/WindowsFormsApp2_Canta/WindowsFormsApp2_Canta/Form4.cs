﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp2_Canta
{
    public partial class Form4 : Form
    {

        double a, b;
        
        
        public Form4()
        {
            InitializeComponent();
        }




        
        private void button5_Click(object sender, EventArgs e)
        {
            Form3 frm= new Form3();
            frm.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            a= Convert.ToDouble(textBox1.Text);
            b= Convert.ToDouble(textBox2.Text);
            textBox3.Text = (a + b).ToString();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            a = Convert.ToDouble(textBox1.Text);
            b = Convert.ToDouble(textBox1.Text);
            textBox3.Text = (a - b).ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            a = Convert.ToDouble(textBox1.Text);
            b = Convert.ToDouble(textBox1.Text);
            textBox3.Text = (a * b).ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            a = Convert.ToDouble(textBox1.Text);
            b = Convert.ToDouble(textBox1.Text);
            textBox3.Text = (a / b).ToString();


        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        
        private void Form4_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you want to quit ? ", "Exit Application", MessageBoxButtons.OKCancel);
            if (result == System.Windows.Forms.DialogResult.OK)
            {
                Application.Exit();
            }
            else
            {
                return;

            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }
    }
}
    
    
    


