﻿/*19-03008, 19-01840
 * Ocasiones, Rovic Troy
 * Malaluan, Francis Vien
 * ND2A
 * 2/23/2021
 * "The purpose of this code is to display the name, date of birth, course and year & section."
 */

using System;


namespace Sample2_MyProfile
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Rovic Troy B. Ocasiones");
            Console.WriteLine("March 19, 2001");
            Console.WriteLine("BSCS");
            Console.WriteLine("ND2A");
            Console.ReadKey();
            
        }
    }
}
