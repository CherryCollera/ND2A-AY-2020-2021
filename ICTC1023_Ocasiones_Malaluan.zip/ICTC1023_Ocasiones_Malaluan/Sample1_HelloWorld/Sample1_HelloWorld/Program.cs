﻿// 19-03008, 19-01840
// Ocasiones, Rovic Troy
// Malaluan, Francis Vien


using System;


namespace Sample1_HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.ReadKey();
        }
    }
}
