﻿/* 19-03008, 19-01840
 * Ocasiones, Rovic Troy
 * Malaluan, Francis Vien
 */

using System;


namespace Sample3_InputMyName
{
    class Program
    {
        static void Main(string[] args)
        {
            

            Console.Write("Enter your Name (FirstName LastName): ");
            String name = Console.ReadLine();
            
            Console.WriteLine("\nHello " + name);
            Console.WriteLine("Welcome to OOP Environment...");
            Console.ReadKey();
        }
    }
}
