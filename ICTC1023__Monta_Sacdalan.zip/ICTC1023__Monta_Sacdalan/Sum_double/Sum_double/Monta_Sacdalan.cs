﻿/* 19-04378
  Lorefe-Mae T. Monta
  19-04013
  Sta. Niña Marie P. Sacdalan
  ND2A
  March 2, 2021
  This program will display the sum of two numbers using double data type*/

using System;

namespace Sum_double
{
    class Monta_Sacdalan
    {
        static void Main(string[] args)
        {
            double num1, num2;
            Console.Write("Enter First Number: ");
            num1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            num2 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Sum = " + (num1 + num2));


        }
    }
}
