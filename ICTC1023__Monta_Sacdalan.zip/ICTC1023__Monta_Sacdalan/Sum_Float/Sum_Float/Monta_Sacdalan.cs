﻿/* 19-04378
  Lorefe-Mae T. Monta
  19-04013
  Sta. Niña Marie P. Sacdalan
  ND2A
  March 2, 2021
  This program will display the sum of two numbers using float data type*/

using System;

namespace Sum_Float
{
    class Monta_Sacdalan
    {
        static void Main(string[] args)
        {
            float num1, num2;
            Console.Write("Enter First Number: ");
            num1 = float.Parse(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            num2 = float.Parse(Console.ReadLine());
            Console.WriteLine("Sum = " + (num1 + num2));
        }
    }
}
