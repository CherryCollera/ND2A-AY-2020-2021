﻿/* 19-04378
  Lorefe-Mae T. Monta
  19-04013
  Sta. Niña Marie P. Sacdalan
  ND2A
  March 2, 2021
  This program will display the greates number among 3 input number*/


using System;

namespace IfElse
{
    class Monta_Sacdalan
    {
        static void Main(string[] args)
        {
            
            int num1, num2, num3;
            Console.Write("Enter first number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter second number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter third number: ");
            num3 = Convert.ToInt32(Console.ReadLine());

            if (num1 > num2 & num1 > num3)
            {
                Console.WriteLine(num1 + " is greater than " + num2 + " and " + num3);
            }

            else if (num2 > num1 & num2 > num3)
            {
                Console.WriteLine(num2 + " is greater than " + num1 + " and " + num3);
            }

            else if (num3 > num1 & num3 > num2)
            {
                Console.WriteLine(num3 + " is greater than " + num1 + " and " + num2);
            }

            else
            {
                Console.WriteLine("{0} is equal to {1} and {2}", num1 ,num2, num3);
            }

        }
    }
}
