﻿/* 19-04378
  Lorefe-Mae T. Monta
  19-04013
  Sta. Niña Marie P. Sacdalan
  ND2A
  March 2, 2021
  This program will display the average of the 5 grade that you input*/

using System;

namespace Computing_Grades
{
    class Monta_Sacdalan
    {
        static void Main(string[] args)
        {
            double[] grade = new double[5];
            string[] grad = { "first ", "second ", "third ", "fourth ", "fifth " };
            double compute = 0;
            double comp = 0;
            for (int i = 0; i < 5; i++)
            {
                Console.Write("Enter " + grad[i] + "Grade : ");
                grade[i] = Convert.ToDouble(Console.ReadLine());
                compute += grade[i];
            }
            comp = compute / 5;
            Console.WriteLine("The average grade is: " + comp);

        }
    }
}
