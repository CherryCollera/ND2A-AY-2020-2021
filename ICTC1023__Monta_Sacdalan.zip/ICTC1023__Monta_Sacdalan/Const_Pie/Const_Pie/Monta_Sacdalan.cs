﻿/* 19-04378
  Lorefe-Mae T. Monta
  19-04013
  Sta. Niña Marie P. Sacdalan
  ND2A
  February 23, 2021
  This program will display the area and radius of circle*/


using System;

namespace Const_Pie
{
    class Monta_Sacdalan
    {
        static void Main(string[] args)
        {
            float radius;
            double area;

            Console.Write("Enter the Radius: ");
            radius = float.Parse(Console.ReadLine());
            area = Math.PI * radius * radius;

            Console.WriteLine("Radius : " + Math.Round(radius, 4));
            Console.WriteLine("Area : " + Math.Round(area, 4));
        }
    }
}
