﻿/* 19-04378
  Lorefe-Mae T. Monta
  19-04013
  Sta. Niña Marie P. Sacdalan
  ND2A
  March 2, 2021
  This program will display the all the answer of two numbers using all the basic operation*/

using System;

namespace Basic_Operation
{
    class Monta_Sacdalan
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Console.Write("Enter First Number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Sum = " + (num1 + num2));
            Console.WriteLine("Difference = " + (num1 - num2));
            Console.WriteLine("Product = " + (num1 * num2));
            Console.WriteLine("Quotient = " + (num1 / num2));
            Console.WriteLine("Remainder = " + (num1 % num2));

        }
    }
}
