﻿/*using System;

namespace If_Condition 
{
    class Santos_CristanCarl
    {
        static void Main(string[] args)
        {
            
            int num1, num2, num3;
            Console.Write("Enter 1st num: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter 2nd num: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter 3rd num: ");
            num3 = Convert.ToInt32(Console.ReadLine());

            if (num1 > num2 & num1 > num3)
            {
                Console.WriteLine(num1 + " is greater than " + num2 + " and " + num3);
            }

            else if (num2 > num1 & num2 > num3)
            {
                Console.WriteLine(num2 + " is greater than " + num3 + " and " + num1);
            }

            else if (num3 > num1 & num3 > num2)
            {
                Console.WriteLine(num3 + " is greater than " + num1 + " and " + num2);
            }

            else
            {
                Console.WriteLine("{0} is equal to {1} and {2}", num1 ,num2, num3);
            }

        }
    }
}