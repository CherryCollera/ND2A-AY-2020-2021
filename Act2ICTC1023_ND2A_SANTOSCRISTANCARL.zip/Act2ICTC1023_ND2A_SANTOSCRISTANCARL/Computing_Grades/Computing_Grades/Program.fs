﻿/*using System;

namespace Computing_Grades
{
    class Santos_CristanCarl
    {
        static void Main(string[] args)
        {
            double[] grade = new double[5];
            string[] grades = { "1st", "2nd", "3rd", "4th", "5th" };
            double compute = 0;
            double computes = 0;
            for (int mp = 0; mp < 5; mp++)
            {
                Console.Write("Enter " + grades[mp] + "grade : ");
                grade[mp] = Convert.ToDouble(Console.ReadLine());
                compute += grades[mp];
            }
            comp = compute / 5;
            Console.WriteLine("The average grade is: " + comp);

        }
    }
}