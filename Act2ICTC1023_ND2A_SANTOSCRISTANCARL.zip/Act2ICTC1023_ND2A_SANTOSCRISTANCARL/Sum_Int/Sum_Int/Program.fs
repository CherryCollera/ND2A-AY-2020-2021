﻿/* 19-06678
Santos,CristanCarl
  ND2A
  March 2, 2021
  This program will display the sum of two numbers using int data type*/

using System;

namespace Sum_Int
{
 class Monta_Sacdalan
 {
     static void Main(string[] args)
     {
         int num1, num2;
         Console.Write("Enter First Number: ");
         num1 = Convert.ToInt32(Console.ReadLine());
         Console.Write("Enter Second Number: ");
         num2 = Convert.ToInt32(Console.ReadLine());
         Console.WriteLine("Sum = " + (num1 + num2));
     }
 }
}
