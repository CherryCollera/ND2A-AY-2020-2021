﻿
using ClassExample1_Laquindanum;
class Print
{
	public void PrintDetails()
	{
	Accept a = new Accept();
	a.AcceptDetails();
		System.Console.Write("Hello " + a.firstname + " " + a.lastname + "!!!\nYou have created classes on OOP");
		MyProfile mp = new MyProfile();
		mp.DisplayProfile();
	}
}
