﻿using System;
namespace ClassExample1_Laquindanum
{
	class Program
	{
		static void Main(string[] args)
		{
			Print p = new Print();
			p.PrintDetails();
			Console.ReadLine();
		}
	}
}
