﻿using System;
class MyProfile
{
	public void DisplayProfile()
	{
		System.Console.WriteLine("\n\n\n\t\t\t\tP R O F I L E");
		System.Console.WriteLine("Name:\t\t\tCindy Laquindanum");
		System.Console.WriteLine("Birthday:\t\tAugust 01, 2000");
		System.Console.WriteLine("Course:\t\t\tBS Computer Science Major in Network" + "and Data Communication");
		System.Console.WriteLine("Year:\t\t\t2nd Year");
		System.Console.WriteLine("Section:\t\t\tA");
		System.Console.ReadLine();

	}
}

