﻿
namespace BasicOperations_Laquindanum
{
	class Quotient
	{
		public void ComputeQuotient()
		{
			DeclareVar.quo = DeclareVar.num1 / DeclareVar.num2;
			System.Console.WriteLine("\n\tThe Quotient is " + DeclareVar.quo);
		}
	}
}
