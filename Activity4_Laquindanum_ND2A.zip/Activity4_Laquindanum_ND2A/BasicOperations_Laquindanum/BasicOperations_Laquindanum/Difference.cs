﻿
namespace BasicOperations_Laquindanum
{
	class Difference
	{
		public void ComputeDifference()
		{
			DeclareVar.diff = DeclareVar.num1 - DeclareVar.num2;
			System.Console.WriteLine("\n\tThe Difference is " + DeclareVar.diff);
		}
	}
}
