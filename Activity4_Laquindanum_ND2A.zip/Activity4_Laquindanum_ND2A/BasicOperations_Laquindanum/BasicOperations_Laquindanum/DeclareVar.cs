﻿
using BasicOperations_Laquindanum;

	class DeclareVar
	{
	public static double num1, num2, sum, diff, prod, quo, rem;
	}

