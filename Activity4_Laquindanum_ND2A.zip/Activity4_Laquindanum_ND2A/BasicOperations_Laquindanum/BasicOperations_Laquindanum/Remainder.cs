﻿
namespace BasicOperations_Laquindanum
{
	class Remainder
	{
		public void ComputeRemainder()
		{
			DeclareVar.rem = DeclareVar.num1 % DeclareVar.num2;
			System.Console.WriteLine("\n\tThe Remainder is " + DeclareVar.rem);
		}
	}
}
