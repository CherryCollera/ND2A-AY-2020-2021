﻿
namespace BasicOperations_Laquindanum
{
	class Product
	{
		public void ComputeProduct()
		{
			DeclareVar.prod = DeclareVar.num1 * DeclareVar.num2;
			System.Console.WriteLine("\n\tThe Product is " + DeclareVar.prod);
		}
	}
}
