﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsApp1_ManalacLee
{
    class HappyBirthday
    {
        public string GetMessage(string firstname)
        {
            return "Happy Birthday" + firstname;
        }
    }
}
