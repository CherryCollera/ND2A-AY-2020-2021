﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp2_Ocasiones
{
    public partial class Form4 : Form
    {
        double first, second;

        public Form4()
        {
            InitializeComponent();
        }

        private void btn_Division_Click(object sender, EventArgs e)
        {
            first = Convert.ToDouble(textBox1.Text);
            second = Convert.ToDouble(textBox2.Text);
            textBox3.Text = (first / second).ToString();
        }

        private void btn_Multiplication_Click(object sender, EventArgs e)
        {
            first = Convert.ToDouble(textBox1.Text);
            second = Convert.ToDouble(textBox2.Text);
            textBox3.Text = (first * second).ToString();
        }

        private void btn_Subtraction_Click(object sender, EventArgs e)
        {
            first = Convert.ToDouble(textBox1.Text);
            second = Convert.ToDouble(textBox2.Text);
            textBox3.Text = (first - second).ToString();
        }

        private void btn_Addition_Click(object sender, EventArgs e)
        {
            first = Convert.ToDouble(textBox1.Text);
            second = Convert.ToDouble(textBox2.Text);
            textBox3.Text = (first + second).ToString();
        }

        private void button_Clear_Click(object sender, EventArgs e)
        {
            textBox1.Text = ""; 
            textBox2.Text = "";
            textBox3.Text = "";

            //Clearing of TextBox
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            Form3 btn = new Form3();
            btn.Show();     // Show Form3
            this.Hide();    //Hide Form4
        }

        private void Form4_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult choice = MessageBox.Show("Are you sure want to close the Form 4?", "Exit", MessageBoxButtons.YesNo);
            if (choice == DialogResult.Yes)
            {
                Application.ExitThread();
            }
            else if (choice == DialogResult.No)
            {
                e.Cancel = true;
            }
        }

    }
}

