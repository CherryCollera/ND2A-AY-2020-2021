﻿
namespace WindowsFormsApp2_Ocasiones
{
    class HappyBirthday
    {
        public string GetMessage(string firstname)
        {

            return "Happy Birthday! " + firstname;
        
        }
    }
}
