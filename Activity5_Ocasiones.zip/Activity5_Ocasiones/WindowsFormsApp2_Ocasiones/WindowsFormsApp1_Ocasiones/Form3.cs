﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp2_Ocasiones
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private const int CP_NOCLOSE_BUTTON = 0x200;
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams myCp = base.CreateParams;
                myCp.ClassStyle = myCp.ClassStyle | CP_NOCLOSE_BUTTON;
                return myCp;
            }
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            Form2 btn = new Form2();
            btn.Show();     // Show Form2
            this.Hide();    //Hide Form3
        }

        private void btn_Next_Click(object sender, EventArgs e)
        {
            Form4 btn = new Form4();
            btn.Show();     // Show Form4
            this.Hide();    //Hide Form3
        }

        private void btn_GetMyProfile_Click(object sender, EventArgs e)
        {
            string firstName, lastName;

            firstName = textBox1.Text;
            lastName = textBox2.Text;

            MessageBox.Show("\t\tHello! "+firstName + " " + lastName + ".\t\t"+"\nDate of Birth\t\t:\tMarch 19, 2001"
                            +"\nCourse\t\t\t:\tBS Computer Science"+"\nYear\t\t\t:\tII"+"\nSection\t\t\t:\tA");
            
        }
    }
}
