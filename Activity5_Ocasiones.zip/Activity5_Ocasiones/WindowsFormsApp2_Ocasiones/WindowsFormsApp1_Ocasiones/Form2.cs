﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp2_Ocasiones
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btn_GetMessage_Click(object sender, EventArgs e)
        {
            string firstName, lastName;

            firstName = textBox1.Text;
            lastName = textBox2.Text;

            HappyBirthday rovic = new HappyBirthday();
            MessageBox.Show(rovic.GetMessage(firstName +" "+lastName+ "."));
        }

        private void btn_Hide_Click(object sender, EventArgs e)
        {
            Form3 btn = new Form3();
            btn.Show();     // Show Form3
            this.Hide();    //Hide Form2
        }

        //Disabling Close Button
        private const int CP_NOCLOSE_BUTTON = 0x200;
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams myCp = base.CreateParams;
                myCp.ClassStyle = myCp.ClassStyle | CP_NOCLOSE_BUTTON;
                return myCp;
            }
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            Form1 btn = new Form1();
            btn.Show();     // Show Form1
            this.Hide();    //Hide Form2
        }
    }
}
