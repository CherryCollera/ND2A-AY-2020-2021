﻿
using System;
using System.Windows.Forms;

namespace WindowsFormsApp2_Ocasiones
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_GetMessage_Click(object sender, EventArgs e)
        {
            HappyBirthday rovic = new HappyBirthday();
            MessageBox.Show(rovic.GetMessage("Rovic"));
            
        }

        //Disabling Close Button
        private const int CP_NOCLOSE_BUTTON = 0x200;
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams myCp = base.CreateParams;
                myCp.ClassStyle = myCp.ClassStyle | CP_NOCLOSE_BUTTON;
                return myCp;
            }
        }

        private void btn_Hide_Click(object sender, EventArgs e)
        {
            Form2 btn = new Form2();
            btn.Show();     // Show Form2
            this.Hide();    //Hide Form1
        }
    }
}
