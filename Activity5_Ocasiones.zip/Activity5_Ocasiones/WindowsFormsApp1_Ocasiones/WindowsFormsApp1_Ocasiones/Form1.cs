﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp1_Ocasiones
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Close_btn(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void getMessage_btn(object sender, EventArgs e)
        {
            HappyBirthday rovic = new HappyBirthday();
            MessageBox.Show(rovic.GetMessage("Rovic!!!"));
        }

        private const int CP_NOCLOSE_BUTTON = 0x200;
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams myCp = base.CreateParams;
                myCp.ClassStyle = myCp.ClassStyle | CP_NOCLOSE_BUTTON;
                return myCp;
            }
        }
    }
}
