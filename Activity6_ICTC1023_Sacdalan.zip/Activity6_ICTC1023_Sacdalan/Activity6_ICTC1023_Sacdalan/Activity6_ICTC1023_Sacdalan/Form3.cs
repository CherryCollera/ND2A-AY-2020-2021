﻿using System;
using System.Windows.Forms;

namespace Activity6_ICTC1023_Sacdalan
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btn_integer_Click(object sender, EventArgs e)
        {
            int number = 25;
            MessageBox.Show(number.ToString());
        }

        private void btn_float_Click(object sender, EventArgs e)
        {
            float number = 25.78F;
            MessageBox.Show(number.ToString());
        }

        private void btn_double_Click(object sender, EventArgs e)
        {
            double number = 25.7889;
            MessageBox.Show(number.ToString());
        }

        private void btn_ComputeSum_Click(object sender, EventArgs e)
        {
            int num1, num2, sum;

            num1 = Convert.ToInt32(txt_num1.Text);
            num2 = Convert.ToInt32(txt_num2.Text);

            sum = num1 + num2;

            MessageBox.Show("The sum is " + Convert.ToString(sum));

        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            frm.Show();
            this.Hide();
        }
    }
}
