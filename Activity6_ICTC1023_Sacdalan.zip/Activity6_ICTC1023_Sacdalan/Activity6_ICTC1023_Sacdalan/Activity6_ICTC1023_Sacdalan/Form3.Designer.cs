﻿namespace Activity6_ICTC1023_Sacdalan
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_back = new System.Windows.Forms.Button();
            this.btn_ComputeSum = new System.Windows.Forms.Button();
            this.txt_num2 = new System.Windows.Forms.TextBox();
            this.txt_num1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_double = new System.Windows.Forms.Button();
            this.btn_float = new System.Windows.Forms.Button();
            this.btn_integer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_back
            // 
            this.btn_back.Location = new System.Drawing.Point(275, 164);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(140, 30);
            this.btn_back.TabIndex = 17;
            this.btn_back.Text = "Back to Form 1";
            this.btn_back.UseVisualStyleBackColor = true;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // btn_ComputeSum
            // 
            this.btn_ComputeSum.Location = new System.Drawing.Point(120, 164);
            this.btn_ComputeSum.Name = "btn_ComputeSum";
            this.btn_ComputeSum.Size = new System.Drawing.Size(140, 30);
            this.btn_ComputeSum.TabIndex = 16;
            this.btn_ComputeSum.Text = "Compute Sum";
            this.btn_ComputeSum.UseVisualStyleBackColor = true;
            this.btn_ComputeSum.Click += new System.EventHandler(this.btn_ComputeSum_Click);
            // 
            // txt_num2
            // 
            this.txt_num2.Location = new System.Drawing.Point(393, 120);
            this.txt_num2.Name = "txt_num2";
            this.txt_num2.Size = new System.Drawing.Size(100, 20);
            this.txt_num2.TabIndex = 15;
            // 
            // txt_num1
            // 
            this.txt_num1.Location = new System.Drawing.Point(147, 120);
            this.txt_num1.Name = "txt_num1";
            this.txt_num1.Size = new System.Drawing.Size(100, 20);
            this.txt_num1.TabIndex = 14;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(272, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Enter Second Number:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 127);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Enter First Number:";
            // 
            // btn_double
            // 
            this.btn_double.Location = new System.Drawing.Point(358, 39);
            this.btn_double.Name = "btn_double";
            this.btn_double.Size = new System.Drawing.Size(140, 30);
            this.btn_double.TabIndex = 11;
            this.btn_double.Text = "Double";
            this.btn_double.UseVisualStyleBackColor = true;
            this.btn_double.Click += new System.EventHandler(this.btn_double_Click);
            // 
            // btn_float
            // 
            this.btn_float.Location = new System.Drawing.Point(203, 39);
            this.btn_float.Name = "btn_float";
            this.btn_float.Size = new System.Drawing.Size(140, 30);
            this.btn_float.TabIndex = 10;
            this.btn_float.Text = "Float";
            this.btn_float.UseVisualStyleBackColor = true;
            this.btn_float.Click += new System.EventHandler(this.btn_float_Click);
            // 
            // btn_integer
            // 
            this.btn_integer.Location = new System.Drawing.Point(47, 39);
            this.btn_integer.Name = "btn_integer";
            this.btn_integer.Size = new System.Drawing.Size(140, 30);
            this.btn_integer.TabIndex = 9;
            this.btn_integer.Text = "Integer";
            this.btn_integer.UseVisualStyleBackColor = true;
            this.btn_integer.Click += new System.EventHandler(this.btn_integer_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(549, 239);
            this.ControlBox = false;
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.btn_ComputeSum);
            this.Controls.Add(this.txt_num2);
            this.Controls.Add(this.txt_num1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_double);
            this.Controls.Add(this.btn_float);
            this.Controls.Add(this.btn_integer);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.Button btn_ComputeSum;
        private System.Windows.Forms.TextBox txt_num2;
        private System.Windows.Forms.TextBox txt_num1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_double;
        private System.Windows.Forms.Button btn_float;
        private System.Windows.Forms.Button btn_integer;
    }
}