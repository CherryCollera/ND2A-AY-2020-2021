﻿using System;
using System.Windows.Forms;

namespace Activity6_ICTC1023_Sacdalan
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_message_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Hello", "My Message", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

            if (result == DialogResult.Yes)
            {
                Calculator calc = new Calculator();
                calc.Show();
                this.Hide();
            }
            else
            {
                this.Close();
            }
        }
    }
}
