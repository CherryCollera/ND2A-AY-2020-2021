﻿
    class Difference
    {
        public void ComputeDifference()
        {
            DeclareVar.difference = DeclareVar.num1 - DeclareVar.num2;
        }
}

