﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BasicOperations_Sacdalan
{
    class Sum
    {
        public void ComputeSum()
        {
            Input i = new Input();
            i.InputData();

            DeclareVar.sum = DeclareVar.num1 + DeclareVar.num2;
        }
    }
}
