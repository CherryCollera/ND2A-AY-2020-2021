﻿/*
19-01923
Jefte R. Perdio
19-00359
John Henrich Dela Pena
BSCS ND2A
23/02/21
The  Program are intended to compare three number and display the  the highest number and compare to two number in descending order
display another line comparing the second least number to greatest number
another line for comparing the least number to greatest number
 */
using System;

public class Program
{
	public static void Main()
	{
		int num1, num2, num3;
		int holder = 0;
		Console.Write("Enter First Number: ");
		num1 = Convert.ToInt32(Console.ReadLine());
		Console.Write("Enter Second Number: ");
		num2 = Convert.ToInt32(Console.ReadLine());
		Console.Write("Enter Third Number: ");
		num3 = Convert.ToInt32(Console.ReadLine());
		if (num2 > num1 && num2 > num3)
		{
			holder = num2;
			num2 = num1;
			num1 = holder;
		}
		else if (num3 > num2 && num3 > num1)
		{
			holder = num3;
			num3 = num2;
			num2 = holder;

			if (num2 > num1)
			{
				holder = num2;
				num2 = num1;
				num1 = holder;
			}
		}
		else if (num1 == num2 && num2 == num3 && num3 == num1)
		{
			Console.WriteLine("{0} , {1} and {2} are Equal", num1, num2, num3);
			goto exit;
		}
		Console.WriteLine("{0} is greater than {1} and {2}", num1, num2, num3);
		Console.WriteLine("{0} is less than {1}", num2, num1);
		Console.WriteLine("{0} is less than {1}", num3, num1);
	exit:
		Console.ReadLine();
	}
}