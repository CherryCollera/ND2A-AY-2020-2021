﻿/*
19-01923
Jefte R. Perdio
19-00359
John Henrich Dela Pena
BSCS ND2A
23/02/21
The  Program are intended to add four numbers in a array and add it using do while loop
and display the result
 */
using System;
class HelloWorld
{
    static void Main()
    {
        int[] JHDP28_nms = new int[] { 6, 7, 8, 10 };
        int JHDP28_sum = 0;
        int i = 0;
        do
        {
            JHDP28_sum += JHDP28_nms[i];
        } while (i < 4);
        Console.WriteLine(JHDP28_sum);
        Console.ReadKey();
    }
}
