﻿/*
19-00359
John Henrich Dela Pena
19-01923
Jefte R. Perdio
BSCS ND2A
23/02/21
The  Program are intended to get a the final grade of user and transcribe
the grade to equivalent GPA and the remarks.
 */
using System;
public class HelloWorld
{
    public static void Main()
    {
        double fgrade = 0;
        string remark = "";
        Console.Write("Enter your Final Grade: ");
        string strgrade = Console.ReadLine();
        // propose solution for incomplete grade
        if (strgrade.Equals("INC") == true)
        {
            Console.WriteLine("Incomplete");
            goto exit;
        }
        int grade = Convert.ToInt32(strgrade);
        if (grade >= 98 && grade <= 100)
        {
            fgrade = 1.00;
            remark = "Excellent";
        }
        else if (grade >= 95 && grade <= 97)
        {
            fgrade = 1.25;
            remark = "Excellent";
        }
        else if (grade >= 92 && grade <= 94)
        {
            fgrade = 1.50;
            remark = "Very Good";
        }
        else if (grade >= 89 && grade <= 91)
        {
            fgrade = 1.75;
            remark = "Very Good";
        }
        else if (grade >= 86 && grade <= 88)
        {
            fgrade = 2.00;
            remark = "Good";
        }
        else if (grade >= 83 && grade <= 85)
        {
            fgrade = 2.25;
            remark = "Good";
        }
        else if (grade >= 80 && grade <= 82)
        {
            fgrade = 2.50;
            remark = "Fair";
        }
        else if (grade >= 77 && grade <= 79)
        {
            fgrade = 2.75;
            remark = "Passed";
        }
        else if (grade >= 75 && grade <= 76)
        {
            fgrade = 3.00;
            remark = "Passed";
        }
        else if (grade >= 72 && grade <= 74)
        {
            fgrade = 4.00;
            remark = "Conditional (MT Only)";
        }
        else if (grade >= 60 && grade <= 71)
        {
            fgrade = 5.00;
            remark = "Failed";
        }
        Console.WriteLine("Grade Equivalent: " + fgrade);
        Console.WriteLine("Remarks: " + remark);
    exit:
        Console.ReadLine();
    }
}
