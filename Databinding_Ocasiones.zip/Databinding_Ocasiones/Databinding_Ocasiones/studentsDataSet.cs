﻿namespace Databinding_Ocasiones
{


    partial class studentsDataSet
    {
    }
}

namespace Databinding_Ocasiones.studentsDataSetTableAdapters {
    
    
    public partial class tblStudent_InfoTableAdapter {
    }
}
