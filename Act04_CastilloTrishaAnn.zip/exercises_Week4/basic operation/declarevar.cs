

  class Declarevar 
    {
   public static double num1,num2,sum,diff,product,quo,rem;
    }
