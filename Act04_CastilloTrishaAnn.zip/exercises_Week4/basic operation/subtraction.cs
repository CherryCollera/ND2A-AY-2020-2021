
using trishacastillo_basicOperation;
   
   class Subtraction 
    { 
    	public void ComputeDiff(){
	     Declarevar.diff=Declarevar.num1-Declarevar.num2;
	     System.Console.WriteLine("Difference is "+Declarevar.diff);
    }
}