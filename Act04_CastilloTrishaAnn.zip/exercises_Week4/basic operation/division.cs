
using trishacastillo_basicOperation;
   
   class Division
    { 
    	public void ComputeDiv(){
	     Declarevar.quo=Declarevar.num1/Declarevar.num2;
	     System.Console.WriteLine("Quotient is "+Declarevar.quo);
    }
}