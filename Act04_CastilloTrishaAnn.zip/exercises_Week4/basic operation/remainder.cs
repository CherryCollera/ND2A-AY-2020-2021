
using trishacastillo_basicOperation;
   
   class Remainder
    { 
    	public void ComputeRem(){
	     Declarevar.rem=Declarevar.num1%Declarevar.num2;
	     System.Console.WriteLine("Remainder is "+Declarevar.rem);
    }
}