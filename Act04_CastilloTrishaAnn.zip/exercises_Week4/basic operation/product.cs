
using trishacastillo_basicOperation;
   
   class Product
    { 
    	public void ComputeProduct(){
	     Declarevar.product=Declarevar.num1*Declarevar.num2;
	     System.Console.WriteLine("Product is "+Declarevar.product);
    }
}