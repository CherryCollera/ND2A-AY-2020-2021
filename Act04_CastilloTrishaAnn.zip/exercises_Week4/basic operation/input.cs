
using trishacastillo_basicOperation;

  class Input 
    {
       public void InputData(){
       	System.Console.Write("Enter first number: ");
		      	Declarevar.num1 = System.Convert.ToDouble(Console.ReadLine());
		     	System.Console.Write("Enter second number: ");
		      	Declarevar.num2 = System.Convert.ToDouble(Console.ReadLine());
       }
    }
