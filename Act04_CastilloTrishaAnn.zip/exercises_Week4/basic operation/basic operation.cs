using System;

namespace trishacastillo_basicOperation
{

    public class Program 
    {
        public static void Main()
        {
			        Input i=new Input();
			        i.InputData();
			        Addition a= new Addition();
			        a.ComputeSum();
			        Subtraction s= new Subtraction();
			        s.ComputeDiff();
			        Product p= new Product();
			        p.ComputeProduct();
			        Division d= new Division();
			        d.ComputeDiv();
			        Remainder r= new Remainder();
			        r.ComputeRem();
        }
    }
}