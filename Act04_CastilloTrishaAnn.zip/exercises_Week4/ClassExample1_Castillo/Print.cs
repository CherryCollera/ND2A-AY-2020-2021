using ClassExample1_Castillo;

   class Print 
    {
       public void PrintDetails() {
       	Accept a=new Accept();
       	a.AcceptDetails();
       	
       	System.Console.WriteLine("\n\t\tHello "+a.fn+" "+a.ln+"!!!\n\t\tYou made to create classes in OOP:)\n\t\tYey!!!!!");
       	MyProfile mp=new MyProfile();
       	mp.DisplayProfile();
       }
    }