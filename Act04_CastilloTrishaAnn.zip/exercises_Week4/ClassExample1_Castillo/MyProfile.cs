

   class MyProfile 
    {
      public void DisplayProfile(){
       	System.Console.WriteLine("\n      PROFILE   ");
       	System.Console.WriteLine("	Name:   Trisha Castillo");
       	System.Console.WriteLine("	Birthday: March 28 2002");
        System.Console.WriteLine("	Course: BSCS");
        System.Console.WriteLine("	Year: 2nd Year");
        System.Console.WriteLine("	Section: ND2A");
       }
    }