using System;

namespace ClassExample1_Castillo
{
    public class Program 
    {
        public static void Main()
        {
			        Print p=new Print();
			        p.PrintDetails();
			        Console.ReadLine();
        }
    }
}