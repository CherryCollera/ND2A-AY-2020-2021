using ClassExample1_Castillo;

 class Accept
    {
      public string fn, ln;
      
       public void AcceptDetails()
           {
           	System.Console.Write("Enter firstname: ");
           	fn=System.Console.ReadLine();
           	System.Console.Write("Enter lastname: ");
           	ln=System.Console.ReadLine();
           }
    }
