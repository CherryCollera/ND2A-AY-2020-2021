

class Cars 
    {
    private string color;

    public Cars(string color)
    {
        this.color = color;
    }
    public string Describe()
    {
        return "This car is " + color;
    }
}
    