using System;

namespace sample2_Castillo_ND2A
{

    class Program
    {
        static void Main(string[] args)
        {
            Cars cars;
            cars = new Cars("Purple");
            Console.WriteLine(cars.Describe());
            cars = new Cars("Black");
            Console.WriteLine(cars.Describe());
            Console.ReadLine();
        }
    }
}