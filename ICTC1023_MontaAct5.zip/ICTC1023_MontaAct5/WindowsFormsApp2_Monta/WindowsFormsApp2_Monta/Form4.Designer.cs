﻿
namespace WindowsFormsApp2_Monta
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtfnum = new System.Windows.Forms.TextBox();
            this.txtsnum = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnadd = new System.Windows.Forms.Button();
            this.btndiff = new System.Windows.Forms.Button();
            this.btnmul = new System.Windows.Forms.Button();
            this.btnquo = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtans = new System.Windows.Forms.TextBox();
            this.btnback = new System.Windows.Forms.Button();
            this.btnclear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtfnum
            // 
            this.txtfnum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfnum.Location = new System.Drawing.Point(181, 11);
            this.txtfnum.Name = "txtfnum";
            this.txtfnum.Size = new System.Drawing.Size(138, 30);
            this.txtfnum.TabIndex = 0;
            this.txtfnum.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtsnum
            // 
            this.txtsnum.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsnum.Location = new System.Drawing.Point(181, 47);
            this.txtsnum.Name = "txtsnum";
            this.txtsnum.Size = new System.Drawing.Size(138, 34);
            this.txtsnum.TabIndex = 1;
            this.txtsnum.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "First Number:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(0, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(148, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Second Number:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // btnadd
            // 
            this.btnadd.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnadd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadd.Location = new System.Drawing.Point(46, 102);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(96, 67);
            this.btnadd.TabIndex = 4;
            this.btnadd.Text = "+";
            this.btnadd.UseVisualStyleBackColor = false;
            this.btnadd.Click += new System.EventHandler(this.button1_Click);
            // 
            // btndiff
            // 
            this.btndiff.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btndiff.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btndiff.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndiff.Location = new System.Drawing.Point(197, 102);
            this.btndiff.Name = "btndiff";
            this.btndiff.Size = new System.Drawing.Size(101, 67);
            this.btndiff.TabIndex = 5;
            this.btndiff.Text = "-";
            this.btndiff.UseVisualStyleBackColor = false;
            this.btndiff.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnmul
            // 
            this.btnmul.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnmul.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnmul.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmul.Location = new System.Drawing.Point(46, 175);
            this.btnmul.Name = "btnmul";
            this.btnmul.Size = new System.Drawing.Size(96, 66);
            this.btnmul.TabIndex = 6;
            this.btnmul.Text = "*";
            this.btnmul.UseVisualStyleBackColor = false;
            this.btnmul.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnquo
            // 
            this.btnquo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnquo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnquo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnquo.Location = new System.Drawing.Point(197, 175);
            this.btnquo.Name = "btnquo";
            this.btnquo.Size = new System.Drawing.Size(101, 66);
            this.btnquo.TabIndex = 7;
            this.btnquo.Text = "/";
            this.btnquo.UseVisualStyleBackColor = false;
            this.btnquo.Click += new System.EventHandler(this.button4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(69, 272);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Answer:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // txtans
            // 
            this.txtans.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtans.Location = new System.Drawing.Point(164, 266);
            this.txtans.Name = "txtans";
            this.txtans.Size = new System.Drawing.Size(100, 30);
            this.txtans.TabIndex = 9;
            this.txtans.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // btnback
            // 
            this.btnback.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnback.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnback.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.Location = new System.Drawing.Point(57, 315);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(91, 37);
            this.btnback.TabIndex = 10;
            this.btnback.Text = "Back";
            this.btnback.UseVisualStyleBackColor = false;
            this.btnback.Click += new System.EventHandler(this.button5_Click);
            // 
            // btnclear
            // 
            this.btnclear.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnclear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnclear.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclear.Location = new System.Drawing.Point(197, 315);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(83, 37);
            this.btnclear.TabIndex = 11;
            this.btnclear.Text = "Clear";
            this.btnclear.UseVisualStyleBackColor = false;
            this.btnclear.Click += new System.EventHandler(this.button6_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(349, 364);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.txtans);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnquo);
            this.Controls.Add(this.btnmul);
            this.Controls.Add(this.btndiff);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtsnum);
            this.Controls.Add(this.txtfnum);
            this.Name = "Form4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form4";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form4_FormClosing);
            this.Load += new System.EventHandler(this.Form4_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtfnum;
        private System.Windows.Forms.TextBox txtsnum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Button btndiff;
        private System.Windows.Forms.Button btnmul;
        private System.Windows.Forms.Button btnquo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtans;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Button btnclear;
    }
}