﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Activity9_DelaPena
{
    public partial class Form1 : Form
    {
        private OleDbConnection bookConn;
        private OleDbCommand oleDbCmd = new OleDbCommand();
        //private String connParam = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Acer\Desktop\Jang\OOP\Activity9_DelaPena\book3.accdb";
        private String connParam = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Acer\Desktop\Jang\OOP\Activity9_DelaPena\book3.mdb";
        public Form1()
        {
            bookConn = new OleDbConnection(connParam);
            InitializeComponent();
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'book3DataSet1.bookrecords' table. You can move, or remove it, as needed.
            this.bookrecordsTableAdapter1.Fill(this.book3DataSet1.bookrecords);
            // TODO: This line of code loads data into the 'book3DataSet.bookrecords' table. You can move, or remove it, as needed.
            this.bookrecordsTableAdapter.Fill(this.book3DataSet.bookrecords);

        }

        private void btnAddRecord_Click(object sender, EventArgs e)
        {
            bookConn.Open();
            oleDbCmd.Connection = bookConn;
            oleDbCmd.CommandText = "INSERT INTO bookrecords(booktitle,description)" + " " +
                "VALUES ('" + this.txtBoxBookTitle.Text + "', '" + this.txtBoxDesc.Text + "');";
            int temp = oleDbCmd.ExecuteNonQuery();
            if (temp>0)
            {
                txtBoxBookTitle.Text = null;
                txtBoxDesc.Text = null;
                MessageBox.Show("Records Added Sucessfully");
            }
            else
            {
                MessageBox.Show("Error Occured, Failed to Add Record");
            }
            bookConn.Close();
        }

        private void btnShowAll_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("Select * FROM bookrecords",connParam);
            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);
            DataTable dataTable = new DataTable();
            DataSet ds = new DataSet();
            dAdapter.Fill(dataTable);
            for (int i = 0; i<dataTable.Rows.Count; i++)
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0], dataTable.Rows[i][1]);
            }

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("To Delete a Record, Please select a row in the Data Grid View.","Deleting Record");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                dataGridView1.Rows.RemoveAt(dataGridView1.SelectedRows[0].Index);
                bookrecordsBindingSource1.EndEdit();
                bookrecordsTableAdapter1.Update(this.book3DataSet1.bookrecords);
            }
            catch (Exception)
            {
                bookrecordsBindingSource1.ResetBindings(false);
            }
	// the problem could be when the dataset is updated it will show again
	// all deleted rows. I try to use Update record in DML but cannot use it
	// it properly. I also cannot use DELETE() since there is no Unique key for table bookrecords
            
        }

        private void bookrecordsBindingSource1_CurrentChanged(object sender, EventArgs e)
        {

        }
    }
}
