﻿using System;


namespace compare_num
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, num3;
            Console.Write("Enter 1st num: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter 2nd num: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter 3rd num: ");
            num3 = Convert.ToInt32(Console.ReadLine());

            if (num2 > num1 & num3 < num2)
            {
                Console.WriteLine(num2 + " is greater than " + num1 + " and " + num3 + "\n" + num1 + " is less than " + num2 + "\n" + num3 + " is less than " + num2);

                Console.ReadLine();
            }

            else if (num3 > num1 & num2 < num3)
            {
                Console.WriteLine(num3 + " is greater than " + num1 + " and " + num2 + "\n" + num1 + " is less than " + num3 + "\n" + num2 + " is less than " + num3);
                Console.ReadLine();
            }

            else
            {
                Console.WriteLine("{0} {1} and {2} are equal", num1, num2, num3);

                Console.ReadLine();
            }
        }
    }

}
        