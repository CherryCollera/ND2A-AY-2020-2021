﻿using System;


namespace CompareNumbers
{
   


namespace CompareNumbers
    {
        class Program
        {
            static void Main(string[] args)
            {
                int CRSTAN11_num1, CRSTAN1_num2, RTBO19_num3;

                Console.Write("Enter First Number: ");
                CRSTAN11_num1 = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Second Number: ");
                CRSTAN11_num2 = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Third Number: ");
                CRSTAN11_num3 = Convert.ToInt32(Console.ReadLine());

                if (CRSTAN11_num1 > CRSTAN11_num2 && CRSTAN11_num1 > CRSTAN11_num3)
                {
                    Console.WriteLine("{0} is greater than {1} and {2}", CRSTAN11_num1, CRSTAN11_num2, CRSTAN11_num3);
                    Console.WriteLine("{0} is less than {1}", CRSTAN11_num2, CRSTAN119_num1);
                    Console.WriteLine("{0} is less than {1}", CRSTAN11_num3, CRSTAN11_num1);
                }
                else if (CRSTAN11_num2 > CRSTAN11_num1 && CRSTAN11_num2 > CRSTAN11_num3)
                {
                    Console.WriteLine("{0} is greater than {1} and {2}", CRSTAN11_num2, CRSTAN11_num1, CRSTAN11_num3);
                    Console.WriteLine("{0} is less than {1}", CRSTAN11_num1, CRSTAN11_num2);
                    Console.WriteLine("{0} is less than {1}", CRSTAN11_num3, CRSTAN11_num2);
                }
                else if (RTBO19_num3 > RTBO19_num1 && RTBO19_num3 > RTBO19_num2)
                {
                    Console.WriteLine("{0} is greater than {1} and {2}", CRSTAN11_num3, CRSTAN11_num1, CRSTAN11_num2);
                    Console.WriteLine("{0} is less than {1}", CRSTAN11_num1, CRSTAN11_num3);
                    Console.WriteLine("{0} is less than {1}", CRSTAN11_num2, CRSTAN11_num3);
                }
                else if (CRSTAN11_num3 == CRSTAN11_num1 && CRSTAN11_num3 == CRSTAN11_num2)
                {
                    Console.WriteLine("{0}, {1} and {2} are equal", CRSTAN11_num1, CRSTAN11_num2, CRSTAN11_num3);

                }
                Console.ReadLine();
            }
        }
    }
}
    