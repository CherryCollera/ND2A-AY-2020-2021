﻿using System;

namespace DoWhile
{
    

namespace DoWhile
    {
        class Program
        {
            static void Main(string[] args)
            {
                int[] CRSTAN11_nms = new int[] { 6, 7, 8, 10 };
                int CRSTAN1_sum = 0;
                int i = 0;

                do
                {
                    CRSTAN1_sum += CRSTAN1_nms[i];
                    i++;
                } while (i < 4);

                Console.WriteLine(CRSTAN1_sum);
                Console.ReadLine();
            }
        }
    }
}
    