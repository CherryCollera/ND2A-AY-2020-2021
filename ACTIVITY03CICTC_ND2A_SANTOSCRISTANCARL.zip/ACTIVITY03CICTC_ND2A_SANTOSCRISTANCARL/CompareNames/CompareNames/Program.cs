﻿using System;


namespace CompareNames
{
    
        

namespace CompareNames
    {
        class Program
        {
            static void Main(string[] args)
            {
                string CRSTAN11_string1 = "carl1";
                string CRSTAN11_string2 = "carl1";
                string CRSTAN11_string3 = "carl";
                string CRSTAN11_string4 = "carl";
                string CRSTAN11_string5 = "CARL";

                Console.WriteLine("\nUsing Equals() method");

                Console.WriteLine("compare {0} to {1}: {2}", CRSTAN11_string1, CRSTAN11_string2, String.Equals(CRSTAN11_string1, CRSTAN11_string2));
                Console.WriteLine("compare {0} to {1}: {2}", CRSTAN11_string1, CRSTAN11_string3, String.Equals(CRSTAN11_string1, CRSTAN11_string3));
                Console.WriteLine("Length of {0} is {1}", CRSTAN11_string1, CRSTAN11_string1.Length);
                Console.WriteLine("String {0} Substring(0,3) will return {1}", CRSTAN11_string5, CRSTAN11_string5.Substring(0, 3));

                Console.WriteLine("\nUsing Compare() method");

                Console.WriteLine("compare {0} to {1}: {2}", CRSTAN11_string1, CRSTAN11_string2, String.Compare(CRSTAN11_string1, CRSTAN11_string2));
                Console.WriteLine("compare {0} to {1}: {2}", CRSTAN11_string1, CRSTAN11_string3, String.Compare(CRSTAN11_string1, CRSTAN11_string3));
                Console.WriteLine("compare {0} to {1}: {2}", CRSTAN11_string3, CRSTAN11_string1, String.Compare(CRSTAN11_string3, CRSTAN11_string1));
                Console.WriteLine("compare {0} to {1}: {2}", CRSTAN11_string4, CRSTAN11_string5, String.Equals(CRSTAN11_string4, CRSTAN11_string5));

                Console.WriteLine("\nUsing CompareTo() method");

                Console.WriteLine("compare {0} to {1}: {2}", CRSTAN11_string1, CRSTAN11_string2, CRSTAN11_string1.CompareTo(CRSTAN11_string2));
                Console.WriteLine("compare {0} to {1}: {2}", CRSTAN11_string1, CRSTAN11_string3, CRSTAN11_string1.CompareTo(CRSTAN11_string3));
                Console.WriteLine("compare {0} to {1}: {2}", CRSTAN11_string3, CRSTAN11_string1, CRSTAN11_string3.CompareTo(CRSTAN11_string1));
                Console.ReadLine();
            }
        }
    }
}
  