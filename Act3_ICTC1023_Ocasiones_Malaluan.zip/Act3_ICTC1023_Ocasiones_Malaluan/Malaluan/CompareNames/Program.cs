﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace compareNames
{
    class Program
    {
        static void Main(string[] args)
        {
            string pangalan1 = "FrancisVien";
            string pangalan2 = "Francis";
            string pangalan3 = "francisvien";
            string pangalan4 = "FRANCISVIEN";

            Console.WriteLine("Using equals() method");
            Console.WriteLine("compare {0} to {1}: {2}",pangalan1,pangalan2,String.Equals(pangalan1,pangalan2));
            Console.WriteLine("compare {0} to {1}: {2}", pangalan1, pangalan3, String.Equals(pangalan1, pangalan3));
            Console.WriteLine("length of {0}: {1}",pangalan1,pangalan1.Length );
            Console.WriteLine("String {0} Substring (0,3) will return{1}",pangalan4,pangalan4.Substring(0,3));

            Console.WriteLine("Using Compare() method");
            Console.WriteLine("compare {0} to {1}: {2}", pangalan1, pangalan2, String.Compare(pangalan1, pangalan2));
            Console.WriteLine("compare {0} to {1}: {2}", pangalan1, pangalan3, String.Compare(pangalan1, pangalan3));
            Console.WriteLine("compare {0} to {1}: {2}", pangalan3, pangalan1, String.Compare(pangalan3, pangalan1));
            Console.WriteLine("compare {0} to {1}: {2}", pangalan1, pangalan3, String.Compare(pangalan3, pangalan4));

            Console.WriteLine("Using CompareTo() method");
            Console.WriteLine("compare {0} to {1}: {2}", pangalan1, pangalan2, pangalan1.CompareTo(pangalan2));
            Console.WriteLine("compare {0} to {1}: {2}", pangalan1, pangalan3, pangalan1.CompareTo(pangalan3));
            Console.WriteLine("compare {0} to {1}: {2}", pangalan3, pangalan1, pangalan3.CompareTo(pangalan1));
            Console.ReadKey();





        }
    }
}
