﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompareNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int number1, number2, number3;

            Console.Write("Enter First Number: ");
            number1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Second Number: ");
            number2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Third Number: ");
            number3 = Convert.ToInt32(Console.ReadLine());
            Console.ReadKey();

            if (number1 == number2)
            {
                if (number1 == number3)
                {
                    Console.WriteLine("{0} {1} and {2} are equal", number1, number2, number3);
                    Console.ReadKey();
                }
                else if (number1 < number3)
                {
                    Console.WriteLine("{0} and {1} are equal but less than {3}", number1, number2, number3);
                    Console.ReadKey();
                }
                else if (number1 > number3)
                {
                    Console.WriteLine("{0} and {1} are equal but greater than {3}", number1, number2, number3);
                    Console.ReadKey();
                }


            }
            else if (number1 > number2)
            {
                if (number1 > number3)
                {
                    Console.WriteLine("{0} is greater than {1} and {2}", number1, number2, number3);

                    Console.WriteLine("{0} is greater than {1}", number1, number2);
                    Console.WriteLine("{0} is greater than {1}", number1, number3);
                    Console.ReadKey();
                }

                else if (number1 < number3)
                {
                    Console.WriteLine("{0} is greater than {1} but less than {2}", number1, number2, number3);
                    Console.WriteLine("{0} is greater than {1}", number1, number2);
                    Console.WriteLine("{0} is less than {1}", number1, number3);
                    Console.ReadKey();
                }
                else if (number1 == number3)
                {
                    Console.WriteLine("{0} is greater than {1} but equal to {2}", number1, number2, number3);
                    Console.WriteLine("{0} is greater than {1}", number1, number2);
                    Console.WriteLine("{0} is equal to {1}", number1, number3);
                    Console.ReadKey();

                }

                }
                else if (number2 > number3)
                {
                    if (number2 > number1)
                    {
                        Console.WriteLine("{0} is greater than {1} and {2}", number2, number1, number3);
                        Console.WriteLine("{0} is greater than {1}", number2, number3);
                        Console.WriteLine("{0} is greater than {1}", number2, number1);
                        Console.ReadKey();

                    }

                
               
                }
                else if (number3 > number1)
                {
                    if (number3 > number2)
                    {
                        Console.WriteLine("{0} greater than {1} and {2}", number3, number2, number1);
                       
                    Console.WriteLine("{0} greater than {1}", number3, number1);
                    Console.WriteLine("{0} is greater than {1}", number3, number2);
                    Console.ReadKey();
                }
                else if (number3 < number2)
                    {
                        Console.WriteLine("{0} greater than {1} but less than {2}", number3, number1, number2);
                    Console.WriteLine("{0} greater than {1}", number3, number1);
                    Console.WriteLine("{0} is less than {1}", number3, number2);
                    Console.ReadKey();
                    }
                    else if (number3 == number2)
                    {
                        Console.WriteLine("{0} greater than {1} equal to {2}", number3, number1, number2);
                    Console.WriteLine("{0} greater than {1}", number3, number1);
                    Console.WriteLine("{0} is equal {1}", number3, number2);
                    Console.ReadKey();
                    }
                }

            }

        }
    }

