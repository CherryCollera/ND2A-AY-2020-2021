﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace do_While
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] nums = new int[] { 4,5,6,7};
            int sum = 0;
            int i = 0;

            do
            {
                sum+=nums[i];
                i++;
            } while (i < 4);

            Console.WriteLine(sum);
            Console.ReadKey();

        }
    }
}
