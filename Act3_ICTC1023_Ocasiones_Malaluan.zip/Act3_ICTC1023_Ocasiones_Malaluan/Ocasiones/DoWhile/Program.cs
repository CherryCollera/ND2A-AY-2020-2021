﻿// 19-03008
// Ocasiones, Rovic Troy B.
// BSCS ND2A

using System;


namespace DoWhile
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] RTBO19_nms = new int[] { 6, 7, 8, 10 };
            int RTBO19_sum = 0;
            int i = 0;

            do
            {
                RTBO19_sum += RTBO19_nms[i];
                i++;
            } while (i < 4);

            Console.WriteLine(RTBO19_sum);
            Console.ReadLine();
        }
    }
}
