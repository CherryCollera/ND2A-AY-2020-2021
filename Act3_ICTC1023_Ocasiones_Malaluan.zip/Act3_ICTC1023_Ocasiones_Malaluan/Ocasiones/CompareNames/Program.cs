﻿// 19-03008
// Ocasiones, Rovic Troy B.
// BSCS ND2A

using System;


namespace CompareNames
{
    class Program
    {
        static void Main(string[] args)
        {
            string RTBO19_string1 = "Rovi";
            string RTBO19_string2 = "Rovi";
            string RTBO19_string3 = "Rovic";
            string RTBO19_string4 = "rovic";
            string RTBO19_string5 = "ROVIC";

            Console.WriteLine("\nUsing Equals() method");

            Console.WriteLine("compare {0} to {1}: {2}", RTBO19_string1, RTBO19_string2, String.Equals(RTBO19_string1, RTBO19_string2));
            Console.WriteLine("compare {0} to {1}: {2}", RTBO19_string1, RTBO19_string3, String.Equals(RTBO19_string1, RTBO19_string3));
            Console.WriteLine("Length of {0} is {1}", RTBO19_string1, RTBO19_string1.Length);
            Console.WriteLine("String {0} Substring(0,3) will return {1}", RTBO19_string5, RTBO19_string5.Substring(0, 3));

            Console.WriteLine("\nUsing Compare() method");

            Console.WriteLine("compare {0} to {1}: {2}", RTBO19_string1, RTBO19_string2, String.Compare(RTBO19_string1, RTBO19_string2));
            Console.WriteLine("compare {0} to {1}: {2}", RTBO19_string1, RTBO19_string3, String.Compare(RTBO19_string1, RTBO19_string3));
            Console.WriteLine("compare {0} to {1}: {2}", RTBO19_string3, RTBO19_string1, String.Compare(RTBO19_string3, RTBO19_string1));
            Console.WriteLine("compare {0} to {1}: {2}", RTBO19_string4, RTBO19_string5, String.Equals(RTBO19_string4, RTBO19_string5));

            Console.WriteLine("\nUsing CompareTo() method");

            Console.WriteLine("compare {0} to {1}: {2}", RTBO19_string1, RTBO19_string2, RTBO19_string1.CompareTo(RTBO19_string2));
            Console.WriteLine("compare {0} to {1}: {2}", RTBO19_string1, RTBO19_string3, RTBO19_string1.CompareTo(RTBO19_string3));
            Console.WriteLine("compare {0} to {1}: {2}", RTBO19_string3, RTBO19_string1, RTBO19_string3.CompareTo(RTBO19_string1));
            Console.ReadLine();
        }
    }
}
