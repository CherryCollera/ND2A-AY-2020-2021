﻿// 19-03008
// Ocasiones, Rovic Troy
// BSCS ND2A

using System;


namespace CompareNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int RTBO19_num1, RTBO19_num2, RTBO19_num3;

            Console.Write("Enter First Number: ");
            RTBO19_num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            RTBO19_num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Third Number: ");
            RTBO19_num3 = Convert.ToInt32(Console.ReadLine());

            if (RTBO19_num1 > RTBO19_num2 && RTBO19_num1 > RTBO19_num3)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", RTBO19_num1, RTBO19_num2, RTBO19_num3);
                Console.WriteLine("{0} is less than {1}", RTBO19_num2, RTBO19_num1);
                Console.WriteLine("{0} is less than {1}", RTBO19_num3, RTBO19_num1);
            }
            else if (RTBO19_num2 > RTBO19_num1 && RTBO19_num2 > RTBO19_num3)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", RTBO19_num2, RTBO19_num1, RTBO19_num3);
                Console.WriteLine("{0} is less than {1}", RTBO19_num1, RTBO19_num2);
                Console.WriteLine("{0} is less than {1}", RTBO19_num3, RTBO19_num2);
            }
            else if (RTBO19_num3 > RTBO19_num1 && RTBO19_num3 > RTBO19_num2)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", RTBO19_num3, RTBO19_num1, RTBO19_num2);
                Console.WriteLine("{0} is less than {1}", RTBO19_num1, RTBO19_num3);
                Console.WriteLine("{0} is less than {1}", RTBO19_num2, RTBO19_num3);
            }
            else if (RTBO19_num3 == RTBO19_num1 && RTBO19_num3 == RTBO19_num2)
            {
                Console.WriteLine("{0}, {1} and {2} are equal", RTBO19_num1, RTBO19_num2, RTBO19_num3);
                
            }
                Console.ReadLine();
        }
    }
}
