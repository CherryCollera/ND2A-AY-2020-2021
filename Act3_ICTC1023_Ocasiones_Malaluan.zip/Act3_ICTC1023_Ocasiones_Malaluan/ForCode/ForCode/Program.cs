﻿// 19-03008, 19-01840
// Ocasiones, Rovic Troy
// Malaluan, Francis Vien
// BSCS ND2A

using System;


namespace ForCode
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 10 - 1; i >= 0; i--) {
                Console.WriteLine(i);
            }
            Console.ReadLine();
        }
    }
}
