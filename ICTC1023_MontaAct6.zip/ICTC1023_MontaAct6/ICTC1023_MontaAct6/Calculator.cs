﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ICTC1023_MontaAct6
{
    public partial class Calculator : Form
    {
        double total1 = 0;
        double total2 = 0;
        int operations;
        bool ops = false;

        bool btnAddClick = false;
        bool btnSubClick = false;
        bool btnMultClick = false;
        bool btnDivClick = false;

        public Calculator()
        {
            InitializeComponent();
        }


        private void Calculator_Load(object sender, EventArgs e)
        {

        }

        private void btn1_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "1";
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "2";
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "3";
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "4";
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "5";
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "6";
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "7";
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "8";
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "9";
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + "0";
        }


        private void btnDot_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + ".";
        }

        private void btnClr_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

        private void btnBkFm1_Click(object sender, EventArgs e)
        {
            Form1 frm1 = new Form1();
            this.Hide();
            frm1.Show();
        }

        private void btnG2frm3_Click(object sender, EventArgs e)
        {
            Form3 frm3 = new Form3();
            this.Hide();
            frm3.Show();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            total1 = total1 + Convert.ToDouble(textBox1.Text);
            textBox1.Clear();
            operations = 1;
            ops = true;

        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            total1 = total1 + Convert.ToDouble(textBox1.Text);
            textBox1.Clear();
            operations = 2;
            ops = true;
        }

        private void btnMul_Click(object sender, EventArgs e)
        {
            total1 = total1 + Convert.ToDouble(textBox1.Text);
            textBox1.Clear();
            operations = 3;
            ops = true;
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {

            total1 = total1 + Convert.ToDouble(textBox1.Text);
            textBox1.Clear();
            operations = 4;
            ops = true;
        }

        private void btnEq_Click(object sender, EventArgs e)
        {

            if (operations == 1)
            {
                total2 = total1 + Convert.ToDouble(textBox1.Text);
                textBox1.Clear();
                textBox1.Text = Convert.ToString(total2);
                total1 = 0;
                total2 = 0;
            }

            else if (operations == 2)
            {
                total2 = total1 - Convert.ToDouble(textBox1.Text);
                textBox1.Clear();
                textBox1.Text = Convert.ToString(total2);
                total1 = 0;
                total2 = 0;
            }

            else if (operations == 3)
            {
                total2 = total1 * Convert.ToDouble(textBox1.Text);
                textBox1.Clear();
                textBox1.Text = Convert.ToString(total2);
                total1 = 0;
                total2 = 0;
            }

            else if (operations == 4)
            {
                total2 = total1 / Convert.ToDouble(textBox1.Text);
                textBox1.Clear();
                textBox1.Text = Convert.ToString(total2);
                total1 = 0;
                total2 = 0;
            }

        }  

       private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
