﻿namespace WindowsFormsApp2_Sacdalan
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btn_getmyprofile = new System.Windows.Forms.Button();
            this.txtFN = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtLN = new System.Windows.Forms.TextBox();
            this.btn_hide = new System.Windows.Forms.Button();
            this.btn_back = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Pink;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(104, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "My Profile";
            // 
            // btn_getmyprofile
            // 
            this.btn_getmyprofile.BackColor = System.Drawing.Color.Pink;
            this.btn_getmyprofile.Location = new System.Drawing.Point(12, 167);
            this.btn_getmyprofile.Name = "btn_getmyprofile";
            this.btn_getmyprofile.Size = new System.Drawing.Size(86, 28);
            this.btn_getmyprofile.TabIndex = 1;
            this.btn_getmyprofile.Text = "Get My Profile";
            this.btn_getmyprofile.UseVisualStyleBackColor = false;
            this.btn_getmyprofile.Click += new System.EventHandler(this.btn_getmyprofile_Click);
            // 
            // txtFN
            // 
            this.txtFN.Location = new System.Drawing.Point(86, 48);
            this.txtFN.Name = "txtFN";
            this.txtFN.Size = new System.Drawing.Size(167, 20);
            this.txtFN.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Firstname:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "Lastname:";
            // 
            // txtLN
            // 
            this.txtLN.Location = new System.Drawing.Point(86, 86);
            this.txtLN.Name = "txtLN";
            this.txtLN.Size = new System.Drawing.Size(167, 20);
            this.txtLN.TabIndex = 5;
            // 
            // btn_hide
            // 
            this.btn_hide.BackColor = System.Drawing.Color.Pink;
            this.btn_hide.Location = new System.Drawing.Point(117, 167);
            this.btn_hide.Name = "btn_hide";
            this.btn_hide.Size = new System.Drawing.Size(55, 28);
            this.btn_hide.TabIndex = 6;
            this.btn_hide.Text = "Hide";
            this.btn_hide.UseVisualStyleBackColor = false;
            this.btn_hide.Click += new System.EventHandler(this.btn_hide_Click);
            // 
            // btn_back
            // 
            this.btn_back.BackColor = System.Drawing.Color.Pink;
            this.btn_back.Location = new System.Drawing.Point(196, 167);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(57, 28);
            this.btn_back.TabIndex = 7;
            this.btn_back.Text = "Back";
            this.btn_back.UseVisualStyleBackColor = false;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApp2_Sacdalan.Properties.Resources.blackpink;
            this.ClientSize = new System.Drawing.Size(293, 224);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.btn_hide);
            this.Controls.Add(this.txtLN);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtFN);
            this.Controls.Add(this.btn_getmyprofile);
            this.Controls.Add(this.label1);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_getmyprofile;
        private System.Windows.Forms.TextBox txtFN;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtLN;
        private System.Windows.Forms.Button btn_hide;
        private System.Windows.Forms.Button btn_back;
    }
}