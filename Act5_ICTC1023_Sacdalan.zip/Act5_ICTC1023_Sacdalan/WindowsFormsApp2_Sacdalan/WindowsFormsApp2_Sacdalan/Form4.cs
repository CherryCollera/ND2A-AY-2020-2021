﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp2_Sacdalan
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void btn_sum_Click(object sender, EventArgs e)
        {
            double FirstNumber, SecondNumber;

            FirstNumber = Convert.ToDouble(txtnum1.Text);
            SecondNumber = Convert.ToDouble(txtnum2.Text);
            txtAns.Text = (FirstNumber + SecondNumber).ToString();
            
        }

        private void btn_difference_Click(object sender, EventArgs e)
        {
            double FirstNumber, SecondNumber;

            FirstNumber = Convert.ToDouble(txtnum1.Text);
            SecondNumber = Convert.ToDouble(txtnum2.Text);
            txtAns.Text = (FirstNumber - SecondNumber).ToString();
        }

        private void btn_product_Click(object sender, EventArgs e)
        {
            double FirstNumber, SecondNumber;

            FirstNumber = Convert.ToDouble(txtnum1.Text);
            SecondNumber = Convert.ToDouble(txtnum2.Text);
            txtAns.Text = (FirstNumber * SecondNumber).ToString();
        }

        private void btn_quotient_Click(object sender, EventArgs e)
        {
            double FirstNumber, SecondNumber;

            FirstNumber = Convert.ToDouble(txtnum1.Text);
            SecondNumber = Convert.ToDouble(txtnum2.Text);
            txtAns.Text = (FirstNumber / SecondNumber).ToString();
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txtnum1.Clear();
            txtnum2.Clear();
            txtAns.Clear();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Form3 frm = new Form3();
            frm.Show();
            this.Hide();
        }
    }
}
