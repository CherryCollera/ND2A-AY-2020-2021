﻿namespace WindowsFormsApp2_Sacdalan
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtFN = new System.Windows.Forms.TextBox();
            this.txtLN = new System.Windows.Forms.TextBox();
            this.btn_getmessage = new System.Windows.Forms.Button();
            this.btn_hide = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Firstname:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(24, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Lastname:";
            // 
            // txtFN
            // 
            this.txtFN.Location = new System.Drawing.Point(95, 23);
            this.txtFN.Name = "txtFN";
            this.txtFN.Size = new System.Drawing.Size(161, 20);
            this.txtFN.TabIndex = 2;
            // 
            // txtLN
            // 
            this.txtLN.Location = new System.Drawing.Point(95, 58);
            this.txtLN.Name = "txtLN";
            this.txtLN.Size = new System.Drawing.Size(161, 20);
            this.txtLN.TabIndex = 3;
            // 
            // btn_getmessage
            // 
            this.btn_getmessage.BackColor = System.Drawing.Color.Pink;
            this.btn_getmessage.Location = new System.Drawing.Point(85, 159);
            this.btn_getmessage.Name = "btn_getmessage";
            this.btn_getmessage.Size = new System.Drawing.Size(131, 35);
            this.btn_getmessage.TabIndex = 4;
            this.btn_getmessage.Text = "Get Message";
            this.btn_getmessage.UseVisualStyleBackColor = false;
            this.btn_getmessage.Click += new System.EventHandler(this.btn_getmessage_Click);
            // 
            // btn_hide
            // 
            this.btn_hide.BackColor = System.Drawing.Color.Pink;
            this.btn_hide.Location = new System.Drawing.Point(205, 203);
            this.btn_hide.Name = "btn_hide";
            this.btn_hide.Size = new System.Drawing.Size(59, 22);
            this.btn_hide.TabIndex = 5;
            this.btn_hide.Text = "Hide";
            this.btn_hide.UseVisualStyleBackColor = false;
            this.btn_hide.Click += new System.EventHandler(this.btn_hide_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImage = global::WindowsFormsApp2_Sacdalan.Properties.Resources.blackpink;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(276, 239);
            this.Controls.Add(this.btn_hide);
            this.Controls.Add(this.btn_getmessage);
            this.Controls.Add(this.txtLN);
            this.Controls.Add(this.txtFN);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtFN;
        private System.Windows.Forms.TextBox txtLN;
        private System.Windows.Forms.Button btn_getmessage;
        private System.Windows.Forms.Button btn_hide;
    }
}