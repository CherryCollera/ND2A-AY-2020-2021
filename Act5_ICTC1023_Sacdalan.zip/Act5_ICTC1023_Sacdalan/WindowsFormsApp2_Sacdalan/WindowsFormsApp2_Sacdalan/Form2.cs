﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp2_Sacdalan
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btn_getmessage_Click(object sender, EventArgs e)
        {
            String Firstname, Lastname;

            Firstname = txtFN.Text;
            Lastname = txtLN.Text;

            MessageBox.Show("Happy Birthday " + Firstname + " " + Lastname);
        }

        private void btn_hide_Click(object sender, EventArgs e)
        {
            Form3 frm = new Form3();
            frm.Show();
            this.Hide();
        }
        
    }
}
