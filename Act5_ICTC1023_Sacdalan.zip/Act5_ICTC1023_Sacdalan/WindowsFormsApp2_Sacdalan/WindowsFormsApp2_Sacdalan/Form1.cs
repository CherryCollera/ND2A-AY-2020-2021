﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp2_Sacdalan
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_getmessage_Click(object sender, EventArgs e)
        {
            HappyBirthday hb = new HappyBirthday();
            MessageBox.Show(hb.GetMessage("Nina"));
            
        }

        private void btn_hide_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
            this.Hide();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }


    }
}  
