﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp2_Sacdalan
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btn_getmyprofile_Click(object sender, EventArgs e)
        {
            String Firstname, Lastname;

            Firstname = txtFN.Text;
            Lastname = txtLN.Text;

            MessageBox.Show("\t     Hello " + Firstname + " " + Lastname + "\nDate of Birth     :     January 21, 2001" +
           "\nCourse               :     BS COMPUTER SCIENCE" + "\nYear                    :     1" +
           "\nSection              :     A");


        }

        private void btn_hide_Click(object sender, EventArgs e)
        {
            Form4 frm = new Form4();
            frm.Show();
            this.Hide();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
            this.Hide();
        }
    
    }
}
