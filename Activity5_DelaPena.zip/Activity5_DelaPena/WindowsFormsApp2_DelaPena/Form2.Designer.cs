﻿
namespace WindowsFormsApp2_DelaPena
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_fName = new System.Windows.Forms.TextBox();
            this.textBox_lName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnGetM2 = new System.Windows.Forms.Button();
            this.btnHide2 = new System.Windows.Forms.Button();
            this.btnBack2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "First Name: ";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // textBox_fName
            // 
            this.textBox_fName.Location = new System.Drawing.Point(91, 79);
            this.textBox_fName.Name = "textBox_fName";
            this.textBox_fName.Size = new System.Drawing.Size(258, 20);
            this.textBox_fName.TabIndex = 1;
            // 
            // textBox_lName
            // 
            this.textBox_lName.Location = new System.Drawing.Point(91, 114);
            this.textBox_lName.Name = "textBox_lName";
            this.textBox_lName.Size = new System.Drawing.Size(258, 20);
            this.textBox_lName.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 22);
            this.label2.TabIndex = 2;
            this.label2.Text = "Last Name:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnGetM2
            // 
            this.btnGetM2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnGetM2.Location = new System.Drawing.Point(107, 162);
            this.btnGetM2.Name = "btnGetM2";
            this.btnGetM2.Size = new System.Drawing.Size(134, 37);
            this.btnGetM2.TabIndex = 4;
            this.btnGetM2.Text = "Get Message";
            this.btnGetM2.UseVisualStyleBackColor = true;
            this.btnGetM2.Click += new System.EventHandler(this.btnGetM2_Click);
            // 
            // btnHide2
            // 
            this.btnHide2.Location = new System.Drawing.Point(314, 325);
            this.btnHide2.Name = "btnHide2";
            this.btnHide2.Size = new System.Drawing.Size(58, 24);
            this.btnHide2.TabIndex = 5;
            this.btnHide2.Text = "Hide";
            this.btnHide2.UseVisualStyleBackColor = true;
            this.btnHide2.Click += new System.EventHandler(this.btnHide2_Click);
            // 
            // btnBack2
            // 
            this.btnBack2.Location = new System.Drawing.Point(250, 325);
            this.btnBack2.Name = "btnBack2";
            this.btnBack2.Size = new System.Drawing.Size(58, 24);
            this.btnBack2.TabIndex = 6;
            this.btnBack2.Text = "Back";
            this.btnBack2.UseVisualStyleBackColor = true;
            this.btnBack2.Click += new System.EventHandler(this.btnBack2_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 361);
            this.Controls.Add(this.btnBack2);
            this.Controls.Add(this.btnHide2);
            this.Controls.Add(this.btnGetM2);
            this.Controls.Add(this.textBox_lName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox_fName);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_fName;
        private System.Windows.Forms.TextBox textBox_lName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnGetM2;
        private System.Windows.Forms.Button btnHide2;
        private System.Windows.Forms.Button btnBack2;
    }
}