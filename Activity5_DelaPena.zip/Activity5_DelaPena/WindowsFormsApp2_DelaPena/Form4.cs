﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2_DelaPena
{
    public partial class Form4 : Form
    {
        double num1,num2,ans;
        public Form4()
        {
            InitializeComponent();
        }

        private void btnBack4_Click(object sender, EventArgs e)
        {
            Form3 frm3 = new Form3();
            frm3.Show();
            this.Hide();
        }

        private void btnMinus_Click(object sender, EventArgs e)
        {
            num1 = Convert.ToDouble(textBox_fNumber.Text);
            num2 = Convert.ToDouble(textBox_sNumber.Text);
            ans = num1 - num2;
            labelAns.Text = ans.ToString();
        }

        private void btnTimes_Click(object sender, EventArgs e)
        {
            num1 = Convert.ToDouble(textBox_fNumber.Text);
            num2 = Convert.ToDouble(textBox_sNumber.Text);
            ans = num1 * num2;
            labelAns.Text = ans.ToString();
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            num1 = Convert.ToDouble(textBox_fNumber.Text);
            num2 = Convert.ToDouble(textBox_sNumber.Text);
            ans = num2 / num1;
            labelAns.Text = ans.ToString();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            textBox_fNumber.Text = "";
            textBox_sNumber.Text = "";
            labelAns.Text = "";
        }

        private void Form4_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                DialogResult result = MessageBox.Show("Do you really want to exit?", "Confirmation", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    Environment.Exit(0);
                }
                else
                {
                    e.Cancel = true;
                }
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            num1 = Convert.ToDouble(textBox_fNumber.Text);
            num2 = Convert.ToDouble(textBox_sNumber.Text);
            ans = num1 + num2;
            labelAns.Text = ans.ToString();

        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        
    }
}
