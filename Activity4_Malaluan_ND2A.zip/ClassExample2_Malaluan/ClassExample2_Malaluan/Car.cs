﻿
    class Car
    {
    private string color;
    public Car(string color) 
    {
        this.color = color;
    }
    public string Describe() 
    {
        return "this Car is " + color;
    }
    }

