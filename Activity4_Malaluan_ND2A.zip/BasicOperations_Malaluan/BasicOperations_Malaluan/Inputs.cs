﻿

    class Inputs
    {
   
 
    public void Input()
    {
     
       System.Console.WriteLine("Enter First Num: ");
       DeclareVar.num1 = System.Convert.ToInt32(System.Console.ReadLine());
       System.Console.WriteLine("Enter Second Num: ");
       DeclareVar.num2 = System.Convert.ToInt32(System.Console.ReadLine());
       
    }
}

