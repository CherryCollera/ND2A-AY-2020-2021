﻿



    class Multiply
    {
    public void prod()
    {
       
        DeclareVar.product = DeclareVar.num1 * DeclareVar.num2;
        System.Console.WriteLine("The product is "+ DeclareVar.product);
        System.Console.Read();


    }
}

