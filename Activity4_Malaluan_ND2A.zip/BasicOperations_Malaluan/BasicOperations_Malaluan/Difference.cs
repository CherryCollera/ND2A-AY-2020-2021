﻿



    class Difference
    {
    public void Differ()
    {
        
        DeclareVar.diff = DeclareVar.num1 - DeclareVar.num2;
        System.Console.WriteLine("The difference is "+ DeclareVar.diff);
        System.Console.Read();


    }
}

