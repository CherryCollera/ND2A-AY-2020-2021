﻿using System;

namespace ClassExample1_Malaluan
{
    class Program
    {
        static void Main(string[] args)
        {
            PrintDetails p = new PrintDetails();
            p.print();
            Console.ReadLine();
        }
    }
}
