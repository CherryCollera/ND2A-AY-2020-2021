﻿

using ClassExample1_Malaluan;

    class PrintDetails
    {
    public void print() 
    {
        Accept a = new Accept();
        a.AcceptDetails();
        System.Console.Write("Hello "+a.firstname+" "+a.lastname+"!!!\n You have created classes in OOP");
        DisplayProfile mp = new DisplayProfile();
        mp.MyProfile();
    }
    }

