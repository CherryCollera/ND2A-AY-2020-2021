﻿
using ClassExample1_Malaluan;

    class DisplayProfile
    {
    public void MyProfile() 
    {
        System.Console.WriteLine("\n\n\n\t\t\t\tP R O F I L E");
        System.Console.WriteLine("Name:\t\t\tFrancis Vien Malaluan");
        System.Console.WriteLine("Birthday:\t\tMarch 4, 2001");
        System.Console.WriteLine("Course:\t\t\tBS Computer Science");
        System.Console.WriteLine("Year:\t\t\t2nd Year");
        System.Console.WriteLine("Section:\t\tND2A");
        System.Console.ReadLine();
    }
    }

