﻿/*
19-01923
Jefte R. Perdio
19-00359
John Henrich Dela Pena
BSCS ND2A
23/02/21
The  Program are intended to display "Hello World" on the console.
 */

namespace Sample1_HelloWorld
{
    class HelloWorld
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Hello World");
            System.Console.ReadKey();
        }
    }
}
