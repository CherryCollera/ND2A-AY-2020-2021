﻿// 19-03008, 19-01840
// Ocasiones, Rovic Troy
// Malaluan, Francis Vien
// BSCS ND2A

using System;


namespace float_operations
{
    class Program
    {
        static void Main(string[] args)
        {
            float num1, num2;

            Console.Write("Enter First Number: ");
            num1 = float.Parse(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            num2 = float.Parse(Console.ReadLine());

            Console.WriteLine("Sum = {0}", num1 + num2);
            Console.ReadLine();



        }
    }
}
