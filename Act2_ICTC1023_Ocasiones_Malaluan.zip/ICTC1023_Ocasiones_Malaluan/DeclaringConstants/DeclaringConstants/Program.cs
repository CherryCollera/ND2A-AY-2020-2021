﻿// 19-03008, 19-01840
// Malaluan, Francis Vien B
// Ocasiones, Rovic Troy B
//BSCS ND2A
using System;


namespace DeclaringConstants
{
    class Program
    {
        static void Main(string[] args)
        {
            double radius;
            const double pi = 3.14159;

            Console.Write("Enter Radius: ");
            radius = Convert.ToDouble(Console.ReadLine());

            double area = pi * radius * radius;
            Console.Write("Radius: {0:0.0000}   ",radius);
            Console.Write("Area: {0:0.0000}",area);
            Console.ReadLine();
            
            



            

        }
    }
}
