﻿// 19-03008, 19-01840
// Ocasiones, Rovic Troy
// Malaluan, Francis Vien
// BSCS ND2A

using System;


namespace DoubleSum
{
    class Double
    {
        static void Main(string[] args)
        {
            double num1, num2;

            Console.Write("Enter First Number: ");
            num1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            num2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Sum = {0:0.00}", num1 + num2);
            Console.ReadLine();
        }
    }
}
