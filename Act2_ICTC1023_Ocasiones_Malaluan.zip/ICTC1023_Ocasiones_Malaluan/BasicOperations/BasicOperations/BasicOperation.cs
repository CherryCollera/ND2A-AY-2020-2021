﻿// 19-03008, 19-01840
// Ocasiones, Rovic Troy
// Malaluan, Francis Vien
// BSCS ND2A

using System;


namespace BasicOperations
{
    class BasicOperation
    {
        static void Main(string[] args)
        {
            double num1, num2;

            Console.Write("Enter First Number: ");
            num1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter Second Number: ");
            num2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Sum = {0}", num1 + num2);
            Console.WriteLine("Difference = {0}", num1 - num2);
            Console.WriteLine("Product = {0}", num1 * num2);
            Console.WriteLine("Quotient = {0}", num1 / num2);
            Console.WriteLine("Remainder = {0}", num1 % num2);
            Console.ReadLine();
        }
    }
}
