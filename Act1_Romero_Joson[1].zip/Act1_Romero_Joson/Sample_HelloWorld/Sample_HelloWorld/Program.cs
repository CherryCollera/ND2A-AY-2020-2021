﻿/* Romero, Alleyna Jhed : 19-00749
 * Joson, Rachelle Ann : 19-03480
 * ND2A
 * */
using System;

namespace Sample_HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            System.Console.ReadKey();
        }
    }
}
