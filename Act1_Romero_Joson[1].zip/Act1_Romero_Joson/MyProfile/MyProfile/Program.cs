﻿/*Romero, Alleyna Jhed R: 19-00749
 * Joson, Rachelle Ann P:19- 03480
 * ND2A
 */

using System;

namespace MyProfile
{
    class Program
    {
        static void Main(string[] args)
        {
           String Name = "Romero, Alleyna Jhed" ; // name of student
           String DateofBirth = " August 21, 2001"; // birthdate of the student
            String Year = "2nd Year"; // year level
           String Course = "BS Computer Science"; // student course
            String Section = " ND2A"; // Student section

  System.Console.WriteLine(" Name: "+Name+"\n"+ "Birthdate: " + DateofBirth + "\n" + "Year Level: " + Year + "\n" + "Course: " + Course + "\n" + "Section: " + Section);

            System.Console.ReadKey();
        }
    }
}
