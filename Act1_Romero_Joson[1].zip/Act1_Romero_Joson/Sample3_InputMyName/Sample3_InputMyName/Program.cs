﻿/* Romero, Alleyna Jhed, R. ; 19-00749
 * Joson, Rachelle Ann - 19-03480
 *BSCS  nd2a
 * Display declared string
 * feb 26, 2020
 * */

using System;

namespace Sample3_InputMyName
{
    class Program
    {
        static void Main(string[] args)
        {

            string Fullname;
            Console.WriteLine("Enter your full name : "); 
              Fullname = Console.ReadLine();
            Console.WriteLine("Hello {0}", Fullname ) ;
            Console.WriteLine(" Welcome to OOP Environment!!");
               
            
            Console.ReadKey();
        }
    }
}
