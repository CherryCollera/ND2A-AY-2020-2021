﻿/*19-06678
Santos,CristanCarl s,
ND2A
February 23, 2021
This program will display the area and radius of circle*/


using System;

namespace Const_Pie
{
  class Santos_CristanCarl
  {
      static void Main(string[] args)
      {
          float radius;
          double area;

          Console.Write("Enter the Radius: ");
          radius = float.Parse(Console.ReadLine());
          area = Math.PI * radius * radius;

          Console.WriteLine("Radius : " + Math.Round(radius, 4));
          Console.WriteLine("Area : " + Math.Round(area, 4));
      }
  }
}
