﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;//
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;//
using System.Data.SqlClient;

namespace Activity9_Ocasiones
{
    public partial class Form1 : Form
    {
        private OleDbConnection bookCon;
        private OleDbCommand oleDbCmd = new OleDbCommand();

        //Connection String

        private String conParam = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ASH-HOLE\Documents\ICTC1023\Activity9_Ocasiones\book3.accdb";
        //private String conParam = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\ASH-HOLE\Documents\ICTC1023\Activity9_Ocasiones\book3.mdb";

        public Form1()
        {
            bookCon = new OleDbConnection(conParam);
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'book3DataSet1.bookrecords' table. You can move, or remove it, as needed.
            this.bookrecordsTableAdapter1.Fill(this.book3DataSet1.bookrecords);
            // TODO: This line of code loads data into the 'book3DataSet.bookrecords' table. You can move, or remove it, as needed.
            this.bookrecordsTableAdapter.Fill(this.book3DataSet.bookrecords);

        }

        private void AddBtn_Click(object sender, EventArgs e)
        {
            bookCon.Open();
            oleDbCmd.Connection = bookCon; 

            oleDbCmd.CommandText = "Insert into bookrecords (booktitle, description)" + " " + " values ('" + this.BookTextBox.Text + "' , '" + this.DescTextBox.Text + "');";

            int temp = oleDbCmd.ExecuteNonQuery();
            if (temp > 0)
            {
                BookTextBox.Text = null;
                DescTextBox.Text = null;
                MessageBox.Show("Record Added Successfully");
            }
            else 
            {
                
                MessageBox.Show("Failed to Add Record");
            }
            bookCon.Close();
        }

        private void ShowBtn_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter("SELECT * FROM bookrecords", conParam);
            OleDbDataAdapter dAdapter1 = new OleDbDataAdapter("SELECT * FROM bookrecords", conParam);
            OleDbCommandBuilder cBuilder = new OleDbCommandBuilder(dAdapter);

            DataTable dataTable = new DataTable();
            DataSet dataSet = new DataSet();

            dAdapter.Fill(dataTable);

            for (int i = 0; i < dataTable.Rows.Count; i++) 
            {
                dataGridView1.Rows.Add(dataTable.Rows[i][0], dataTable.Rows[i][1]);
            }
        }

        private void BtnCls_Click(object sender, EventArgs e)
        {
            DialogResult choice = MessageBox.Show("Are you sure you want to close the Program?", "Exit", MessageBoxButtons.YesNo);
            if (choice == DialogResult.Yes)
            {
                Application.ExitThread();
            }
            else if (choice == DialogResult.No)
            {
            }
        }
        //Delete Button
        private void BtnDel_Click(object sender, EventArgs e)
        {
            try
            {
                bookCon.Open();
                oleDbCmd.Connection = bookCon;

                oleDbCmd.CommandText = "delete from bookrecords where BookTitle='" + BookTextBox.Text+"'";

                oleDbCmd.ExecuteNonQuery();
                if (string.IsNullOrEmpty(BookTextBox.Text))
                {
                    MessageBox.Show("Select a Record to Delete");
                }
                else 
                {
                    MessageBox.Show("Successfully Deleted!");
                    BookTextBox.Clear();
                    DescTextBox.Clear();
                }

                bookCon.Close();
            }
            catch (Exception ex) 
            {
                MessageBox.Show("Error Occured!");
            }
        }
        //Show Info on TextBox
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            BookTextBox.Text= dataGridView1.CurrentRow.Cells[0].Value.ToString();
            DescTextBox.Text= dataGridView1.CurrentRow.Cells[1].Value.ToString();
        }
    }
}
