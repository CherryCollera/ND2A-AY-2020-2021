﻿/* 19-04378
  Lorefe-Mae T. Monta
  19-04013
  Sta. Niña Marie P. Sacdalan
  ND2A
  February 23, 2021
  This program will display the phrase "Hello World"*/

using System;

namespace Sample1_HelloWorld
{
    class HelloWorld
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.ReadKey();
        }
    }
}
