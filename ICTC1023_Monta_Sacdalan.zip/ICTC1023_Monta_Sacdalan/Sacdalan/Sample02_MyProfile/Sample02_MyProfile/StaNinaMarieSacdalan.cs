﻿/*19-04013
  Sta. Niña Marie P. Sacdalan
  ND2A
  February 23, 2001
  This program will display my Name, Date of Birth, Course, Year&Section*/

using System;

namespace Sample02_MyProfile
{
    class StaNinaMarieSacdalan
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Name: " + "Sta. Niña Marie P. Sacdalan");
            Console.WriteLine("Date of Birth: " + "January 21");
            Console.WriteLine("Course: " + "BS Computer Science major in Network and Data Communication");
            Console.WriteLine("Year: " + "II");
            Console.WriteLine("Secton: " + "A");
            Console.ReadKey();
        }
    }
}
