﻿/*19-04013
  Sta. Niña Marie P. Sacdalan
  ND2A
  February 23, 2001
  This program, the user will input their name and display it*/

using System;

namespace Sample03_InputMyName
{
    class StaNinaMarieSacdalan
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your name <firstname lastname> ");
            string name = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine("Hello " + name + "!!!");
            Console.WriteLine("Welcome to OOP environment.");
            Console.ReadKey();
        }
    }
}
