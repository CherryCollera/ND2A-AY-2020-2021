﻿/*19-04378
  Lorefe-Mae Monta
  ND2A
  February 23, 2001
  This program will display my Name, Date of Birth, Course, Year&Section*/

using System;

namespace Sample2_MyProfile
{
    class LorefeMaeMonta
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Name: " + "Lorefe-Mae T. Monta");
            Console.WriteLine();
            Console.WriteLine("Date of Birth: " + "July 03");
            Console.WriteLine();
            Console.WriteLine("Course: " + "BS Computer Science");
            Console.WriteLine();
            Console.WriteLine("Year: " + "II");
            Console.WriteLine();
            Console.WriteLine("Secton: " + "A");
            Console.ReadKey();
        }
    }
}
