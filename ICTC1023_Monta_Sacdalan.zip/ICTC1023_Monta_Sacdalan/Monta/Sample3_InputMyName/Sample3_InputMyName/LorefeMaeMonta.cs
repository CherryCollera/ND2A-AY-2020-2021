﻿/*19-04378
  Lorefe-Mae Monta
  ND2A
  February 23, 2001
  This program, the user will input their name and display it*/

using System;

namespace Sample3_InputMyName
{
    class LorefeMaeMonta
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your name <firstname lastname> ");
            string name = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine("Hello " + name + "!!!");
            Console.WriteLine("Welcome to OOP environment.");
            Console.ReadKey();
        }
    }
}
