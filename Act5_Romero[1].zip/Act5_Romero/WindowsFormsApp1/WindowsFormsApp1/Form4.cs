﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form4 : Form
    {

        double a, b, result;
        private object fnumber;
        private object snumber;
        private object answer;

        public Form4()
        {
            InitializeComponent();
        }

        private void plus_Click(object sender, EventArgs e)
        {

            a = Convert.ToDouble(fnumber.Text);
            b = Convert.ToDouble(snumber.Text);
            result = a + b;
            answer.Text = result.ToString();

        }

        private void minus_Click(object sender, EventArgs e)
        {

            a = Convert.ToDouble(fnumber.Text);
            b = Convert.ToDouble(snumber.Text);
            result = a - b;
            answer.Text = result.ToString();

        }

        private void multiplication_Click(object sender, EventArgs e)
        {

            a = Convert.ToDouble(fnumber.Text);
            b = Convert.ToDouble(snumber.Text);
            result = a * b;
            answer.Text = result.ToString();

        }


        private void Form4_Load(object sender, EventArgs e)
        {

            MaximizeBox = false;
            MinimizeBox = false;
            ControlBox = false;
        }

        private void back_Click_1(object sender, EventArgs e)
        {
            Form3 frm = new Form3();
            frm.Show();
            this.Hide();

        }

        private void Clear_Click(object sender, EventArgs e)
        {
            fnumber.Clear();
            snumber.Clear();
            answer.Clear();
        }

        private void divide_Click(object sender, EventArgs e)
        {

            a = Convert.ToDouble(fnumber.Text);
            b = Convert.ToDouble(snumber.Text);
            result = a / b;
            answer.Text = result.ToString();

        }

    }
}

