﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        private object ayt;
        private object ajr;

        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String firstname = ajr.Text;
            String lastname = ayt.Text;


            MessageBox.Show("\tHello " + firstname+ " " + lastname + "\n\n" + "\n****MY PROFILE***\n" + "Date of Birth\t:\tAugust 21,2001\n" + "Course\t\t:\tBS Computer Science Major in Network and Data Communication\n" + "Year\t\t:\tII\n" + "Section\t\t:\tA");




        }

        private void Button3_Click(object sender, EventArgs e)

        {
            Form4 frm = new Form4();
            frm.Show();
            this.Hide();
        }

        private void Button2_Click(object sender, EventArgs e)
        {

            Form3 frm = new Form3();
            frm.Show();
            this.Hide();
        }


    }
}

