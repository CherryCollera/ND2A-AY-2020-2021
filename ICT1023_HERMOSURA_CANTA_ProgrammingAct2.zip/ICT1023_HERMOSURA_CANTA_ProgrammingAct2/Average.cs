﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Average
{
    class Program
    {
        static void Main(string[] args)
        {


            double num1, num2, num3, num4, num5;

            Console.Write("Enter 1st grade: ");
            num1 = Convert.ToDouble(Console.ReadLine());
           
            Console.Write("Enter 2nd grade: ");
            num2 = Convert.ToDouble(Console.ReadLine());
            
            Console.Write("Enter 3rd grade: ");
            num3 = Convert.ToDouble(Console.ReadLine());
            
            Console.Write("Enter 4th grade: ");
            num4 = Convert.ToDouble(Console.ReadLine());
           
            Console.Write("Enter 5th grade: ");
            num5 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Average = {0}", (num1 + num2 + num3 + num4 + num5) / 5);
            Console.ReadKey();



        }
    }
}
