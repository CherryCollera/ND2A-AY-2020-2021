﻿using System;

namespace Double
{
    class Program
    {
        static void Main(string[] args)
        {

            double num1, num2;

            Console.WriteLine("Enter First Number:");


            num1 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter Second Number");
            num2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Sum = " + (num1 + num2));
            Console.ReadLine();








        }
    }
}
