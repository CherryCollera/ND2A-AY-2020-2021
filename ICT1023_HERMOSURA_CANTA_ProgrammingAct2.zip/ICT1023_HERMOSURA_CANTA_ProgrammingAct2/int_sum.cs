﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sum
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;

            Console.WriteLine("Enter First Number:");
            num1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Second Number");
            num2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Sum = " + (num1 + num2));
            Console.ReadLine();    
        
        
        
        
        
        
        
        }
    }
}
