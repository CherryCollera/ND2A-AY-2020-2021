﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cons_double_pi
{
    class Program
    {
        static void Main(string[] args)
        {

            const double pi =3.14159;
            double r, area;
            Console.WriteLine("Enter Radius: ");
            r = Convert.ToDouble(Console.ReadLine());

            area = pi * r * r;

            Console.WriteLine(("Radius: " + r) + (", Area: " + area));











        }
    }
}
