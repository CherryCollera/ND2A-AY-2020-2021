﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoWhile
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] Tal_nms = new int[] { 6, 7, 8, 10 };
            int Tal_sum = 0;
            int i = 0;

            do
            {
                Tal_sum += Tal_nms[i];
                i++;
            } while (i < 4);

            Console.WriteLine(Tal_sum);
            Console.ReadLine();
        }
    }
}
