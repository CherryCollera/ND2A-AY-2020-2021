﻿using System;

namespace comparesname
{
    class Program
    {
        static void Main(string[] args)
        {
            string JRLM1 = "JoannaRuf";
            string JRLM2 = "JoannaRuf";
            string JRLM3 = "Joanna";
            string JRLM4 = "joannaruffe";
            string JRLM5 = "JOANNARUFFE";
            Console.WriteLine("\nUsing Equals() method");

            Console.WriteLine("compare {0} to {1}: {2}", JRLM1, JRLM2, String.Equals(JRLM1, JRLM2));
            Console.WriteLine("compare {0} to {1}: {2}", JRLM1, JRLM3, String.Equals(JRLM1, JRLM3));
            Console.WriteLine("Length of {0} is {1}", JRLM1, JRLM1.Length);
            Console.WriteLine("String {0} Substring(0,3) will return {1}", JRLM5, JRLM5.Substring(0, 3));

            Console.WriteLine("\nUsing Compare() method");

            Console.WriteLine("compare {0} to {1}: {2}", JRLM1, JRLM2, String.Compare(JRLM1, JRLM2));
            Console.WriteLine("compare {0} to {1}: {2}", JRLM1, JRLM3, String.Compare(JRLM1, JRLM3));
            Console.WriteLine("compare {0} to {1}: {2}", JRLM3, JRLM1, String.Compare(JRLM3, JRLM1));
            Console.WriteLine("compare {0} to {1}: {2}", JRLM4, JRLM5, String.Equals(JRLM4, JRLM5));

            Console.WriteLine("\nUsing CompareTo() method");
            
            Console.WriteLine(" compare {0} to {1}: {2}", JRLM1, JRLM2, JRLM1.CompareTo(JRLM2));
            Console.WriteLine(" compare {0} to {1}: {2}", JRLM1, JRLM3, JRLM1.CompareTo(JRLM3));
            Console.WriteLine(" compare {0} to {1}: {2}", JRLM3, JRLM1, JRLM3.CompareTo(JRLM1));
            Console.ReadKey();
        }
    }
}
