﻿using System;


namespace DoWhile
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] JRLM_nms = new int[] { 6, 7, 8, 10 };
            int JRLM_sum = 0;
            int i = 0;

            do
            {
                JRLM_sum += JRLM_nms[i];
                i++;
            } while (i < 4);

            Console.WriteLine(JRLM_sum);
            Console.ReadLine();
        }
    }
}
