﻿using System;


namespace GradingSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            int fgrade;

            Console.Write("Enter your final grade: ");
            fgrade = Convert.ToInt32(Console.ReadLine());

            if (fgrade >= 98)
            {
                Console.WriteLine("Grade Equivalent: 1.00");
                Console.WriteLine("Remarks         : Excellent");
            }
            else if (fgrade >= 95)
            {
                Console.WriteLine("Grade Equivalent: 1.25");
                Console.WriteLine("Remarks         : Excellent");
            }
            else if (fgrade >= 92)
            {
                Console.WriteLine("Grade Equivalent: 1.50");
                Console.WriteLine("Remarks         : Very Good");
            }
            else if (fgrade >= 89)
            {
                Console.WriteLine("Grade Equivalent: 1.75");
                Console.WriteLine("Remarks         : Very Good");
            }
            else if (fgrade >= 86)
            {
                Console.WriteLine("Grade Equivalent: 2.00");
                Console.WriteLine("Remarks         : Good");
            }
            else if (fgrade >= 83)
            {
                Console.WriteLine("Grade Equivalent: 2.25");
                Console.WriteLine("Remarks         : Good");
            }
            else if (fgrade >= 80)
            {
                Console.WriteLine("Grade Equivalent: 2.50");
                Console.WriteLine("Remarks         : Fair");
            }
            else if (fgrade >= 77)
            {
                Console.WriteLine("Grade Equivalent: 2.75");
                Console.WriteLine("Remarks         : Fair");
            }
            else if (fgrade >= 75)
            {
                Console.WriteLine("Grade Equivalent: 3.00");
                Console.WriteLine("Remarks         : Passed");
            }
            else if (fgrade >= 72)
            {
                Console.WriteLine("Grade Equivalent: 4.00");
                Console.WriteLine("Remarks         : Conditional (MT only)");
            }
            else if (fgrade >= 60)
            {
                Console.WriteLine("Grade Equivalent: 5.00");
                Console.WriteLine("Remarks         : Failed");
            }
            else
            {
                Console.WriteLine("Remarks: Incomplete");
            }
            Console.ReadLine();
        }
    }
}
