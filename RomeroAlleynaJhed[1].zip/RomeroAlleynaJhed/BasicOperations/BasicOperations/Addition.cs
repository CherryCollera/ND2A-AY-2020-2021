﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations
{
    class Addition
    {
        public void ComputeSum()
        {
            Declarevar.sum = Declarevar.num1 + Declarevar.num2;
            System.Console.WriteLine("Sum is " + Declarevar.sum);
        }
    }
}