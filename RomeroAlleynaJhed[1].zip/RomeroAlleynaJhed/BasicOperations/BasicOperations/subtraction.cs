﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations
{
    class Subtraction
    {
        public void ComputeDiff()
        {
            Declarevar.diff = Declarevar.num1 - Declarevar.num2;
            System.Console.WriteLine("Difference is " + Declarevar.diff);
        }
    }
}