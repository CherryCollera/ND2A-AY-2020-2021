﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations
{
    class product
    {
        public void ComputeProduct()
        {
            Declarevar.product = Declarevar.num1 * Declarevar.num2;
            System.Console.WriteLine("Product is " + Declarevar.product);
        }
    }
}