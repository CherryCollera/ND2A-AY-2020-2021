﻿/* Romero, Alleyna Jhed
 * 19-00749
 * ND2A
 * March 19,2021
 */
using System;


namespace BasicOperations
{
	class Program
	{
		public static void Main()
		{
			Input i = new Input();
			i.InputData();
			Addition a = new Addition();
			a.ComputeSum();
			Subtraction s = new Subtraction();
			s.ComputeDiff();
			Product p = new Product();
			p.ComputeProduct();
			Division d = new Division();
			d.ComputeDiv();
			Remainder r = new Remainder();
			r.ComputeRem();
			Console.ReadKey();
		}
	}
}