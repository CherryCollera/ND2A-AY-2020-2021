﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations
{
    class Division
    {
        public void ComputeDiv()
        {
            Declarevar.quo = Declarevar.num1 / Declarevar.num2;
            System.Console.WriteLine("Quotient is " + Declarevar.quo);
        }
    }
}