﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperation_Castillo
{
    class Declarevar
    {
        public static double num1, num2, sum, diff, product, quo, rem;
    }
}
