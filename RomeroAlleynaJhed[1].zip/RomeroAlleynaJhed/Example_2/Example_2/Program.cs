﻿
using System;


namespace Example_2
{
    class Program
    {
        public static void Main()
        {
            Car car;
            car = new Car("Red");
            Console.WriteLine(car.Describe());
            car = new Car("Green");
            Console.WriteLine(car.Describe());
            Console.ReadKey();
        }
    }
}