﻿using System;


namespace Example_2
{
    class Declaration
    {
        public string color
        {
            get
            {
                return color;
            }
            set
            {
                color = value;
            }
        }
    }
}
