﻿using System;


namespace Class_Example1
{
    class Accept
    {
        public string AJRfname, AJRlname;
        public void AcceptDetails()
        {
            Console.Write("Enter your First Name: ");
            AJRfname = Console.ReadLine();
            Console.Write("Enter your Last Name: ");
            AJRlname = Console.ReadLine();
        }
    }
}