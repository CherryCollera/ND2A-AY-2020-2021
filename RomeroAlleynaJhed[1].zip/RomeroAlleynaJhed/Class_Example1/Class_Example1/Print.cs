﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Example1
{
    class Print
    {
        public void PrintDetails()
        {
            Accept a = new Accept();
            a.AcceptDetails();
            Console.Write("Hello! " + a.AJRfname + " " + a.AJRlname + "!!!\n You have created classes in OOP.");
            MyProfile mp = new MyProfile();
            mp.DisplayProfile();
        }
    }
}