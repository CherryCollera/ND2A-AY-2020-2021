﻿using System;

namespace Class_Example1
{
    class MyProfile
    {
        public void DisplayProfile()
        {
            Console.WriteLine("\n\n\n\t\t\t\tP R O F I L E ");
            Console.WriteLine("Name:\t\t\tRomero, Alleyna Jhed ");
            Console.WriteLine("Birthday:\t\tAugust 21,2001 ");
            Console.WriteLine("Course:\t\t\tBS in Computer Science major in Network and Data Communication ");
            Console.WriteLine("Year:\t\t2nd Year ");
            Console.WriteLine("Section:\t\t\tA ");
            Console.ReadKey();
        }
    }
}