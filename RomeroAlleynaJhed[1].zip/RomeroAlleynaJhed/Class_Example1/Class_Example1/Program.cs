﻿
using System;


namespace Class_Example1
{
    class Program
    {
        static void Main(string[] args)
        {
            Print p = new Print();
            p.PrintDetails();
            Console.ReadKey();
        }
    }
}