﻿using System;


namespace Example2
{
    class Declaration
    {
        public string Color
        {
            get
            {
                return Color;
            }
            set
            {
                Color = value;
            }
        }
    }
}
