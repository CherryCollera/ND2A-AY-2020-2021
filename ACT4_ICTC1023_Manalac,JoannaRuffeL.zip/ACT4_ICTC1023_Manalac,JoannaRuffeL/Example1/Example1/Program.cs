﻿using System;


namespace Example1
{
    class Program //Creating 4th class
    {
        static void Main(string[] args)
        {
            Print p = new Print();
            p.PrintDetails();
            Console.ReadLine();
        }
    }
}
