﻿using System;


namespace BasicOperation
{
    class Remainder
    {
        public void ComputeRemainder()
        {
            DeclareVar.remainder = DeclareVar.num1 % DeclareVar.num2;
            System.Console.WriteLine("\nThe remainder is " + DeclareVar.remainder);
        }
    }
}
