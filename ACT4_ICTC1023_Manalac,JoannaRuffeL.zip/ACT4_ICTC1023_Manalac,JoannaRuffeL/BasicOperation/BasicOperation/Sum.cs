﻿using System;


namespace BasicOperation
{
    class Sum
    {
        public void ComputeSum()
        {
            DeclareVar.sum = DeclareVar.num1 + DeclareVar.num2;
            System.Console.WriteLine("\nThe sum is " + DeclareVar.sum);
        }
    }
}
