﻿using System;


namespace CompareNum
{
    class Program
    {
        static void Main(string[] args)
        {
            int JRLM20_num1, JRLM20_num2, JRLM20_num3;

            Console.Write("Enter First Number: ");
            JRLM20_num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            JRLM20_num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Third Number: ");
            JRLM20_num3 = Convert.ToInt32(Console.ReadLine());

            if (JRLM20_num1 > JRLM20_num2 && JRLM20_num1 > JRLM20_num3)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", JRLM20_num1, JRLM20_num2, JRLM20_num3);
                Console.WriteLine("{0} is less than {1}", JRLM20_num2, JRLM20_num1);
                Console.WriteLine("{0} is less than {1}", JRLM20_num3, JRLM20_num1);
            }
            else if (JRLM20_num2 > JRLM20_num1 && JRLM20_num2 > JRLM20_num3)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", JRLM20_num2, JRLM20_num1, JRLM20_num3);
                Console.WriteLine("{0} is less than {1}", JRLM20_num1, JRLM20_num2);
                Console.WriteLine("{0} is less than {1}", JRLM20_num3, JRLM20_num2);
            }
            else if (JRLM20_num3 > JRLM20_num1 && JRLM20_num3 > JRLM20_num2)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", JRLM20_num3, JRLM20_num1, JRLM20_num2);
                Console.WriteLine("{0} is less than {1}", JRLM20_num1, JRLM20_num3);
                Console.WriteLine("{0} is less than {1}", JRLM20_num2, JRLM20_num3);
            }
            else if (JRLM20_num3 == JRLM20_num1 && JRLM20_num3 == JRLM20_num2)
            {
                Console.WriteLine("{0}, {1} and {2} are equal", JRLM20_num1, JRLM20_num2, JRLM20_num3);

            }
            Console.ReadLine();
        }
    }
}
