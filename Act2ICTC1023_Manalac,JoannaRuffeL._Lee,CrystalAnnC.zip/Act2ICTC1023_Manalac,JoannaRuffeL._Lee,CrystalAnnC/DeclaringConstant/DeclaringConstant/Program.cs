﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeclaringConstant
{
    class Program
    {
        static void Main(string[] args)
        {
            double AreaCircle;
            const double pi = 3.14159;

            Console.Write("Type  the Radius: ");
            double radius = Convert.ToDouble(Console.ReadLine());

            AreaCircle = pi * (radius * radius);

            Console.WriteLine();
            Console.Write("Radius: {0:N4}", radius + "\t\t");
            Console.Write("Area: {0:N4}", AreaCircle);
            Console.ReadLine();
        }
    }
}
