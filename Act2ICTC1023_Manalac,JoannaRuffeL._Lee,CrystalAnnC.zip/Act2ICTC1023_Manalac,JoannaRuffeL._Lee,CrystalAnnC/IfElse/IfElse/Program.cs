﻿using System;


namespace IfElse
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, num3;

            Console.Write(" Enter First Number : ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write(" Enter Second Number : ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write(" Enter Third Number : ");
            num3 = Convert.ToInt32(Console.ReadLine());

            if (num1 > num2)
            {
                Console.WriteLine("{0} is greater than {1} and {2}", num1, num2, num3);
            }
            else if (num1 < num2)
            {
                Console.WriteLine("{0} is less than {1} and {2}", num1, num2, num3);
            }
            else
                Console.WriteLine("{0} is equal {1} and {2}", num1, num2, num3);
            Console.ReadLine();
        }
    }
}
