﻿/*19-03008
 * Ocasiones, Rovic Troy B.
 * BSCS ND2A */

using System;

namespace ClassExample2_Ocasiones
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car;
            car = new Car("Blue");
            Console.WriteLine(car.Describe());
            car = new Car("Black");
            Console.WriteLine(car.Describe());
            Console.ReadLine();
        }
    }
}
