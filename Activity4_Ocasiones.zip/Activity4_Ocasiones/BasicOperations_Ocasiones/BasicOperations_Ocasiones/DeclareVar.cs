﻿
class DeclareVar
{
    public static double num1, num2, sum, diff, prod, quot, remain;
    public void DeclareValues() 
    { 
    
    }
}

