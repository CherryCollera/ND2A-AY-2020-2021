﻿
class Quotient
{
    public void ComputeQuotient()
    {

        DeclareVar.quot = DeclareVar.num1 / DeclareVar.num2;

    }
}

