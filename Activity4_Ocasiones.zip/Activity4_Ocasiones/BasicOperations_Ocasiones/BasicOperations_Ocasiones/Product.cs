﻿
class Product
{
    public void ComputeProduct()
    {

        DeclareVar.prod = DeclareVar.num1 * DeclareVar.num2;

    }
}

