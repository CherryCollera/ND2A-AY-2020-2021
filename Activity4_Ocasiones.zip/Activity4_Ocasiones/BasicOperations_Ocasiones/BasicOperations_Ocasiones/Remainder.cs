﻿
class Remainder
{
    public void ComputeRemainder()
    {

        DeclareVar.remain = DeclareVar.num1 % DeclareVar.num2;

    }
}
