﻿
class Difference
{
    public void ComputeDifference()
    {

        DeclareVar.diff = DeclareVar.num1 - DeclareVar.num2;

    }
}

