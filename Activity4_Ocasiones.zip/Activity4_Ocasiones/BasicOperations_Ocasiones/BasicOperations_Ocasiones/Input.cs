﻿
class Input
    {
        public void GetInput() 
        { 
            System.Console.Write("\n\n\n\t\tEnter First Number: ");
            DeclareVar.num1 = System.Convert.ToDouble(System.Console.ReadLine());

            System.Console.Write("\n\t\tEnter Second Number: ");
            DeclareVar.num2 = System.Convert.ToDouble(System.Console.ReadLine());
        }
    }
