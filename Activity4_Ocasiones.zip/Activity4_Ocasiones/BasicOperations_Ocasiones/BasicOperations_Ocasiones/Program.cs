﻿/*19-03008
 * Ocasiones, Rovic Troy B.
 * BSCS ND2A */

using System;

namespace BasicOperations_Ocasiones
{
    class Program
    {
        static void Main(string[] args)
        {
            Input i = new Input();
            i.GetInput();

            Sum s = new Sum();
            s.ComputeSum();

            Difference d = new Difference();
            d.ComputeDifference();

            Product p = new Product();
            p.ComputeProduct();

            Quotient q = new Quotient();
            q.ComputeQuotient();

            Remainder r = new Remainder();
            r.ComputeRemainder();


            System.Console.WriteLine("\n\t\tSum        = {0}", DeclareVar.sum);
            System.Console.WriteLine("\t\tDifference = {0}", DeclareVar.diff);
            System.Console.WriteLine("\t\tProduct    = {0}", DeclareVar.prod);
            System.Console.WriteLine("\t\tQuotient   = {0:0.00}", DeclareVar.quot);
            System.Console.WriteLine("\t\tRemainder  = {0}", DeclareVar.remain);
            System.Console.ReadLine();
        }
    }
}
