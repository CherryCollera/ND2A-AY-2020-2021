﻿/*19-03008
 * Ocasiones, Rovic Troy B.
 * BSCS ND2A */

using System;

namespace ClassExample1_Ocasiones
{
    class Program
    {
        static void Main(string[] args)
        {
            Print p = new Print();
            p.PrintDetails();
            Console.ReadLine();

        }
    }
}
