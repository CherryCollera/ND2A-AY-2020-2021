﻿
class MyProfile
{
    public void DisplayProfile()
    {
        System.Console.WriteLine("\n\n\t\t\tYOUR PROFILE");
        System.Console.WriteLine("Name    : Rovic Ocasiones");
        System.Console.WriteLine("Birthday: March 19, 2001");
        System.Console.WriteLine("Course  : BS in Computer Science Major in Network and Data Communication");
        System.Console.WriteLine("Year    : 2nd Year");
        System.Console.WriteLine("Section : ND2A");
        System.Console.ReadLine();
    }

}

