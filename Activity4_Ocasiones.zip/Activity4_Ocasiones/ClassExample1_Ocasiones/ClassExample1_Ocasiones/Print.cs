﻿
namespace ClassExample1_Ocasiones
{
    class Print
    {
        public void PrintDetails()
        {
            Accept a = new Accept();
            a.AcceptDetails();

            System.Console.Write("Hello " + a.fname + " " + a.lname +"!" +"\nYou have created classes in OOP!!!");

            MyProfile mp = new MyProfile();
            mp.DisplayProfile();
        }

    }
}
