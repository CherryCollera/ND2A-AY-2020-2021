﻿
class Accept
{
    public string fname, lname;
    public void AcceptDetails()
    {
        System.Console.Write("Enter your Firstname and Lastname: ");
        fname = System.Console.ReadLine();
        lname = System.Console.ReadLine();
    }
}
