﻿
namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.bSCS_StudentsToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSCS_StudentsToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.studIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.middleNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.birthdayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.programDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sectionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yearLevelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblStudentInfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.studentsDataSet = new WindowsFormsApp1.studentsDataSet();
            this.tblStudent_InfoTableAdapter = new WindowsFormsApp1.studentsDataSetTableAdapters.tblStudent_InfoTableAdapter();
            this.bSIT_StudentsToolStrip = new System.Windows.Forms.ToolStrip();
            this.bSIT_StudentsToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.address_BalangaToolStrip = new System.Windows.Forms.ToolStrip();
            this.address_BalangaToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.second_Year_StudentsToolStrip = new System.Windows.Forms.ToolStrip();
            this.second_Year_StudentsToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.refreshToolStrip = new System.Windows.Forms.ToolStrip();
            this.refreshToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.lastname_that_start_with_A_and_CToolStrip = new System.Windows.Forms.ToolStrip();
            this.lastname_that_start_with_A_and_CToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.section_2BToolStrip = new System.Windows.Forms.ToolStrip();
            this.section_2BToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.firstname_that_start_with_consonantToolStrip = new System.Windows.Forms.ToolStrip();
            this.firstname_that_start_with_consonantToolStripButton = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.bSCS_StudentsToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentInfoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsDataSet)).BeginInit();
            this.bSIT_StudentsToolStrip.SuspendLayout();
            this.address_BalangaToolStrip.SuspendLayout();
            this.second_Year_StudentsToolStrip.SuspendLayout();
            this.refreshToolStrip.SuspendLayout();
            this.lastname_that_start_with_A_and_CToolStrip.SuspendLayout();
            this.section_2BToolStrip.SuspendLayout();
            this.firstname_that_start_with_consonantToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(467, 31);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(332, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Students Record Monitoring System";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.MenuHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.studIDDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.middleNameDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.birthdayDataGridViewTextBoxColumn,
            this.programDataGridViewTextBoxColumn,
            this.sectionDataGridViewTextBoxColumn,
            this.yearLevelDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tblStudentInfoBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(167, 79);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(945, 182);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // bSCS_StudentsToolStrip
            // 
            this.bSCS_StudentsToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSCS_StudentsToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSCS_StudentsToolStripButton});
            this.bSCS_StudentsToolStrip.Location = new System.Drawing.Point(167, 274);
            this.bSCS_StudentsToolStrip.Name = "bSCS_StudentsToolStrip";
            this.bSCS_StudentsToolStrip.Size = new System.Drawing.Size(101, 25);
            this.bSCS_StudentsToolStrip.TabIndex = 2;
            this.bSCS_StudentsToolStrip.Text = "bSCS_StudentsToolStrip";
            // 
            // bSCS_StudentsToolStripButton
            // 
            this.bSCS_StudentsToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSCS_StudentsToolStripButton.Name = "bSCS_StudentsToolStripButton";
            this.bSCS_StudentsToolStripButton.Size = new System.Drawing.Size(89, 22);
            this.bSCS_StudentsToolStripButton.Text = "BSCS_Students";
            this.bSCS_StudentsToolStripButton.Click += new System.EventHandler(this.bSCS_StudentsToolStripButton_Click);
            // 
            // studIDDataGridViewTextBoxColumn
            // 
            this.studIDDataGridViewTextBoxColumn.DataPropertyName = "StudID";
            this.studIDDataGridViewTextBoxColumn.HeaderText = "StudID";
            this.studIDDataGridViewTextBoxColumn.Name = "studIDDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // middleNameDataGridViewTextBoxColumn
            // 
            this.middleNameDataGridViewTextBoxColumn.DataPropertyName = "MiddleName";
            this.middleNameDataGridViewTextBoxColumn.HeaderText = "MiddleName";
            this.middleNameDataGridViewTextBoxColumn.Name = "middleNameDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            // 
            // birthdayDataGridViewTextBoxColumn
            // 
            this.birthdayDataGridViewTextBoxColumn.DataPropertyName = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.HeaderText = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.Name = "birthdayDataGridViewTextBoxColumn";
            // 
            // programDataGridViewTextBoxColumn
            // 
            this.programDataGridViewTextBoxColumn.DataPropertyName = "Program";
            this.programDataGridViewTextBoxColumn.HeaderText = "Program";
            this.programDataGridViewTextBoxColumn.Name = "programDataGridViewTextBoxColumn";
            // 
            // sectionDataGridViewTextBoxColumn
            // 
            this.sectionDataGridViewTextBoxColumn.DataPropertyName = "Section";
            this.sectionDataGridViewTextBoxColumn.HeaderText = "Section";
            this.sectionDataGridViewTextBoxColumn.Name = "sectionDataGridViewTextBoxColumn";
            // 
            // yearLevelDataGridViewTextBoxColumn
            // 
            this.yearLevelDataGridViewTextBoxColumn.DataPropertyName = "YearLevel";
            this.yearLevelDataGridViewTextBoxColumn.HeaderText = "YearLevel";
            this.yearLevelDataGridViewTextBoxColumn.Name = "yearLevelDataGridViewTextBoxColumn";
            // 
            // tblStudentInfoBindingSource
            // 
            this.tblStudentInfoBindingSource.DataMember = "tblStudent_Info";
            this.tblStudentInfoBindingSource.DataSource = this.studentsDataSet;
            // 
            // studentsDataSet
            // 
            this.studentsDataSet.DataSetName = "studentsDataSet";
            this.studentsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblStudent_InfoTableAdapter
            // 
            this.tblStudent_InfoTableAdapter.ClearBeforeFill = true;
            // 
            // bSIT_StudentsToolStrip
            // 
            this.bSIT_StudentsToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.bSIT_StudentsToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bSIT_StudentsToolStripButton});
            this.bSIT_StudentsToolStrip.Location = new System.Drawing.Point(167, 309);
            this.bSIT_StudentsToolStrip.Name = "bSIT_StudentsToolStrip";
            this.bSIT_StudentsToolStrip.Size = new System.Drawing.Size(97, 25);
            this.bSIT_StudentsToolStrip.TabIndex = 3;
            this.bSIT_StudentsToolStrip.Text = "bSIT_StudentsToolStrip";
            // 
            // bSIT_StudentsToolStripButton
            // 
            this.bSIT_StudentsToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSIT_StudentsToolStripButton.Name = "bSIT_StudentsToolStripButton";
            this.bSIT_StudentsToolStripButton.Size = new System.Drawing.Size(85, 22);
            this.bSIT_StudentsToolStripButton.Text = "BSIT_Students";
            this.bSIT_StudentsToolStripButton.Click += new System.EventHandler(this.bSIT_StudentsToolStripButton_Click);
            // 
            // address_BalangaToolStrip
            // 
            this.address_BalangaToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.address_BalangaToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.address_BalangaToolStripButton});
            this.address_BalangaToolStrip.Location = new System.Drawing.Point(167, 344);
            this.address_BalangaToolStrip.Name = "address_BalangaToolStrip";
            this.address_BalangaToolStrip.Size = new System.Drawing.Size(112, 25);
            this.address_BalangaToolStrip.TabIndex = 4;
            this.address_BalangaToolStrip.Text = "address_BalangaToolStrip";
            // 
            // address_BalangaToolStripButton
            // 
            this.address_BalangaToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.address_BalangaToolStripButton.Name = "address_BalangaToolStripButton";
            this.address_BalangaToolStripButton.Size = new System.Drawing.Size(100, 22);
            this.address_BalangaToolStripButton.Text = "Address_Balanga";
            this.address_BalangaToolStripButton.Click += new System.EventHandler(this.address_BalangaToolStripButton_Click);
            // 
            // second_Year_StudentsToolStrip
            // 
            this.second_Year_StudentsToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.second_Year_StudentsToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.second_Year_StudentsToolStripButton});
            this.second_Year_StudentsToolStrip.Location = new System.Drawing.Point(167, 382);
            this.second_Year_StudentsToolStrip.Name = "second_Year_StudentsToolStrip";
            this.second_Year_StudentsToolStrip.Size = new System.Drawing.Size(141, 25);
            this.second_Year_StudentsToolStrip.TabIndex = 5;
            this.second_Year_StudentsToolStrip.Text = "second_Year_StudentsToolStrip";
            // 
            // second_Year_StudentsToolStripButton
            // 
            this.second_Year_StudentsToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.second_Year_StudentsToolStripButton.Name = "second_Year_StudentsToolStripButton";
            this.second_Year_StudentsToolStripButton.Size = new System.Drawing.Size(129, 22);
            this.second_Year_StudentsToolStripButton.Text = "Second_Year_Students";
            this.second_Year_StudentsToolStripButton.Click += new System.EventHandler(this.second_Year_StudentsToolStripButton_Click);
            // 
            // refreshToolStrip
            // 
            this.refreshToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.refreshToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshToolStripButton});
            this.refreshToolStrip.Location = new System.Drawing.Point(167, 416);
            this.refreshToolStrip.Name = "refreshToolStrip";
            this.refreshToolStrip.Size = new System.Drawing.Size(62, 25);
            this.refreshToolStrip.TabIndex = 6;
            this.refreshToolStrip.Text = "refreshToolStrip";
            // 
            // refreshToolStripButton
            // 
            this.refreshToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.refreshToolStripButton.Name = "refreshToolStripButton";
            this.refreshToolStripButton.Size = new System.Drawing.Size(50, 22);
            this.refreshToolStripButton.Text = "Refresh";
            this.refreshToolStripButton.Click += new System.EventHandler(this.refreshToolStripButton_Click);
            // 
            // lastname_that_start_with_A_and_CToolStrip
            // 
            this.lastname_that_start_with_A_and_CToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.lastname_that_start_with_A_and_CToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lastname_that_start_with_A_and_CToolStripButton});
            this.lastname_that_start_with_A_and_CToolStrip.Location = new System.Drawing.Point(167, 451);
            this.lastname_that_start_with_A_and_CToolStrip.Name = "lastname_that_start_with_A_and_CToolStrip";
            this.lastname_that_start_with_A_and_CToolStrip.Size = new System.Drawing.Size(207, 25);
            this.lastname_that_start_with_A_and_CToolStrip.TabIndex = 7;
            this.lastname_that_start_with_A_and_CToolStrip.Text = "lastname_that_start_with_A_and_CToolStrip";
            // 
            // lastname_that_start_with_A_and_CToolStripButton
            // 
            this.lastname_that_start_with_A_and_CToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.lastname_that_start_with_A_and_CToolStripButton.Name = "lastname_that_start_with_A_and_CToolStripButton";
            this.lastname_that_start_with_A_and_CToolStripButton.Size = new System.Drawing.Size(195, 22);
            this.lastname_that_start_with_A_and_CToolStripButton.Text = "Lastname_that_start_with_A_and_C";
            this.lastname_that_start_with_A_and_CToolStripButton.Click += new System.EventHandler(this.lastname_that_start_with_A_and_CToolStripButton_Click);
            // 
            // section_2BToolStrip
            // 
            this.section_2BToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.section_2BToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.section_2BToolStripButton});
            this.section_2BToolStrip.Location = new System.Drawing.Point(167, 487);
            this.section_2BToolStrip.Name = "section_2BToolStrip";
            this.section_2BToolStrip.Size = new System.Drawing.Size(80, 25);
            this.section_2BToolStrip.TabIndex = 8;
            this.section_2BToolStrip.Text = "section_2BToolStrip";
            // 
            // section_2BToolStripButton
            // 
            this.section_2BToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.section_2BToolStripButton.Name = "section_2BToolStripButton";
            this.section_2BToolStripButton.Size = new System.Drawing.Size(68, 22);
            this.section_2BToolStripButton.Text = "Section_2B";
            this.section_2BToolStripButton.Click += new System.EventHandler(this.section_2BToolStripButton_Click);
            // 
            // firstname_that_start_with_consonantToolStrip
            // 
            this.firstname_that_start_with_consonantToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.firstname_that_start_with_consonantToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.firstname_that_start_with_consonantToolStripButton});
            this.firstname_that_start_with_consonantToolStrip.Location = new System.Drawing.Point(167, 522);
            this.firstname_that_start_with_consonantToolStrip.Name = "firstname_that_start_with_consonantToolStrip";
            this.firstname_that_start_with_consonantToolStrip.Size = new System.Drawing.Size(218, 25);
            this.firstname_that_start_with_consonantToolStrip.TabIndex = 9;
            this.firstname_that_start_with_consonantToolStrip.Text = "firstname_that_start_with_consonantToolStrip";
            // 
            // firstname_that_start_with_consonantToolStripButton
            // 
            this.firstname_that_start_with_consonantToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.firstname_that_start_with_consonantToolStripButton.Name = "firstname_that_start_with_consonantToolStripButton";
            this.firstname_that_start_with_consonantToolStripButton.Size = new System.Drawing.Size(23, 23);
            this.firstname_that_start_with_consonantToolStripButton.Text = "Firstname_that_start_with_consonant";
            this.firstname_that_start_with_consonantToolStripButton.Click += new System.EventHandler(this.firstname_that_start_with_consonantToolStripButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(1362, 741);
            this.Controls.Add(this.firstname_that_start_with_consonantToolStrip);
            this.Controls.Add(this.section_2BToolStrip);
            this.Controls.Add(this.lastname_that_start_with_A_and_CToolStrip);
            this.Controls.Add(this.refreshToolStrip);
            this.Controls.Add(this.second_Year_StudentsToolStrip);
            this.Controls.Add(this.address_BalangaToolStrip);
            this.Controls.Add(this.bSIT_StudentsToolStrip);
            this.Controls.Add(this.bSCS_StudentsToolStrip);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Minion Pro", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.Name = "Form1";
            this.Text = "DataGrid_Cuevas";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.bSCS_StudentsToolStrip.ResumeLayout(false);
            this.bSCS_StudentsToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblStudentInfoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsDataSet)).EndInit();
            this.bSIT_StudentsToolStrip.ResumeLayout(false);
            this.bSIT_StudentsToolStrip.PerformLayout();
            this.address_BalangaToolStrip.ResumeLayout(false);
            this.address_BalangaToolStrip.PerformLayout();
            this.second_Year_StudentsToolStrip.ResumeLayout(false);
            this.second_Year_StudentsToolStrip.PerformLayout();
            this.refreshToolStrip.ResumeLayout(false);
            this.refreshToolStrip.PerformLayout();
            this.lastname_that_start_with_A_and_CToolStrip.ResumeLayout(false);
            this.lastname_that_start_with_A_and_CToolStrip.PerformLayout();
            this.section_2BToolStrip.ResumeLayout(false);
            this.section_2BToolStrip.PerformLayout();
            this.firstname_that_start_with_consonantToolStrip.ResumeLayout(false);
            this.firstname_that_start_with_consonantToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private studentsDataSet studentsDataSet;
        private System.Windows.Forms.BindingSource tblStudentInfoBindingSource;
        private studentsDataSetTableAdapters.tblStudent_InfoTableAdapter tblStudent_InfoTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn studIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn middleNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn birthdayDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn programDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sectionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn yearLevelDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStrip bSCS_StudentsToolStrip;
        private System.Windows.Forms.ToolStripButton bSCS_StudentsToolStripButton;
        private System.Windows.Forms.ToolStrip bSIT_StudentsToolStrip;
        private System.Windows.Forms.ToolStripButton bSIT_StudentsToolStripButton;
        private System.Windows.Forms.ToolStrip address_BalangaToolStrip;
        private System.Windows.Forms.ToolStripButton address_BalangaToolStripButton;
        private System.Windows.Forms.ToolStrip second_Year_StudentsToolStrip;
        private System.Windows.Forms.ToolStripButton second_Year_StudentsToolStripButton;
        private System.Windows.Forms.ToolStrip refreshToolStrip;
        private System.Windows.Forms.ToolStripButton refreshToolStripButton;
        private System.Windows.Forms.ToolStrip lastname_that_start_with_A_and_CToolStrip;
        private System.Windows.Forms.ToolStripButton lastname_that_start_with_A_and_CToolStripButton;
        private System.Windows.Forms.ToolStrip section_2BToolStrip;
        private System.Windows.Forms.ToolStripButton section_2BToolStripButton;
        private System.Windows.Forms.ToolStrip firstname_that_start_with_consonantToolStrip;
        private System.Windows.Forms.ToolStripButton firstname_that_start_with_consonantToolStripButton;
    }
}

