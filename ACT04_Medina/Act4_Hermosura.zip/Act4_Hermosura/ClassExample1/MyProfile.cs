        class MyProfile //Creating 3rd class
{
        public void DisplayProfile()
    {
        System.Console.WriteLine("\n\n\n\t    P R O F I L E\n");
        System.Console.WriteLine("Name\t :  Chris Janniel U. Hermosura\n");
        System.Console.WriteLine("Birthday :  January 7, 2001\n");
        System.Console.WriteLine("Course\t :  BS in Computer Science Major in Network" + " and Data Communication\n");
        System.Console.WriteLine("Year\t :  2nd\n");
        System.Console.WriteLine("Section\t :  A\n");
        System.Console.ReadLine();
    }
}