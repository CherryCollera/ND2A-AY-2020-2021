﻿
using System;

class DisplayProfile
{
    public void MyProfile()
    {
        System.Console.WriteLine("\n\n\n\t\t\t\tP R O F I L E");
        System.Console.WriteLine("Name:\t\t\tChester Canta");
        System.Console.WriteLine("Birthday:\t\tNovember 13, 2000");
        System.Console.WriteLine("Course:\t\t\tBS Computer Science");
        System.Console.WriteLine("Year:\t\t\t2nd Year");
        System.Console.WriteLine("Section:\t\tND2A");
        System.Console.ReadLine();
    }
}

