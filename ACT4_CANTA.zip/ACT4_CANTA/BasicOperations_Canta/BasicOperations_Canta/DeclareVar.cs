﻿
class DeclareVar
{
    public static int num1, num2, sum, diff, product, quotient, remainder;




}

