﻿
class remainder
{
    public void remain()
    {

        DeclareVar.remainder = DeclareVar.num1 % DeclareVar.num2;
        System.Console.WriteLine("The remainder is " + DeclareVar.remainder);
        System.Console.Read();


    }
}

