﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
class Sum
{
    public void Add()
    {



        DeclareVar.sum = DeclareVar.num1 + DeclareVar.num2;
        System.Console.WriteLine("The sum is " + DeclareVar.sum);
        System.Console.Read();

    }
}

