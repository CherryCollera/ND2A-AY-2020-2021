﻿

class divide
{
    public void quotient()
    {

        DeclareVar.quotient = DeclareVar.num1 / DeclareVar.num2;
        System.Console.WriteLine("The quotient is " + DeclareVar.quotient);
        System.Console.Read();


    }
}


