﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicOperations_Canta
{
    class Program
    {
        static void Main(string[] args)
        {


            Inputs go = new Inputs();
            go.Input();
            
            Sum milby = new Sum();
            milby.Add();
           
            Difference min = new Difference();
            min.Differ();
           
            Multiply mul = new Multiply();
            mul.prod();
            
            divide now = new divide();
            now.quotient();
            
            remainder rem = new remainder();
            rem.remain();












        }
    }
}
